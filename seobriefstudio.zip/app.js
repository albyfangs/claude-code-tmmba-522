/* ============================================================
   SEO/GEO Content Brief Studio — prototype
   ------------------------------------------------------------
   Flow: seed topics -> keyword research -> HUMAN APPROVAL GATE
         -> brief generation -> review & Word export.

   The approval gate is the point of the product, not a step in
   it: the AI recommends, the Director decides, and nothing is
   drafted until a human has signed off on the shortlist.

   All keyword volumes, difficulty scores and competitor rows are
   illustrative example data. There is no live Ahrefs call here.
   ============================================================ */
(function () {
  "use strict";

  /* ---------------- config ---------------- */

  var MAX_TOPICS = 5;
  var MAX_APPROVED = 10;      // C1: capped so review quality holds
  var MIN_MSV = 2000;         // mechanical filter thresholds
  var MAX_KD = 60;
  var STALE_DAYS = 14;
  var MANUAL_HRS_PER_BRIEF = 3;
  var TOOL_HRS_PER_BRIEF = 0.75;
  var STEP_MS = 620;

  /* ---------------- example keyword data ---------------- */

  var BANK = [
    { match: ["home loan", "home loans", "mortgage", "house loan"], rows: [
      { kw: "how much home can i afford",      msv: 22000,  kd: 28 },
      { kw: "home loan pre approval",          msv: 5400,   kd: 41 },
      { kw: "home loan requirements",          msv: 3600,   kd: 31 },
      { kw: "mortgage calculator",             msv: 450000, kd: 89 },
      { kw: "best mortgage lenders",           msv: 60500,  kd: 81 }
    ]},
    { match: ["refinanc", "refi"], rows: [
      { kw: "when to refinance a mortgage",    msv: 6600,   kd: 29 },
      { kw: "cash out refinance",              msv: 33100,  kd: 58 },
      { kw: "refinance closing costs",         msv: 4400,   kd: 26 },
      { kw: "refinance mortgage rates",        msv: 40500,  kd: 72 }
    ]},
    { match: ["fha"], rows: [
      { kw: "fha loan requirements",           msv: 27100,  kd: 44 },
      { kw: "fha vs conventional loan",        msv: 12100,  kd: 38 },
      { kw: "fha loan limits",                 msv: 9900,   kd: 35 },
      { kw: "fha loan credit score",           msv: 8100,   kd: 40 }
    ]},
    { match: ["first time", "first-time", "buyer"], rows: [
      { kw: "first time home buyer loans",     msv: 8100,   kd: 34 },
      { kw: "first time home buyer programs",  msv: 14800,  kd: 46 },
      { kw: "down payment assistance programs",msv: 12100,  kd: 37 }
    ]},
    { match: ["equity", "heloc"], rows: [
      { kw: "how does a heloc work",           msv: 6600,   kd: 30 },
      { kw: "heloc vs home equity loan",       msv: 9900,   kd: 39 },
      { kw: "home equity loan rates",          msv: 18100,  kd: 64 }
    ]},
    { match: ["va loan", "veteran"], rows: [
      { kw: "va loan requirements",            msv: 22200,  kd: 42 },
      { kw: "va loan eligibility",             msv: 8100,   kd: 36 }
    ]},
    { match: ["jumbo"], rows: [
      { kw: "jumbo loan requirements",         msv: 6600,   kd: 37 },
      { kw: "jumbo loan limits",               msv: 5400,   kd: 33 }
    ]}
  ];

  var DOMAINS = [
    "bankrate.com", "nerdwallet.com", "investopedia.com",
    "rocketmortgage.com", "forbes.com", "consumerfinance.gov"
  ];
  var TITLE_SHAPES = [
    "{T}: What You Need to Know",
    "{T} Explained",
    "A Complete Guide to {T}",
    "{T}: Requirements and Costs",
    "Understanding {T}"
  ];

  var PIPELINE = [
    { t: "Pull keyword & search volume data",   tool: "Ahrefs API",        aut: "retrieve",  who: "ai",
      sub: "Reading monthly search volume and difficulty for your seed topics…" },
    { t: "Scan competitor coverage",            tool: "SERP scan",         aut: "recommend", who: "ai",
      sub: "Collecting competitor titles — surfaced for your review, not scored as gaps." },
    { t: "Filter by volume & competition",      tool: "Mechanical filter", aut: "act",       who: "ai",
      sub: "Applying fixed thresholds: volume ≥ 2,000/mo, difficulty ≤ 60…" },
    { t: "Rank by opportunity",                 tool: "Ahrefs",            aut: "recommend", who: "ai",
      sub: "Ordering the shortlist so the best candidates surface first…" },

    { t: "Map source requirements",             tool: ".gov / .edu targets", aut: "recommend", who: "ai",
      sub: "Marking where an authoritative citation will be required…" },
    { t: "Draft EEAT outline",                  tool: "Outline builder",   aut: "recommend", who: "ai",
      sub: "Structuring headers around experience, expertise, authority and trust…" },
    { t: "Draft trust signals",                 tool: "Brief generator",   aut: "recommend", who: "both",
      sub: "Proposing expert quotes and credential callouts for you to confirm…" },
    { t: "Draft copy",                          tool: "Brief generator",   aut: "recommend", who: "both",
      sub: "Writing draft copy — every unsourced figure gets a [VERIFY] flag…" },
    { t: "Flag unverifiable claims",            tool: "Claim scanner",     aut: "recommend", who: "both",
      sub: "Any claim not traceable to the supplied data is flagged, never stated as fact…" },
    { t: "QA keyword placement & density",      tool: "Density check",     aut: "recommend", who: "ai",
      sub: "Confirming keywords read naturally rather than stuffed…" },
    { t: "Compile briefs & export package",     tool: "Word export",       aut: "recommend", who: "ai",
      sub: "Assembling the brief set for your review…" }
  ];
  var PHASE_A_END = 4; // steps 0-3 run before the gate

  var AUT_LABEL  = { retrieve: "Retrieve", act: "Act", recommend: "Recommend" };
  var WHO_LABEL  = { ai: "AI", both: "AI + Human" };

  var TRUST_SIGNALS = [
    "Named SoFi loan officer or underwriter quote, with title",
    "Link to SoFi's NMLS / licensing disclosure",
    "Anonymized real borrower scenario with numbers",
    "Visible author byline, reviewer credential and last-updated date"
  ];
  var CHECKLIST = [
    "Includes at least one named, cited data point",
    "Cites 2–3 authoritative .gov / .edu sources",
    "Carries a clear expertise or experience signal",
    "Author bio and reviewer credentials present",
    "Every figure traces to a source or is [VERIFY]-flagged",
    "Rate / term / eligibility claims sent to Legal"
  ];

  /* ---------------- state ---------------- */

  var state = {
    topics: [],
    pinned: [],
    candidates: [],
    cut: [],
    approved: [],
    briefs: [],
    activeBrief: 0,
    reruns: 0,
    variant: 0,
    pulledAt: null
  };
  var timers = [];

  /* ---------------- small helpers ---------------- */

  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function nfmt(n) { return n.toLocaleString("en-US"); }
  var ACRONYMS = {
    fha: "FHA", va: "VA", heloc: "HELOC", dti: "DTI", usda: "USDA",
    apr: "APR", pmi: "PMI", ltv: "LTV", arm: "ARM", nmls: "NMLS", seo: "SEO"
  };
  var MINOR = /^(a|an|the|of|to|vs|in|on|is|for|and|or)$/i;

  function titleCase(s) {
    var words = String(s).split(/(\s+)/);
    var first = true;
    return words.map(function (w) {
      if (!w.trim()) return w;
      var bare = w.toLowerCase().replace(/[^a-z]/g, "");
      if (ACRONYMS[bare]) { first = false; return w.replace(/[a-zA-Z]+/, ACRONYMS[bare]); }
      if (!first && MINOR.test(w)) return w.toLowerCase();
      first = false;
      return w.charAt(0).toUpperCase() + w.slice(1);
    }).join("");
  }
  function hash(s) {
    var h = 0, i;
    for (i = 0; i < s.length; i++) { h = (h * 31 + s.charCodeAt(i)) >>> 0; }
    return h;
  }
  function clearTimers() {
    timers.forEach(function (t) { clearTimeout(t); });
    timers = [];
  }
  function later(fn, ms) { var t = setTimeout(fn, ms); timers.push(t); return t; }
  function fmtDate(d) {
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  }

  /* ---------------- keyword generation ---------------- */

  function compsFor(kw) {
    var h = hash(kw), out = [], used = {}, i, di, si;
    for (i = 0; i < 2; i++) {
      di = (h + i * 7) % DOMAINS.length;
      while (used[di]) { di = (di + 1) % DOMAINS.length; }
      used[di] = true;
      si = (h + i * 3) % TITLE_SHAPES.length;
      out.push({
        domain: DOMAINS[di],
        title: TITLE_SHAPES[si].replace("{T}", titleCase(kw))
      });
    }
    return out;
  }

  function oppScore(msv, kd) {
    var vol = Math.log10(Math.max(msv, 10)) / Math.log10(500000);
    return Math.max(1, Math.round(Math.min(vol, 1) * (1 - kd / 100) * 100));
  }

  // Deterministic pseudo-metrics for topics/keywords not in the example bank.
  function synth(kw) {
    var h = hash(kw);
    var msv = [1300, 2400, 3600, 5400, 8100, 12100, 18100][h % 7];
    var kd = 24 + (h % 42);
    return { kw: kw, msv: msv, kd: kd };
  }

  function rowsForTopic(topic) {
    var t = topic.toLowerCase(), i, j, hit = null;
    for (i = 0; i < BANK.length; i++) {
      for (j = 0; j < BANK[i].match.length; j++) {
        if (t.indexOf(BANK[i].match[j]) !== -1) { hit = BANK[i]; break; }
      }
      if (hit) break;
    }
    if (hit) return hit.rows.slice();
    // Unknown topic: build plausible variants so the tool still demonstrates.
    return [
      synth(t + " requirements"),
      synth("how does " + t + " work"),
      synth("best " + t + " options"),
      synth(t + " rates")
    ];
  }

  function buildCandidates() {
    var seen = {}, all = [];

    state.topics.forEach(function (topic) {
      rowsForTopic(topic).forEach(function (r) {
        var key = r.kw.toLowerCase();
        if (seen[key]) return;
        seen[key] = true;
        all.push({
          kw: r.kw, msv: r.msv, kd: r.kd,
          opp: oppScore(r.msv, r.kd),
          comps: compsFor(r.kw),
          topic: topic,
          pinned: false
        });
      });
    });

    // Pinned keywords are never filtered out — the Director asked for them.
    state.pinned.forEach(function (kw) {
      var key = kw.toLowerCase(), s;
      if (seen[key]) {
        all.forEach(function (r) { if (r.kw.toLowerCase() === key) r.pinned = true; });
        return;
      }
      seen[key] = true;
      s = synth(kw);
      all.push({
        kw: kw, msv: s.msv, kd: s.kd,
        opp: oppScore(s.msv, s.kd),
        comps: compsFor(kw),
        topic: "pinned",
        pinned: true
      });
    });

    var kept = [], cut = [];
    all.forEach(function (r) {
      if (r.pinned || (r.msv >= MIN_MSV && r.kd <= MAX_KD)) kept.push(r);
      else cut.push(r);
    });

    kept.sort(function (a, b) {
      if (b.opp !== a.opp) return b.opp - a.opp;
      return b.msv - a.msv;
    });
    cut.sort(function (a, b) { return b.msv - a.msv; });

    state.candidates = kept;
    state.cut = cut;
  }

  /* ---------------- brief generation ---------------- */

  function intentOf(kw) {
    var k = kw.toLowerCase();
    if (k.indexOf(" vs ") !== -1 || k.indexOf(" vs. ") !== -1) {
      return "Comparison intent — the reader is choosing between two options. Lead with a decision table, not a definition.";
    }
    if (/^(how|what|when|why|does|can|is)\b/.test(k)) {
      return "Informational intent — answer the question directly in the first 40 words so AI overviews can extract it cleanly.";
    }
    if (k.indexOf("rate") !== -1 || k.indexOf("calculator") !== -1 || k.indexOf("apply") !== -1) {
      return "Transactional-leaning intent — the reader is close to acting. Every figure here needs Legal sign-off.";
    }
    return "Research intent — the reader is scoping options. Prioritize completeness and clear eligibility criteria.";
  }

  // Derived from what the brief ACTUALLY contains, never from the keyword string.
  // A brief whose body carries a rate/term/eligibility claim must hit the legal
  // gate even if its keyword looks harmless — and the reverse must never happen.
  var FINANCIAL_CLAIM = /rate|credit score|dti|term|eligib|limit|down payment|apr|fee/i;

  function needsLegal(brief) {
    var hit = brief.copyFlags.some(function (f) { return FINANCIAL_CLAIM.test(f); });
    if (hit) return true;
    return brief.outline.some(function (sec) {
      return sec.subs.some(function (s) { return s.flag && FINANCIAL_CLAIM.test(s.t); });
    });
  }

  function buildBrief(row, idx) {
    var kw = row.kw;
    var kwTitle = titleCase(kw);
    var v = state.variant;
    var year = new Date().getFullYear();

    var titleShapes = [
      kwTitle + ": A Complete " + year + " Guide | SoFi",
      kwTitle + " — Requirements, Costs and Next Steps | SoFi",
      "Your " + year + " Guide to " + kwTitle + " | SoFi"
    ];
    var metaShapes = [
      "Learn how " + kw + " works, what you need to qualify, and how to compare your options — explained by SoFi's home loan team.",
      "A plain-language breakdown of " + kw + ": eligibility, costs, timelines and the questions worth asking before you apply.",
      "Everything to know about " + kw + " — requirements, common pitfalls and how SoFi's loan officers approach it."
    ];

    var outline = [
      { h: "H1: " + kwTitle, subs: [] },
      { h: "H2: Quick answer", subs: [
        { t: "2–3 sentence direct answer, front-loaded for extraction by AI overviews (GEO).", flag: false }
      ]},
      { h: "H2: What “" + kw + "” actually means", subs: [
        { t: "Plain-language definition, no jargon", flag: false },
        { t: "Who this applies to and who it does not", flag: false }
      ]},
      { h: "H2: Eligibility & requirements", subs: [
        { t: "current minimum credit score and DTI thresholds", flag: true },
        { t: "Documentation checklist", flag: false }
      ]},
      { h: "H2: Step-by-step process", subs: [
        { t: "Pre-approval → application → underwriting → closing", flag: false }
      ]},
      { h: "H2: Costs & rates to expect", subs: [
        { t: "current rate range — requires Legal/Compliance sign-off", flag: true }
      ]},
      { h: "H2: Common mistakes to avoid", subs: [] },
      { h: "H2: Expert take", subs: [
        { t: "Named SoFi loan officer quote with credential", flag: false }
      ]},
      { h: "H2: FAQ (schema-ready Q&A pairs for GEO)", subs: [
        { t: "“" + kw + "” — natural-language variant", flag: false },
        { t: "Two follow-up questions readers ask next", flag: false }
      ]}
    ];

    var outlineFlags = 0;
    outline.forEach(function (sec) {
      sec.subs.forEach(function (s) { if (s.flag) outlineFlags++; });
    });

    var brief = {
      idx: idx,
      kw: kw,
      kwTitle: kwTitle,
      msv: row.msv,
      kd: row.kd,
      opp: row.opp,
      comps: row.comps,
      pinned: row.pinned,
      intent: intentOf(kw),
      titleTag: titleShapes[v % titleShapes.length],
      metaDesc: metaShapes[v % metaShapes.length],
      outline: outline,
      trust: TRUST_SIGNALS,
      checklist: CHECKLIST,
      legalCleared: false
    };

    // Flags and word counts come from the article that will actually ship,
    // so the metrics and the legal gate can never disagree with the copy.
    var stats = articleStats(brief);
    brief.copyFlags = articleFlagTexts(brief);
    brief.flagCount = outlineFlags + stats.flags;
    brief.words = stats.words;
    brief.headings = stats.headings;
    brief.needsLegal = needsLegal(brief);
    return brief;
  }

  /* ------------------------------------------------------------
     Long-form draft copy.

     Built as a section model (level + heading + paragraphs) so the
     same structure renders to the on-screen preview, the Word export
     and the plain-text fallback without drifting apart. Target is a
     publish-length draft — 1,500+ words under a single H1 with H2
     section blocks and H3 subsections — because a 200-word stub
     doesn't tell an editor whether the outline actually holds up.
     ------------------------------------------------------------ */

  function vf(t) { return '<mark class="vf">[VERIFY: ' + esc(t) + "]</mark>"; }
  function kwm(t) { return '<mark class="kw">' + esc(t) + "</mark>"; }

  function articleSections(b) {
    var kw = b.kw;
    var K = b.kwTitle;

    return [
      { lvl: 1, h: K, paras: [
        "If you're researching " + kwm(kw) + ", you're likely trying to answer a deceptively simple pair of questions: do I qualify, and what will this actually cost me? Both depend on a handful of factors that interact with each other — your credit profile, how stable your income looks on paper, how much cash you can bring to closing, and which loan program fits your circumstances. None of these sit in isolation, which is why two borrowers with similar salaries can walk away from the same lender with very different answers.",
        "This guide works through each factor in plain language. It's written for someone comparing options rather than someone who already has a loan officer on the phone, so it starts with fundamentals and builds toward the details that matter most at the decision point. Where a step tends to trip people up, we've flagged it rather than glossing over it.",
        "One note before the numbers. Rate ranges, qualifying thresholds and program limits change constantly — some of them weekly. Every figure below is marked where it needs current confirmation, for example " + vf("current published rate range") + ", and nothing here should be read as an offer, a quote, or a commitment to lend."
      ]},

      { lvl: 2, h: "The short answer", paras: [
        "For most borrowers, qualifying for " + kwm(kw) + " comes down to four checkpoints: a credit score at or above the program minimum, a debt-to-income ratio inside the lender's limit, verifiable and reasonably stable income, and enough cash for the down payment plus closing costs. Meet all four comfortably and approval is usually straightforward. Fall short on one, and compensating strengths elsewhere — a larger down payment, significant reserves, a longer employment history — can often make up the difference.",
        "Current program minimums sit near " + vf("specific minimum credit score by program") + ", though individual lenders frequently apply stricter standards of their own, known as overlays. That gap between the program floor and what a given lender will actually approve is the single most common source of confusion for first-time borrowers."
      ]},

      { lvl: 2, h: "What " + K + " actually means", paras: [
        "Before comparing offers, it helps to be precise about what you're comparing. The terminology in this space is used loosely in marketing material, and small distinctions carry real financial consequences over a thirty-year term."
      ]},
      { lvl: 3, h: "How it works in practice", paras: [
        "At its core, the arrangement is straightforward: a lender advances the purchase price, and you repay that principal plus interest on a fixed schedule, with the property itself serving as collateral. What varies between programs is who backs the loan, what the lender is permitted to accept in terms of credit and down payment, and what ongoing costs — mortgage insurance in particular — attach as a result.",
        "Government-backed programs generally allow more flexible credit and down payment terms because a federal agency absorbs part of the lender's risk. Conventional loans conforming to Fannie Mae and Freddie Mac guidelines typically ask for stronger credit but can be cheaper over the life of the loan, especially once you can drop mortgage insurance. Neither is universally better; the right answer depends on your credit, your down payment, and how long you plan to hold the property."
      ]},
      { lvl: 3, h: "Who it's typically a good fit for", paras: [
        "Borrowers who benefit most are usually those with solid income but limited savings, those rebuilding credit after a setback, or those buying in markets where prices have outpaced their ability to accumulate a large down payment. If you have excellent credit and twenty percent down, you should model conventional financing alongside it before assuming a government-backed program is cheaper — the mortgage insurance math often favors conventional at that point.",
        "It's a weaker fit if you expect to move within a few years, since upfront costs are amortized over a long horizon, or if you're purchasing a property that won't satisfy the program's condition and appraisal standards."
      ]},

      { lvl: 2, h: "Eligibility and requirements", paras: [
        "Underwriting is more formulaic than most borrowers expect. Lenders are evaluating a small number of measurable things, and knowing which ones lets you focus your effort where it actually moves the decision."
      ]},
      { lvl: 3, h: "Credit score and credit history", paras: [
        "Your score sets the floor for which programs you can access and heavily influences your rate. Program minimums currently sit around " + vf("minimum credit score threshold, by program and down payment tier") + ", but the practical minimum at most lenders runs meaningfully higher. Beyond the number itself, underwriters look at the pattern: recent late payments weigh far more heavily than old ones, and a single thirty-day mortgage or rent late in the past twelve months can matter more than a collection account from five years ago.",
        "If your score sits just below a threshold, it's usually worth delaying an application to address it. Paying revolving balances below thirty percent of their limits and disputing genuine reporting errors can move a score within one or two billing cycles — often enough to cross into a better pricing tier."
      ]},
      { lvl: 3, h: "Debt-to-income ratio", paras: [
        "Debt-to-income, or DTI, compares your total monthly debt obligations against gross monthly income. Lenders look at it two ways: the front-end ratio covering housing costs alone, and the back-end ratio including car loans, student loans, minimum credit card payments and any court-ordered obligations. The back-end figure is the binding constraint in nearly every case.",
        "Typical ceilings fall near " + vf("maximum DTI thresholds and any automated-underwriting exceptions") + ", with room above that when an automated underwriting system finds compensating factors. Note what is and isn't counted: utilities, insurance, groceries and childcare generally don't appear, while a co-signed loan you never pay does. Paying off a small installment loan entirely can sometimes help more than paying down a much larger balance, because it removes the monthly payment from the calculation completely."
      ]},
      { lvl: 3, h: "Down payment, closing costs and reserves", paras: [
        "Down payment requirements vary widely by program, currently ranging from " + vf("minimum down payment percentages by program") + ". Gift funds from family are broadly permitted, but they must be documented with a gift letter confirming the money isn't a loan, and the paper trail matters — underwriters will follow deposits back to their source.",
        "Budget separately for closing costs, which typically run several percent of the purchase price and are due at signing on top of the down payment. Some lenders and sellers will credit part of these, and certain programs cap what the seller can contribute. Reserves — liquid savings remaining after closing — aren't always required, but strong reserves can offset weakness elsewhere in the file."
      ]},

      { lvl: 2, h: "The process, step by step", paras: [
        "From first conversation to keys in hand, most transactions run thirty to forty-five days once an offer is accepted. Knowing the sequence helps you spot delays early, when they're still fixable."
      ]},
      { lvl: 3, h: "Pre-approval", paras: [
        "Pre-approval means a lender has reviewed your credit, income and assets and issued a conditional commitment. It is materially stronger than pre-qualification, which is typically a soft estimate based on figures you supplied without verification. Sellers in competitive markets increasingly disregard pre-qualification letters entirely, so get the real thing before touring properties seriously."
      ]},
      { lvl: 3, h: "Application and documentation", paras: [
        "Expect to provide recent pay stubs, two years of W-2s or tax returns, two to three months of complete bank statements, and identification. Self-employed borrowers face a heavier lift — generally two years of business and personal returns plus a year-to-date profit and loss statement. Send complete documents rather than excerpts; a bank statement missing its final page is the most common cause of an avoidable delay."
      ]},
      { lvl: 3, h: "Underwriting, appraisal and closing", paras: [
        "Underwriting is where the file is verified rather than merely collected. In parallel, an appraiser establishes the property's value; if it comes in below the contract price, you'll need to renegotiate, bring additional cash, or dispute the appraisal. Underwriters commonly return conditions — requests for clarification or additional documentation — and responding within a day or two is the single biggest factor in closing on schedule.",
        "During this window, change nothing financially. Don't open credit accounts, finance furniture, change jobs, or make large undocumented deposits. Lenders re-pull credit shortly before closing, and a new account discovered at that stage can derail an otherwise approved file."
      ]},

      { lvl: 2, h: "Costs and rates to expect", paras: [
        "Rate shopping is worthwhile, but only when you compare the right things. Two quotes at the same rate can carry materially different costs once points and fees are included."
      ]},
      { lvl: 3, h: "What actually drives your rate", paras: [
        "Your individual rate reflects credit score, loan-to-value ratio, loan program, property type, occupancy and term, layered on top of broader market conditions. Advertised rates almost always assume an excellent credit profile and a substantial down payment, and frequently include discount points paid upfront. Current averages sit near " + vf("current average rate by program and term — requires Legal/Compliance sign-off") + " and move continuously.",
        "Compare the annual percentage rate alongside the note rate, since APR folds in most lender fees and makes offers more genuinely comparable. Ask explicitly whether a quote includes points. Credit inquiries for mortgages within a short shopping window are generally treated as a single inquiry by scoring models, so comparing several lenders in the same couple of weeks does not meaningfully penalize your score."
      ]},
      { lvl: 3, h: "Closing costs, insurance and escrow", paras: [
        "Closing costs bundle origination charges, appraisal, title insurance, recording fees and prepaid items such as homeowners insurance and property taxes. Your Loan Estimate itemizes these within three business days of application, and the Closing Disclosure — which you receive at least three business days before signing — shows final figures. Compare the two line by line; unexplained increases in lender-controlled charges are worth challenging.",
        "Where mortgage insurance applies, understand both its monthly cost and its removal conditions, currently " + vf("mortgage insurance rates and cancellation terms by program") + ". On some programs it falls away automatically once you reach a defined equity threshold; on others it persists for the life of the loan unless you refinance. Over a full term, that distinction can be worth tens of thousands of dollars."
      ]},

      { lvl: 2, h: "Common mistakes to avoid", paras: [
        "The errors that cost borrowers most are rarely dramatic. They tend to be small process missteps repeated across thousands of transactions.",
        "Shopping on monthly payment alone hides the real cost — a longer term lowers the payment while increasing total interest substantially. Skipping pre-approval wastes time on properties you can't finance and weakens your position when you do find one. Making large undocumented deposits creates underwriting problems that take weeks to unwind, because every deposit outside normal payroll must be sourced.",
        "Two more are worth naming. Borrowers frequently accept the first quote without comparing, and the spread across lenders on an identical profile is often wide enough to matter over a full term. And many treat the maximum approval amount as a target rather than a ceiling, leaving no margin for maintenance, taxes, insurance increases or a change in income."
      ]},

      { lvl: 2, h: "Expert take", paras: [
        vf("named SoFi loan officer quote with title and NMLS ID — 2 to 3 sentences on the most common avoidable mistake they see") + " A specific, attributable quote from a named person with verifiable credentials is what separates content that demonstrates genuine expertise from content that merely summarizes it, and both search engines and AI answer engines weigh that signal heavily.",
        "Pair the quote with a short reviewer credit identifying who verified the financial accuracy of this article and when, and link to the relevant licensing disclosure."
      ]},

      { lvl: 2, h: "Frequently asked questions", paras: [] },
      { lvl: 3, h: "How long does approval usually take?", paras: [
        "Pre-approval is often issued within one to three business days of a complete submission. Full approval to closing typically runs thirty to forty-five days after an accepted offer, with the most common delays coming from slow responses to underwriting conditions and appraisal scheduling in busy markets."
      ]},
      { lvl: 3, h: "Can I qualify with student loan debt?", paras: [
        "Yes, and it's routine. What matters is the monthly payment counted in your DTI, not the total balance. Treatment of deferred or income-driven repayment plans varies by program — some use the actual documented payment, others impute a percentage of the outstanding balance, which can materially change your ratio. Confirm which method applies to your program before assuming you don't qualify."
      ]},
      { lvl: 3, h: "How much should I have saved beyond the down payment?", paras: [
        "Plan for closing costs of several percent of the purchase price plus an emergency reserve after closing. Program requirements are shown as " + vf("reserve requirements in months of payments, by program") + ", but independent of any requirement, moving in with no cushion is where otherwise sound purchases become financially stressful. Budget for immediate repairs and furnishing as well; both routinely exceed expectations."
      ]}
    ];
  }

  function articleHTML(b) {
    return articleSections(b).map(function (s) {
      var head = s.lvl === 1 ? "" : "<h" + s.lvl + ">" + esc(s.h) + "</h" + s.lvl + ">";
      return head + s.paras.map(function (p) { return "<p>" + p + "</p>"; }).join("");
    }).join("");
  }

  function articleText(b) {
    var out = [];
    articleSections(b).forEach(function (s) {
      var pre = s.lvl === 1 ? "" : (s.lvl === 2 ? "## " : "### ");
      out.push(pre + s.h);
      out.push("");
      s.paras.forEach(function (p) {
        out.push(stripTags(p));
        out.push("");
      });
    });
    return out.join("\n").replace(/\n{3,}/g, "\n\n").trim();
  }

  function stripTags(html) {
    return String(html)
      .replace(/<mark class="vf">/g, "")
      .replace(/<mark class="kw">/g, "")
      .replace(/<\/mark>/g, "")
      .replace(/<[^>]+>/g, "");
  }

  // Exact-match density of the target keyword across the drafted body copy.
  function kwDensity(b, words) {
    var body = articleSections(b).map(function (s) {
      return s.paras.map(stripTags).join(" ");
    }).join(" ").toLowerCase();
    var needle = b.kw.toLowerCase();
    var count = 0, at = body.indexOf(needle);
    while (at !== -1) { count++; at = body.indexOf(needle, at + needle.length); }
    var termWords = needle.split(/\s+/).length;
    return words ? ((count * termWords / words) * 100).toFixed(2) : "0.00";
  }

  function articleFlagTexts(b) {
    var out = [];
    articleSections(b).forEach(function (s) {
      s.paras.forEach(function (p) {
        var m = p.match(/\[VERIFY: [^\]]+\]/g);
        if (m) m.forEach(function (x) { out.push(x); });
      });
    });
    return out;
  }

  function articleStats(b) {
    var secs = articleSections(b);
    var words = 0, heads = 0, flags = 0;
    secs.forEach(function (s) {
      if (s.lvl > 1) heads++;
      s.paras.forEach(function (p) {
        var t = stripTags(p).trim();
        if (t) words += t.split(/\s+/).length;
        flags += (p.match(/class="vf"/g) || []).length;
      });
    });
    return { words: words, headings: heads, flags: flags };
  }

  /* ============================================================
     SCREEN 1 — intake
     ============================================================ */

  var topicInput = $("topic-input");
  var kwInput = $("kw-input");

  function renderTopics() {
    var wrap = $("topic-tags");
    wrap.innerHTML = "";
    state.topics.forEach(function (t, i) {
      var chip = document.createElement("span");
      chip.className = "tag-chip";
      var label = document.createElement("span");
      label.textContent = t;
      var x = document.createElement("button");
      x.type = "button";
      x.setAttribute("aria-label", "Remove " + t);
      x.textContent = "✕";
      x.addEventListener("click", function (e) {
        e.stopPropagation();
        state.topics.splice(i, 1);
        renderTopics();
      });
      chip.appendChild(label);
      chip.appendChild(x);
      wrap.appendChild(chip);
    });
    $("topic-count").textContent = state.topics.length;
    topicInput.disabled = state.topics.length >= MAX_TOPICS;
    topicInput.placeholder = state.topics.length >= MAX_TOPICS
      ? "Topic limit reached"
      : (state.topics.length ? "Add another topic…" : "e.g. home loans");

    var has = state.topics.length > 0;
    $("kw-prompt").classList.toggle("hidden", !has);
    $("kw-row").classList.toggle("hidden", !has);
    $("kw-meta").classList.toggle("hidden", !has);
    $("research-btn").disabled = !has;
  }

  function renderPinned() {
    var wrap = $("kw-tags");
    wrap.innerHTML = "";
    state.pinned.forEach(function (k, i) {
      var chip = document.createElement("span");
      chip.className = "tag-chip";
      var label = document.createElement("span");
      label.textContent = k;
      var x = document.createElement("button");
      x.type = "button";
      x.setAttribute("aria-label", "Remove " + k);
      x.textContent = "✕";
      x.addEventListener("click", function (e) {
        e.stopPropagation();
        state.pinned.splice(i, 1);
        renderPinned();
      });
      chip.appendChild(label);
      chip.appendChild(x);
      wrap.appendChild(chip);
    });
    $("kw-count").textContent = state.pinned.length;
  }

  function addTag(list, value, max, done) {
    var v = String(value).trim().replace(/[,\s]+$/, "");
    if (!v) return;
    if (max && list.length >= max) return;
    var exists = list.some(function (x) { return x.toLowerCase() === v.toLowerCase(); });
    if (exists) return;
    list.push(v);
    done();
  }

  function wireTagInput(inputEl, containerId, list, max, render) {
    inputEl.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === ",") {
        e.preventDefault();
        addTag(list, inputEl.value, max, render);
        inputEl.value = "";
      } else if (e.key === "Backspace" && inputEl.value === "" && list.length) {
        list.pop();
        render();
      }
    });
    inputEl.addEventListener("blur", function () {
      if (inputEl.value.trim()) {
        addTag(list, inputEl.value, max, render);
        inputEl.value = "";
      }
    });
    $(containerId).addEventListener("click", function () { inputEl.focus(); });
  }

  wireTagInput(topicInput, "topic-tag-input", state.topics, MAX_TOPICS, renderTopics);
  wireTagInput(kwInput, "kw-tag-input", state.pinned, null, renderPinned);

  $("fill-example").addEventListener("click", function () {
    state.topics = ["home loans", "refinancing", "FHA loans"];
    state.pinned = [];
    renderTopics();
    renderPinned();
    $("research-btn").focus();
  });

  $("research-btn").addEventListener("click", function () {
    if (!state.topics.length) return;
    state.reruns = 0;
    state.variant = 0;
    startResearch();
  });

  /* ============================================================
     SCREEN 2 — pipeline + gate
     ============================================================ */

  function goScreen(n) {
    var i;
    var screens = document.querySelectorAll(".screen");
    for (i = 0; i < screens.length; i++) screens[i].classList.remove("active");
    $("screen-" + n).classList.add("active");

    var items = document.querySelectorAll("#stepper li");
    for (i = 0; i < items.length; i++) {
      var s = parseInt(items[i].getAttribute("data-step"), 10);
      items[i].classList.remove("active", "done");
      if (s === n) items[i].classList.add("active");
      else if (s < n) items[i].classList.add("done");
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderPipeline() {
    var ol = $("pipeline");
    ol.innerHTML = "";
    PIPELINE.forEach(function (s, i) {
      var li = document.createElement("li");
      li.id = "pl-" + i;
      li.innerHTML =
        '<span class="pl-mark"></span>' +
        '<span class="pl-body">' +
          '<span class="pl-title">' + esc(s.t) + "</span>" +
          '<span class="pl-tags">' +
            '<span class="tg tg-' + s.aut + '">' + AUT_LABEL[s.aut] + "</span>" +
            '<span class="tg tg-' + (s.who === "both" ? "both" : "ai") + '">' + WHO_LABEL[s.who] + "</span>" +
            '<span class="tg tg-tool">' + esc(s.tool) + "</span>" +
          "</span>" +
        "</span>";
      ol.appendChild(li);
    });
  }

  function runPhase(from, to, headline, budget, onDone) {
    $("gen-stage").classList.remove("hidden");
    $("gate-stage").classList.add("hidden");
    $("gen-headline").textContent = headline;
    $("gen-budget").textContent = budget;

    var i = from;
    function step() {
      if (i > from) {
        var prev = $("pl-" + (i - 1));
        if (prev) { prev.classList.remove("on"); prev.classList.add("done"); }
      }
      if (i >= to) { onDone(); return; }
      var li = $("pl-" + i);
      if (li) {
        li.classList.add("on");
        li.scrollIntoView({ block: "nearest" });
      }
      $("gen-sub").textContent = PIPELINE[i].sub;
      $("progress-fill").style.width = Math.round(((i + 1) / PIPELINE.length) * 100) + "%";
      i++;
      later(step, STEP_MS);
    }
    step();
  }

  function startResearch() {
    clearTimers();
    goScreen(2);
    renderPipeline();
    $("progress-fill").style.width = "0%";
    state.pulledAt = new Date();
    buildCandidates();

    runPhase(0, PHASE_A_END,
      "Pulling keyword data…",
      "Latency budget: under 2 minutes — you're waiting on this one.",
      function () {
        later(showGate, 320);
      });
  }

  function showGate() {
    $("gen-stage").classList.add("hidden");
    $("gate-stage").classList.remove("hidden");
    $("sel-max").textContent = MAX_APPROVED;
    renderKwTable();
    renderCutList();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function kdClass(kd) { return kd <= 39 ? "kd-low" : (kd <= 59 ? "kd-mid" : "kd-high"); }

  function renderKwTable() {
    var tb = $("kw-tbody");
    tb.innerHTML = "";

    state.candidates.forEach(function (r, i) {
      var tr = document.createElement("tr");
      tr.setAttribute("data-i", String(i));

      var comps = r.comps.map(function (c) {
        return "<li><span class=\"comp-dom\">" + esc(c.domain) + "</span> — " + esc(c.title) + "</li>";
      }).join("");

      tr.innerHTML =
        '<td class="c-check"><input type="checkbox" aria-label="Select ' + esc(r.kw) + '"></td>' +
        '<td class="c-kw"><span class="kw-name">' + esc(r.kw) + "</span>" +
          (r.pinned ? '<span class="kw-pin">pinned</span>' : "") + "</td>" +
        '<td class="c-num">' + nfmt(r.msv) + "</td>" +
        '<td class="c-num"><span class="kd-pill ' + kdClass(r.kd) + '">' + r.kd + "</span></td>" +
        '<td class="c-num"><span class="opp-wrap">' +
          '<span class="opp-bar"><span class="opp-fill" style="width:' + Math.min(r.opp, 100) + '%"></span></span>' +
          '<span class="opp-num">' + r.opp + "</span></span></td>" +
        '<td class="c-comp"><ul class="comp-list">' + comps + "</ul></td>";

      var box = tr.querySelector("input");
      box.addEventListener("click", function (e) { e.stopPropagation(); });
      box.addEventListener("change", function () { onToggle(i, box.checked); });
      tr.addEventListener("click", function () {
        if (box.disabled && !box.checked) return;
        box.checked = !box.checked;
        onToggle(i, box.checked);
      });

      tb.appendChild(tr);
    });

    $("filtered-note").textContent =
      state.candidates.length + " passed the filter of " +
      (state.candidates.length + state.cut.length) + " pulled";
    syncSelection();
  }

  function onToggle(i, checked) {
    var kw = state.candidates[i].kw;
    var at = state.approved.indexOf(kw);
    if (checked && at === -1) {
      if (state.approved.length >= MAX_APPROVED) {
        var box = $("kw-tbody").children[i].querySelector("input");
        box.checked = false;
        return;
      }
      state.approved.push(kw);
    } else if (!checked && at !== -1) {
      state.approved.splice(at, 1);
    }
    syncSelection();
  }

  function syncSelection() {
    var rows = $("kw-tbody").children, i, box, kw, on;
    var full = state.approved.length >= MAX_APPROVED;

    for (i = 0; i < rows.length; i++) {
      kw = state.candidates[i].kw;
      on = state.approved.indexOf(kw) !== -1;
      box = rows[i].querySelector("input");
      box.checked = on;
      box.disabled = full && !on;
      rows[i].classList.toggle("sel", on);
      rows[i].style.opacity = (full && !on) ? "0.5" : "";
    }
    $("sel-count").textContent = state.approved.length;
    $("approve-btn").disabled = state.approved.length === 0;
  }

  function renderCutList() {
    $("cut-count").textContent = state.cut.length;
    $("cut-panel").classList.toggle("hidden", state.cut.length === 0);
    $("cut-list").innerHTML = state.cut.map(function (r) {
      var why = [];
      if (r.msv < MIN_MSV) why.push("volume " + nfmt(r.msv) + " below 2,000");
      if (r.kd > MAX_KD) why.push("difficulty " + r.kd + " above 60");
      return "<li><strong>" + esc(r.kw) + "</strong> — " + why.join("; ") + "</li>";
    }).join("");
  }

  $("select-top").addEventListener("click", function () {
    state.approved = state.candidates.slice(0, MAX_APPROVED).map(function (r) { return r.kw; });
    syncSelection();
  });
  $("clear-sel").addEventListener("click", function () {
    state.approved = [];
    syncSelection();
  });
  $("approve-btn").addEventListener("click", function () {
    if (!state.approved.length) return;
    startGeneration();
  });

  function startGeneration() {
    clearTimers();
    var n = state.approved.length;
    runPhase(PHASE_A_END, PIPELINE.length,
      "Drafting " + n + " brief" + (n === 1 ? "" : "s") + "…",
      "Latency budget: under 5 minutes for up to 10 briefs — runs after your approval.",
      function () {
        $("gen-headline").textContent = "Brief set ready";
        $("gen-sub").textContent = "Handing off for your review, edits and approval.";
        $("progress-fill").style.width = "100%";
        buildBriefs();
        later(function () {
          renderResults();
          goScreen(3);
        }, 520);
      });
  }

  function buildBriefs() {
    var byKw = {};
    state.candidates.forEach(function (r) { byKw[r.kw] = r; });
    state.briefs = state.approved.map(function (kw, i) {
      return buildBrief(byKw[kw], i);
    });
    state.activeBrief = 0;
  }

  /* ============================================================
     SCREEN 3 — results
     ============================================================ */

  function renderResults() {
    renderMetrics();
    renderRail();
    renderBrief();
  }

  function renderMetrics() {
    var n = state.briefs.length;
    var flags = state.briefs.reduce(function (a, b) { return a + b.flagCount; }, 0);
    var saved = n * (MANUAL_HRS_PER_BRIEF - TOOL_HRS_PER_BRIEF);

    $("m-briefs").textContent = n;
    $("m-reruns").textContent = state.reruns;
    $("m-flags").textContent = flags;
    $("m-hours").textContent = saved.toFixed(1) + " hrs";

    var rb = $("m-reruns-bar");
    if (state.reruns <= 2) { rb.textContent = "within target (≤2)"; rb.className = "h-bar good"; }
    else { rb.textContent = "over target (≤2)"; rb.className = "h-bar over"; }

    $("m-hours-bar").textContent = nfmt(n * MANUAL_HRS_PER_BRIEF) + " hrs manual → " +
      (n * TOOL_HRS_PER_BRIEF).toFixed(1) + " hrs here";
  }

  function renderRail() {
    var ul = $("rail-list");
    ul.innerHTML = "";
    state.briefs.forEach(function (b, i) {
      var li = document.createElement("li");
      li.className = "rail-item" + (i === state.activeBrief ? " on" : "");
      li.setAttribute("role", "button");
      li.setAttribute("tabindex", "0");
      var lock = b.needsLegal
        ? (b.legalCleared
            ? '<span class="rail-lock clear">✓ Legal cleared</span>'
            : '<span class="rail-lock locked">⚠ Legal required</span>')
        : "";
      li.innerHTML =
        '<span class="rail-idx">' + (i + 1) + "</span>" +
        '<span><span class="rail-kw">' + esc(b.kw) + "</span>" +
        '<span class="rail-sub">' + nfmt(b.msv) + "/mo · KD " + b.kd + "</span>" + lock + "</span>";
      li.addEventListener("click", function () { selectBrief(i); });
      li.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); selectBrief(i); }
      });
      ul.appendChild(li);
    });
  }

  function selectBrief(i) {
    state.activeBrief = i;
    renderRail();
    renderBrief();
    document.querySelector('.tab[data-tab="brief"]').click();
  }

  function renderBrief() {
    var b = state.briefs[state.activeBrief];
    if (!b) return;

    var pulled = state.pulledAt || new Date();
    var stale = new Date(pulled.getTime());
    stale.setDate(stale.getDate() + STALE_DAYS);
    $("d-pulled").textContent = fmtDate(pulled);
    $("d-stale").textContent = fmtDate(stale);
    $("d-msv").textContent = nfmt(b.msv) + "/mo";
    $("d-kd").textContent = b.kd;

    $("b-keyword").textContent = b.kw;
    $("b-intent").textContent = b.intent;
    $("b-title").textContent = b.titleTag;
    $("b-meta").textContent = b.metaDesc;

    $("b-outline").innerHTML = b.outline.map(function (sec) {
      var subs = sec.subs.length
        ? "<ul>" + sec.subs.map(function (s) {
            return s.flag
              ? '<li class="vflag">[VERIFY: ' + esc(s.t) + "]</li>"
              : "<li>" + esc(s.t) + "</li>";
          }).join("") + "</ul>"
        : "";
      return "<li>" + esc(sec.h) + subs + "</li>";
    }).join("");

    $("b-comp").innerHTML = b.comps.map(function (c) {
      return "<li><strong>" + esc(c.domain) + "</strong> — " + esc(c.title) + "</li>";
    }).join("");

    $("b-trust").innerHTML = b.trust.map(function (t) {
      return "<li>" + esc(t) + "</li>";
    }).join("");

    $("b-checklist").innerHTML = b.checklist.map(function (c, i) {
      var id = "chk-" + b.idx + "-" + i;
      return '<li><input type="checkbox" id="' + id + '"><label for="' + id + '">' + esc(c) + "</label></li>";
    }).join("");

    $("c-h1").textContent = b.kwTitle;
    $("c-body").innerHTML = articleHTML(b);

    var st = articleStats(b);
    $("cs-words").textContent = nfmt(st.words);
    $("cs-heads").textContent = st.headings;
    $("cs-flags").textContent = st.flags;
    $("cs-density").textContent = kwDensity(b, st.words) + "%";

    renderGate(b);
    $("dl-status").textContent = "";
  }

  function renderGate(b) {
    var gate = $("legal-gate");
    var cb = $("legal-checkbox");

    if (!b.needsLegal) {
      gate.classList.add("clear");
      $("lg-icon").textContent = "✓";
      $("lg-title").textContent = "No rate, term or eligibility claims detected.";
      $("lg-body").textContent =
        "Legal review isn't triggered for this brief — but the [VERIFY] flags still need sourcing, and the call is yours.";
      cb.checked = true;
      cb.disabled = true;
      $("dl-article-btn").disabled = false;
      return;
    }

    cb.disabled = false;
    cb.checked = b.legalCleared;
    gate.classList.toggle("clear", b.legalCleared);
    $("lg-icon").textContent = b.legalCleared ? "✓" : "⚠";
    $("lg-title").textContent = b.legalCleared
      ? "Cleared by Legal/Compliance."
      : "Legal/Compliance review required before publish.";
    $("lg-body").textContent = b.legalCleared
      ? "Draft copy export is unlocked. The [VERIFY] flags still need real sources filled in before this ships."
      : "This brief contains rate, term or eligibility claims. Financial (YMYL) content cannot skip legal review — this tool flags the claims, a human clears them.";
    $("dl-article-btn").disabled = !b.legalCleared;
  }

  $("legal-checkbox").addEventListener("change", function () {
    var b = state.briefs[state.activeBrief];
    if (!b || !b.needsLegal) return;
    b.legalCleared = this.checked;
    renderGate(b);
    renderRail();
  });

  /* tabs */
  (function wireTabs() {
    var tabs = document.querySelectorAll(".tab");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].addEventListener("click", function () {
        var all = document.querySelectorAll(".tab");
        for (var j = 0; j < all.length; j++) all[j].classList.remove("active");
        var panels = document.querySelectorAll(".tab-panel");
        for (var k = 0; k < panels.length; k++) panels[k].classList.remove("active");
        this.classList.add("active");
        $("panel-" + this.getAttribute("data-tab")).classList.add("active");
      });
    }
  })();

  /* regenerate + start over */
  $("regen-btn").addEventListener("click", function () {
    state.reruns += 1;
    state.variant += 1;
    clearTimers();
    goScreen(2);
    renderPipeline();
    for (var i = 0; i < PHASE_A_END; i++) {
      var li = $("pl-" + i);
      if (li) li.classList.add("done");
    }
    $("progress-fill").style.width = Math.round((PHASE_A_END / PIPELINE.length) * 100) + "%";
    startGeneration();
  });

  $("start-over-btn").addEventListener("click", function () {
    clearTimers();
    state.candidates = [];
    state.cut = [];
    state.approved = [];
    state.briefs = [];
    state.activeBrief = 0;
    state.reruns = 0;
    state.variant = 0;
    $("gen-stage").classList.remove("hidden");
    $("gate-stage").classList.add("hidden");
    goScreen(1);
    topicInput.focus();
  });

  /* ============================================================
     Word export
     ============================================================ */

  function docShell(title, body) {
    return '<!DOCTYPE html>\n' +
      '<html xmlns:o="urn:schemas-microsoft-com:office:office" ' +
      'xmlns:w="urn:schemas-microsoft-com:office:word" ' +
      'xmlns="http://www.w3.org/TR/REC-html40">\n' +
      '<head><meta charset="utf-8"><title>' + esc(title) + "</title>\n" +
      "<style>\n" +
      "body{font-family:Calibri,Arial,sans-serif;font-size:11pt;color:#0f172a;line-height:1.5;}\n" +
      "h1{font-size:19pt;color:#0f2340;} h2{font-size:13pt;color:#0f2340;margin-top:16pt;}\n" +
      "h3{font-size:11.5pt;color:#15315a;}\n" +
      ".flag{color:#b91c1c;font-weight:bold;} .kw{color:#047857;font-weight:bold;}\n" +
      ".callout{border:1.5pt solid #0f2340;background:#eef2ff;padding:8pt;margin:10pt 0;}\n" +
      ".meta{color:#64748b;font-size:9.5pt;}\n" +
      "table{border-collapse:collapse;} td,th{border:1px solid #cbd5e1;padding:5pt 8pt;font-size:10pt;}\n" +
      "</style></head>\n<body>" + body + "</body></html>";
  }

  function briefDocBody(b) {
    var outline = b.outline.map(function (sec) {
      var subs = sec.subs.length
        ? "<ul>" + sec.subs.map(function (s) {
            return s.flag
              ? '<li class="flag">[VERIFY: ' + esc(s.t) + "]</li>"
              : "<li>" + esc(s.t) + "</li>";
          }).join("") + "</ul>"
        : "";
      return "<p><strong>" + esc(sec.h) + "</strong></p>" + subs;
    }).join("");

    return "<h1>SEO Content Brief: " + esc(b.kwTitle) + "</h1>" +
      '<p class="meta">Target keyword: ' + esc(b.kw) + " &middot; Volume " + nfmt(b.msv) +
      "/mo &middot; Difficulty " + b.kd + " &middot; Data pulled " + fmtDate(state.pulledAt || new Date()) + "</p>" +
      '<div class="callout"><strong>REQUIRED:</strong> cite 2&ndash;3 authoritative .gov / .edu sources ' +
      "before publish." + (b.needsLegal
        ? " <strong>This brief contains rate/term/eligibility claims and must clear Legal/Compliance review.</strong>"
        : "") + "</div>" +
      "<h2>Search intent</h2><p>" + esc(b.intent) + "</p>" +
      "<h2>Title tag</h2><p>" + esc(b.titleTag) + "</p>" +
      "<h2>Meta description</h2><p>" + esc(b.metaDesc) + "</p>" +
      "<h2>Outline (EEAT + GEO structured)</h2>" + outline +
      "<h2>Competitor coverage (for review — not a confirmed gap)</h2><ul>" +
      b.comps.map(function (c) { return "<li>" + esc(c.domain) + " — " + esc(c.title) + "</li>"; }).join("") +
      "</ul>" +
      "<h2>Trust signals to include</h2><ul>" +
      b.trust.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ul>" +
      "<h2>EEAT checklist (human sign-off required)</h2><ul>" +
      b.checklist.map(function (c) { return "<li>&#9744; " + esc(c) + "</li>"; }).join("") + "</ul>";
  }

  function briefDocText(b) {
    var lines = [];
    lines.push("SEO CONTENT BRIEF: " + b.kwTitle);
    lines.push("Target keyword: " + b.kw + " | Volume " + nfmt(b.msv) + "/mo | Difficulty " + b.kd);
    lines.push("Data pulled " + fmtDate(state.pulledAt || new Date()));
    lines.push("");
    lines.push("REQUIRED: cite 2-3 authoritative .gov/.edu sources before publish.");
    if (b.needsLegal) lines.push("REQUIRED: contains rate/term/eligibility claims - must clear Legal/Compliance.");
    lines.push("");
    lines.push("SEARCH INTENT"); lines.push(b.intent); lines.push("");
    lines.push("TITLE TAG"); lines.push(b.titleTag); lines.push("");
    lines.push("META DESCRIPTION"); lines.push(b.metaDesc); lines.push("");
    lines.push("OUTLINE (EEAT + GEO)");
    b.outline.forEach(function (sec) {
      lines.push("  " + sec.h);
      sec.subs.forEach(function (s) {
        lines.push("    - " + (s.flag ? "[VERIFY: " + s.t + "]" : s.t));
      });
    });
    lines.push("");
    lines.push("COMPETITOR COVERAGE (for review - not a confirmed gap)");
    b.comps.forEach(function (c) { lines.push("  - " + c.domain + " - " + c.title); });
    lines.push("");
    lines.push("TRUST SIGNALS");
    b.trust.forEach(function (t) { lines.push("  - " + t); });
    lines.push("");
    lines.push("EEAT CHECKLIST (human sign-off)");
    b.checklist.forEach(function (c) { lines.push("  [ ] " + c); });
    return lines.join("\n");
  }

  function slug(s) {
    return String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "").slice(0, 60) || "brief";
  }

  function status(msg, isErr) {
    var el = $("dl-status");
    el.textContent = msg;
    el.className = "dl-status" + (isErr ? " err" : "");
    clearTimeout(status._t);
    status._t = setTimeout(function () {
      el.textContent = "";
      el.className = "dl-status";
    }, 6000);
  }

  // Saves through the viewer's downloads capability when the page is running
  // inside the Artifact sandbox (plain <a download> is inert there), and falls
  // back to a Blob anchor when opened as a normal web page.
  function saveDoc(baseName, title, html, text) {
    var full = docShell(title, html);

    if (window.claude && window.claude.downloads) {
      window.claude.downloads.save({ filename: baseName + ".html", data: full })
        .then(function () {
          status("Saved " + baseName + ".html — open it in Word (File › Open).", false);
        })
        .catch(function (err) {
          var code = err && err.code;
          if (code === "declined") { status("Download canceled.", false); return; }
          if (code === "rejected_extension" || code === "extension_not_enabled") {
            window.claude.downloads.save({ filename: baseName + ".txt", data: text })
              .then(function () { status("Saved " + baseName + ".txt (plain text fallback).", false); })
              .catch(function (e2) {
                var c2 = e2 && e2.code;
                status(c2 === "declined" ? "Download canceled." : "Couldn't save the file (" + (c2 || "error") + ").", c2 !== "declined");
              });
            return;
          }
          if (code === "rate_limited") { status("A download prompt is already open — try again in a moment.", true); return; }
          status("Couldn't save the file (" + (code || "error") + ").", true);
        });
      return;
    }

    var blob = new Blob(["﻿", full], { type: "application/msword" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = baseName + ".doc";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
    status("Downloaded " + baseName + ".doc", false);
  }

  $("dl-brief-btn").addEventListener("click", function () {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    saveDoc("SEO-Brief_" + slug(b.kw), "SEO Brief — " + b.kwTitle,
      briefDocBody(b), briefDocText(b));
  });

  $("export-all-btn").addEventListener("click", function () {
    if (!state.briefs.length) return;
    var n = state.briefs.length;
    var gated = state.briefs.filter(function (b) { return b.needsLegal; }).length;

    var head = "<h1>SEO Content Brief Set</h1>" +
      '<p class="meta">' + n + " brief" + (n === 1 ? "" : "s") +
      " &middot; generated " + fmtDate(state.pulledAt || new Date()) +
      " &middot; " + gated + " require Legal/Compliance review before publish</p>" +
      '<div class="callout"><strong>REQUIRED for every brief in this set:</strong> ' +
      "cite 2&ndash;3 authoritative .gov / .edu sources before publish. Any [VERIFY] marker is an " +
      "unsourced claim, not a fact — it must be replaced or removed.</div>";

    var body = head + state.briefs.map(function (b, i) {
      return (i > 0 ? '<p style="page-break-before:always"></p>' : "") + briefDocBody(b);
    }).join("");

    var text = "SEO CONTENT BRIEF SET\n" + n + " briefs | generated " +
      fmtDate(state.pulledAt || new Date()) + "\n" +
      gated + " require Legal/Compliance review before publish.\n\n" +
      state.briefs.map(briefDocText).join("\n\n" + new Array(60).join("=") + "\n\n");

    saveDoc("SEO-Brief-Set_" + n + "-briefs", "SEO Brief Set", body, text);
  });

  $("dl-article-btn").addEventListener("click", function () {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    if (b.needsLegal && !b.legalCleared) {
      status("Blocked: this brief still needs Legal/Compliance clearance.", true);
      return;
    }
    var body = "<h1>" + esc(b.kwTitle) + "</h1>" +
      articleHTML(b).replace(/<mark class="vf">/g, '<span class="flag">')
                 .replace(/<mark class="kw">/g, '<span class="kw">')
                 .replace(/<\/mark>/g, "</span>") +
      '<p class="meta"><em>Draft copy. Every [VERIFY] marker must be replaced with a sourced figure ' +
      "before publish.</em></p>";
    saveDoc("Draft-Copy_" + slug(b.kw), b.kwTitle, body, articleText(b));
  });

  /* ---------------- init ---------------- */
  renderTopics();
  renderPinned();
  topicInput.focus();
})();
