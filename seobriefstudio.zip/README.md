# SEO/GEO Content Brief Generator — Prototype

A clickable, front-end-only prototype for SoFi's SEO Content Brief Generator. Built for an
SEO Director to go from a topic + exact-match keywords to a review-ready SEO/GEO content
brief and article draft, with the human approval and legal/compliance gates the workflow
requires.

## Run it

No build step or dependencies — it's static HTML/CSS/JS.

```bash
python3 -m http.server 8080
# then open http://localhost:8080
```

or just open `index.html` directly in a browser.

## Screens

1. **Brief Input** (`#screen-1`) — chatbot-style form to enter a content topic and up to
   10 exact-match SEO keywords (capped for review quality, per the accuracy/cost tradeoffs).
2. **Generating** (`#screen-2`) — animated 11-step pipeline showing each cognitive task
   (keyword research → fact-checking → density QA), tagged with its autonomy level
   (Retrieve / Act / Recommend) and whether AI or AI+Human owns it.
3. **Review & Export** (`#screen-3`) — the finished brief and a copy preview, with:
   - a **mandatory Legal/Compliance gate** that blocks the article download until checked
     (rate/term/eligibility claims are YMYL content and can't skip legal review),
   - `[VERIFY: …]` flags on any claim not traceable to supplied data, instead of stated fact,
   - a **data-pulled timestamp** and staleness window,
   - a **required-sources callout** (2–3 .gov/.edu citations),
   - competitor coverage labeled "for your review" rather than a claimed content gap,
   - a human-checked EEAT structural checklist (not AI-scored),
   - downloadable **Word-compatible `.doc`** exports for both the brief and the article.

All content is placeholder/example data (mortgage/home-loan topic) generated client-side
from whatever topic and keywords you type in — there's no backend or live API integration
in this prototype.
