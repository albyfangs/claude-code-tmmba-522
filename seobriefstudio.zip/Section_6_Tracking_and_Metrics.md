# Section 6: Tracking and Metrics

## Part C: Tracking

**Q1. The 3-Tier Metric Stack**

| Tier | Metric | Target | Why this one |
|---|---|---|---|
| **Model** | **Flag recall on unverifiable claims** — of all claims in a generated brief that cannot be traced to the Ahrefs data or competitor context passed in, the share that received a `[VERIFY]` flag. | ≥95% recall. Operational bar carried from A3: no more than **1 unflagged claim per 10** spot-checked briefs; target is **0**. | The claim-flagging logic is the 20% experimental piece from C3, and it is the only thing standing between a hallucinated mortgage rate and a writer. I measure **recall, not precision**, on purpose: an over-flag costs the editor ten seconds, a missed flag is A4's Tuesday-afternoon scenario. Asymmetric downside gets the asymmetric metric. |
| **Product** | **First-pass acceptance rate** — share of briefs the Director approves for writer handoff with **zero** regenerations. | ≥70% | This is the single number that says "the output was good enough to actually use." It is already instrumented (the tool counts generations per brief), and it is upstream of every hour saved — reruns are where the time savings leak out. A3's "≤2 tries" is the guardrail underneath this; 70% first-pass is the ambition above it. |
| **Business** | **Brief-generation hours per 20 briefs** (generation only — explicitly *not* time-to-publish). | **<15 hours**, down from 60 hours manual (3 hrs × 20). | This is Q5's success criterion stated honestly. Per C2's flag, I am scoping it to generation and refusing to let it imply "publish-ready," because the mandatory legal gate is a downstream process this tool does not own. Hours saved is also the only business metric that is *cleanly attributable* to the tool at v1 — see Q3. |

---

**Q2. "This Is Working" at 30 Days**

Three things I would actually observe on the dashboard 30 days after v1 ships:

1. **At least 40 briefs generated and approved, across at least 3 of the 4 weeks, at under 0.75 hours per brief.** Two signals in one: the team beat the ~33 briefs/month implied by their 100-articles-per-quarter baseline, and they came back to the tool unprompted in most weeks rather than using it once for a pilot and drifting back to Word.

2. **Median 1 generation run per approved brief, with ≥70% approved on first pass.** First-pass quality held up under real volume rather than only in the demo. If this lands at 2–3 runs instead, the tool is technically working and practically failing — the Director is doing prompt-engineering instead of reviewing.

3. **Zero unflagged fabricated or untraceable claims across three rounds of 1-in-10 spot-checks (~6 briefs).** The safety layer held under real use. This is the one I would check first, and the only one that would make me pull v1 if it failed.

---

**Q3. What I Am Not Tracking in v1**

| Not tracking | Why I cut it |
|---|---|
| **Organic traffic, rankings, or leads from articles built on these briefs** | 3–6 month lag, and attribution is hopelessly confounded with domain authority, algorithm updates, and how well the *writer* executed the brief. At 30 days I would be reading noise — and worse, I would be tempted to read it as signal in whichever direction flattered the tool. |
| **Revenue or loan applications attributed to content** | Too far downstream to attribute honestly, but the real reason is incentive hygiene: per A4, tying this tool to a revenue number creates quiet pressure to move briefs through the legal gate faster. A metric that rewards skipping the safety gate is worse than no metric. |
| **Any AI-generated quality or EEAT score the tool assigns its own output** | This would re-introduce A1 failure mode #3 directly — a green "92% EEAT compliant" badge is exactly the thing that lets *looks right* substitute for *is right*, and it would give reviewers a false all-clear on a brief that is structurally correct but substantively thin. The EEAT checklist stays a human checkbox, unscored, by design. |

> **Note on time-to-publish:** Also deliberately excluded as a *product* metric, per C2's flag. The org should track end-to-end time-to-cleared-article, but it belongs to the legal/compliance process, not to this tool. Folding it in would either overstate what the tool delivers or penalize the tool for a queue it cannot control.

---

**Q4. Dashboard Spec**

- **Shows:** three tiles — flag recall from the latest spot-check, first-pass acceptance rate, and briefs approved this month against the ~33/month baseline — plus one list: briefs sitting in the legal gate longer than 5 days.
- **Hides:** per-keyword SEO performance, individual writer throughput, and everything traffic- or revenue-shaped (per Q3).
- **Pages someone:** only two conditions — a spot-check finds an unflagged rate/term/eligibility claim, or a brief reaches writer handoff with the legal gate unchecked. Nothing else is urgent enough to interrupt a human.
- **Who and how often:** SEO Director weekly; content ops lead monthly. Nobody watches it daily — this is a review tool, not a real-time one, and a dashboard checked daily would invite exactly the volume-over-accuracy pressure C1 already traded away.

---

**Q5. The Demo Narrative (60 seconds)**

> It's Monday. The SEO Director at SoFi has ten home-loan keywords worth chasing, a competitor publishing faster than their team can, and a writer waiting on next quarter's briefs. Each brief takes three hours by hand. Twenty briefs is sixty hours nobody has. So the list gets cut to eight, and the other twelve keywords go to Bankrate.
>
> They open the tool, type the topic, paste in ten keywords, hit generate. Under five minutes later: ten briefs. EEAT-structured outlines, title tags and meta descriptions, competitor coverage, trust signals, a GEO-optimized quick-answer block built to get picked up by AI overviews.
>
> Here's the part that matters. In the rates section, the tool did not write a number. It wrote: **VERIFY — current rate, requires legal sign-off.** It flagged its own uncertainty instead of inventing a plausible-sounding statistic. And the article export stays locked until a human checks the compliance box.
>
> Before: sixty hours, and a fabricated stat you discover after it publishes. After: fifteen hours, and every claim the AI couldn't source is marked before a writer ever sees it.

---

## Closing the Loop

| Section | Decision | How Section 6 measures it |
|---|---|---|
| §1 Intent | 3 hrs/brief → 20 briefs in <15 hrs | Business tier: brief-generation hours per 20 briefs |
| §4 A3 Eval | ≤2 reruns; 0 unflagged claims per 10 | Model tier (recall) + Product tier (first-pass rate) |
| §4 A4 Risk | Legal gate must be mandatory | Dashboard pages on gate bypass; revenue metric cut to protect the gate |
| §5 C1 Tradeoff | Accuracy over coverage | Model tier measures recall, not throughput |
| §5 C2 Flag | Q5 overstates publish-readiness | Business metric explicitly scoped to generation only |
| §5 C3 Split | Claim-flagging is the experimental 20% | Model tier points directly at it |
