/* ============================================================
   SEO/GEO Content Brief Studio — v2
   ------------------------------------------------------------
   Flow: seed topics + keywords + competitors + persona
         -> keyword research -> HUMAN APPROVAL GATE
         -> brief generation -> review -> .docx / .zip export

   v2 design rules:
   · No industry is assumed. Every keyword, outline and heading is
     derived from what the user typed. There is no built-in topic
     bank and no default vertical.
   · Competitors are analyzed only if the user names them. The tool
     never invents a competitor or claims a content gap.
   · Every brief gets its own outline. Section archetypes, heading
     phrasings and subsection sets are selected from a seeded RNG
     keyed to the keyword, so no two briefs share a structure.
   · Draft copy is written against the "signs of AI writing"
     guidance and then linted for those signs in the UI.
   ============================================================ */
(function () {
  "use strict";

  /* ---------------- config ---------------- */

  var MAX_TOPICS = 10;
  var MAX_COMPETITORS = 10;
  var MAX_APPROVED = 10;
  var MIN_MSV = 2000;
  var MAX_KD = 60;
  var STALE_DAYS = 14;
  var MANUAL_HRS_PER_BRIEF = 3;
  var TOOL_HRS_PER_BRIEF = 0.75;
  var STEP_MS = 600;
  var MIN_WORDS = 1500;   // long-form floor for every draft

  var PIPELINE = [
    { t: "Expand seed topics into keyword candidates", tool: "Keyword expansion", aut: "retrieve", who: "ai",
      sub: "Building candidate queries from your topics — no industry assumed…" },
    { t: "Estimate volume & competition",              tool: "Volume model",      aut: "retrieve", who: "ai",
      sub: "Attaching estimated monthly volume and difficulty to each candidate…" },
    { t: "Filter by volume & competition",             tool: "Mechanical filter", aut: "act",      who: "ai",
      sub: "Applying fixed thresholds: volume ≥ 2,000/mo, difficulty ≤ 60…" },
    { t: "Rank by opportunity",                        tool: "Opportunity score", aut: "recommend", who: "ai",
      sub: "Ordering the shortlist so the strongest candidates surface first…" },

    { t: "Map competitor coverage",                    tool: "Your competitor list", aut: "recommend", who: "both",
      sub: "Assigning review targets from the competitors you entered…" },
    { t: "Derive a unique outline per keyword",        tool: "Outline builder",   aut: "recommend", who: "ai",
      sub: "Selecting section structure from search intent — different for every keyword…" },
    { t: "Apply your voice & audience",                tool: "Persona",           aut: "recommend", who: "both",
      sub: "Shaping register and phrasing against the persona you described…" },
    { t: "Draft copy",                                 tool: "Draft generator",   aut: "recommend", who: "both",
      sub: "Writing long-form draft copy — unsourced figures become [VERIFY] flags…" },
    { t: "Flag unverifiable claims",                   tool: "Claim scanner",     aut: "recommend", who: "both",
      sub: "Any claim not traceable to your inputs is flagged, never stated as fact…" },
    { t: "Scan for signs of AI writing",               tool: "Style linter",      aut: "recommend", who: "ai",
      sub: "Checking for filler phrasing, puffery and formulaic structure…" },
    { t: "Compile briefs & export package",            tool: ".docx / .zip",      aut: "recommend", who: "ai",
      sub: "Assembling the brief set for your review…" }
  ];
  var PHASE_A_END = 4;

  var AUT_LABEL = { retrieve: "Retrieve", act: "Act", recommend: "Recommend" };
  var WHO_LABEL = { ai: "AI", both: "AI + Human" };

  var TRUST_SIGNALS = [
    "Named subject-matter expert quote, with role and credential",
    "Author byline plus a reviewer credit and review date",
    "First-hand or original data you can point to",
    "Visible last-updated date and a short methodology note"
  ];
  var CHECKLIST = [
    "Includes at least one named, cited data point",
    "Cites 2–3 authoritative primary sources",
    "Carries a clear expertise or first-hand experience signal",
    "Author bio and reviewer credentials present",
    "Every figure traces to a source or is [VERIFY]-flagged",
    "Regulated or high-stakes claims sent for compliance review"
  ];

  /* ============================================================
     Signs of AI writing — lexicon and linter
     ------------------------------------------------------------
     Drawn from the Wikipedia "Signs of AI writing" guidance:
     filler vocabulary, negative parallelism, puffery, vague
     attribution and formulaic section closers. The generator
     avoids these; the linter proves it rather than asserting it.
     ============================================================ */

  var AI_TELLS = [
    { re: /\b(delve|delving)\b/i,                       why: "Filler verb flagged as a common AI tell" },
    { re: /\b(tapestry|landscape of|realm of)\b/i,      why: "Stock metaphor" },
    { re: /\bstands? as a testament\b/i,                why: "Formulaic praise construction" },
    { re: /\bit'?s not just [^.,;]{2,40}, it'?s\b/i,    why: "Negative parallelism (\"not just X, it's Y\")" },
    { re: /\bnot only [^.,;]{2,40} but also\b/i,        why: "Negative parallelism (\"not only… but also\")" },
    { re: /\b(crucial|vital|pivotal|paramount)\b/i,     why: "Inflated importance adjective" },
    { re: /\b(seamless|robust|cutting-edge|state-of-the-art|game-chang)/i, why: "Marketing puffery" },
    { re: /\b(leverage|utilize)\b/i,                    why: "Corporate filler verb — prefer \"use\"" },
    { re: /\b(navigating|navigate) the\b/i,             why: "Stock metaphor" },
    { re: /\b(furthermore|moreover|additionally)\b/i,   why: "Formulaic connective" },
    { re: /\bin conclusion\b/i,                         why: "Formulaic closer" },
    { re: /\bit'?s (important|worth) (to note|noting)\b/i, why: "Empty hedging phrase" },
    { re: /\b(experts say|studies show|many believe|it is widely (regarded|believed))\b/i,
      why: "Vague attribution with no named source" },
    { re: /\b(breathtaking|stunning|world-class|renowned|must-see)\b/i, why: "Puffery adjective" },
    { re: /\bever-(evolving|changing|growing)\b/i,      why: "Stock intensifier" },
    { re: /\bplays? a (significant|key|major) role\b/i, why: "Vague filler claim" },
    { re: /\bwhen it comes to\b/i,                      why: "Filler transition" },
    { re: /\bunlock(ing)? the (power|potential|secrets)\b/i, why: "Marketing cliché" },
    { re: /\bdive (deep|into)\b/i,                      why: "Stock metaphor" },
    { re: /\bin today'?s (fast-paced|digital|modern) world\b/i, why: "Formulaic opener" }
  ];

  function lintCopy(plainText) {
    var hits = [];
    AI_TELLS.forEach(function (rule) {
      var m = plainText.match(rule.re);
      if (m) hits.push({ phrase: m[0], why: rule.why });
    });
    return hits;
  }

  /* ---------------- state ---------------- */

  var state = {
    topics: [], pinned: [], competitors: [], persona: "",
    candidates: [], cut: [], approved: [], briefs: [],
    activeBrief: 0, reruns: 0, variant: 0, pulledAt: null
  };
  var timers = [];

  /* ---------------- helpers ---------------- */

  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function xesc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[c];
    });
  }
  function nfmt(n) { return n.toLocaleString("en-US"); }
  function fmtDate(d) {
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  }
  function hash(s) {
    var h = 2166136261 >>> 0, i;
    for (i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
  }
  function mulberry(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function pick(arr, rnd) { return arr[Math.floor(rnd() * arr.length) % arr.length]; }
  function shuffle(arr, rnd) {
    var a = arr.slice(), i, j, t;
    for (i = a.length - 1; i > 0; i--) {
      j = Math.floor(rnd() * (i + 1));
      t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  var MINOR = /^(a|an|the|of|to|vs|in|on|is|for|and|or|with|at|by)$/i;
  function titleCase(s) {
    var first = true;
    return String(s).split(/(\s+)/).map(function (w) {
      if (!w.trim()) return w;
      if (w.length > 1 && w === w.toUpperCase() && /[A-Z]/.test(w)) { first = false; return w; }
      if (!first && MINOR.test(w)) return w.toLowerCase();
      first = false;
      return w.charAt(0).toUpperCase() + w.slice(1);
    }).join("");
  }
  function sentenceCase(s) {
    var t = String(s).trim();
    return t.charAt(0).toUpperCase() + t.slice(1);
  }
  function clearTimers() { timers.forEach(clearTimeout); timers = []; }
  function later(fn, ms) { var t = setTimeout(fn, ms); timers.push(t); return t; }
  function slug(s) {
    return String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "").slice(0, 50) || "item";
  }

  /* ============================================================
     Keyword expansion — domain neutral
     ============================================================ */

  var MODIFIERS = [
    { pat: "how does {t} work",        intent: "informational" },
    { pat: "what is {t}",              intent: "informational" },
    { pat: "{t} explained",            intent: "informational" },
    { pat: "how to choose {t}",        intent: "commercial" },
    { pat: "best {t}",                 intent: "commercial" },
    { pat: "{t} comparison",           intent: "comparison" },
    { pat: "{t} alternatives",         intent: "comparison" },
    { pat: "{t} cost",                 intent: "pricing" },
    { pat: "{t} pricing",              intent: "pricing" },
    { pat: "{t} requirements",         intent: "informational" },
    { pat: "{t} checklist",            intent: "tutorial" },
    { pat: "how to get started with {t}", intent: "tutorial" },
    { pat: "{t} best practices",       intent: "tutorial" },
    { pat: "{t} mistakes",             intent: "informational" },
    { pat: "{t} for beginners",        intent: "tutorial" },
    { pat: "{t} benefits",             intent: "informational" },
    { pat: "is {t} worth it",          intent: "commercial" },
    { pat: "{t} examples",             intent: "informational" }
  ];

  function detectIntent(kw) {
    var k = " " + kw.toLowerCase() + " ";
    if (/\b(vs|versus)\b/.test(k) || /\balternatives?\b/.test(k) || /\bcomparison\b/.test(k)) return "comparison";
    if (/\b(cost|costs|pricing|price|cheap|budget|fees?)\b/.test(k)) return "pricing";
    if (/\bhow to\b/.test(k) || /\b(checklist|steps?|guide|started|setup|set up|tutorial)\b/.test(k)) return "tutorial";
    if (/\b(best|top|review|reviews|worth it|choose|choosing)\b/.test(k)) return "commercial";
    if (/^\s*(how|what|why|when|where|can|is|does|do|should)\b/.test(k)) return "informational";
    return "informational";
  }

  var INTENT_LABEL = {
    informational: "Informational — the reader wants to understand. Answer directly in the opening, then build depth.",
    comparison:    "Comparison — the reader is choosing between options. Lead with a decision aid, not a definition.",
    pricing:       "Pricing — the reader wants numbers. Every figure needs a source and a date.",
    tutorial:      "How-to — the reader wants to act. Sequence matters more than background.",
    commercial:    "Commercial investigation — the reader is close to a decision and is comparing on criteria."
  };

  // Volume and difficulty are modelled, not fetched. Derived from a hash of the
  // phrase so a given keyword is stable across runs and across sessions.
  function estimate(kw) {
    var h = hash(kw);
    var rnd = mulberry(h);
    var words = kw.split(/\s+/).length;
    // Longer phrases trend to lower volume and lower competition.
    var base = [40500, 27100, 18100, 12100, 9900, 8100, 6600, 5400, 3600, 2400, 1600, 1000];
    var idx = Math.min(base.length - 1, Math.max(0, Math.floor(rnd() * 6) + (words - 2)));
    var msv = base[idx];
    var kd = Math.max(6, Math.min(92, Math.round(18 + rnd() * 55 - (words - 2) * 5)));
    return { msv: msv, kd: kd };
  }

  function oppScore(msv, kd) {
    var vol = Math.log10(Math.max(msv, 10)) / Math.log10(500000);
    return Math.max(1, Math.round(Math.min(vol, 1) * (1 - kd / 100) * 100));
  }

  function buildCandidates() {
    var seen = {}, all = [];

    state.topics.forEach(function (topic) {
      var t = topic.toLowerCase().trim();
      var rnd = mulberry(hash(t));
      // A different slice of modifiers per topic, so topics don't all
      // produce the same shaped keyword set.
      var mods = shuffle(MODIFIERS, rnd).slice(0, 6);
      // The bare topic is always a candidate.
      var rows = [{ kw: t, intent: detectIntent(t) }];
      mods.forEach(function (m) {
        rows.push({ kw: m.pat.replace("{t}", t), intent: m.intent });
      });
      rows.forEach(function (r) {
        var key = r.kw.toLowerCase();
        if (seen[key]) return;
        seen[key] = true;
        var e = estimate(r.kw);
        all.push({
          kw: r.kw, msv: e.msv, kd: e.kd, opp: oppScore(e.msv, e.kd),
          topic: topic, intent: r.intent, pinned: false
        });
      });
    });

    state.pinned.forEach(function (kw) {
      var key = kw.toLowerCase();
      if (seen[key]) {
        all.forEach(function (r) { if (r.kw.toLowerCase() === key) r.pinned = true; });
        return;
      }
      seen[key] = true;
      var e = estimate(kw);
      all.push({
        kw: kw, msv: e.msv, kd: e.kd, opp: oppScore(e.msv, e.kd),
        topic: nearestTopic(kw), intent: detectIntent(kw), pinned: true
      });
    });

    var kept = [], cut = [];
    all.forEach(function (r) {
      if (r.pinned || (r.msv >= MIN_MSV && r.kd <= MAX_KD)) kept.push(r);
      else cut.push(r);
    });
    kept.sort(function (a, b) { return b.opp - a.opp || b.msv - a.msv; });
    cut.sort(function (a, b) { return b.msv - a.msv; });

    state.candidates = kept;
    state.cut = cut;
  }

  function nearestTopic(kw) {
    var k = kw.toLowerCase(), best = state.topics[0] || kw;
    state.topics.forEach(function (t) {
      if (k.indexOf(t.toLowerCase()) !== -1) best = t;
    });
    return best;
  }

  /* ============================================================
     Competitors — only what the user supplied
     ============================================================ */

  function competitorsFor(kw) {
    if (!state.competitors.length) return [];
    var rnd = mulberry(hash("c:" + kw));
    var n = Math.min(state.competitors.length, 2 + Math.floor(rnd() * 2));
    return shuffle(state.competitors, rnd).slice(0, n);
  }

  /* ============================================================
     Persona / tone
     ============================================================ */

  function readPersona(text) {
    var p = (text || "").toLowerCase(), tags = [];
    if (/plain|simple|no jargon|accessible|clear|straightforward/.test(p)) tags.push("plain-spoken");
    if (/expert|technical|advanced|practitioner|specialist|in-depth/.test(p)) tags.push("technical");
    if (/casual|friendly|conversational|warm|approachable|human/.test(p)) tags.push("conversational");
    if (/formal|professional|authoritative|serious|corporate/.test(p)) tags.push("authoritative");
    if (/concise|brief|short|punchy|tight|skimmable/.test(p)) tags.push("concise");
    if (/data|evidence|research|numbers|proof|benchmark/.test(p)) tags.push("evidence-led");
    if (/empath|supportive|reassur|patient|beginner/.test(p)) tags.push("supportive");
    if (/no hype|no fluff|avoid hype|without hype|no buzzwords/.test(p)) tags.push("hype-free");
    if (/practical|actionable|hands-on|concrete|example/.test(p)) tags.push("practical");
    return tags;
  }

  /* ============================================================
     Outline archetypes — every brief gets its own structure
     ============================================================ */

  function T(ctx) { return ctx.topicT; }
  function K(ctx) { return ctx.kwT; }

  var ARCHETYPES = {
    quickanswer: {
      heads: ["The short answer", "Answer first", "The quick version", "Start here"],
      subs: [],
      paras: function (c, r) {
        return [
          [ { t: "The direct answer to " }, { t: c.kw, kw: true },
            { t: ": " }, { t: "one-sentence answer, written to be lifted verbatim by an AI overview", vf: true },
            { t: ". Everything below expands on that, and a reader who stops here should still leave with something usable." } ],
          [ { t: "Put the answer in the first forty words and repeat the exact query phrasing once inside it. Answer engines extract the first passage that resolves the question, so burying it under context costs the placement outright." } ]
        ];
      }
    },
    definition: {
      heads: ["What {K} actually means", "Defining {K}", "{K}, in plain terms", "What we mean by {K}"],
      subs: ["Where the term comes from", "What it is not", "Terms people confuse with it", "How practitioners actually use the word"],
      paras: function (c, r) {
        return [
          [ { t: "Definitions in this area get used loosely, and the differences matter once money or time is committed. " },
            { t: "a precise definition from an authoritative primary source, quoted and cited", vf: true },
            { t: " belongs here, followed by a plainer restatement in your own words." } ],
          [ { t: "Write the plain restatement second, not first. Leading with the formal definition establishes that you know the standard usage; following it with plain language shows you can translate. Reversing the order reads as though you are avoiding the technical version." } ]
        ];
      }
    },
    howitworks: {
      heads: ["How {T} works", "The mechanics", "What actually happens", "How this works in practice"],
      subs: ["The moving parts", "What happens first", "Where the process usually stalls", "What changes the outcome"],
      paras: function (c, r) {
        return [
          [ { t: "Most explanations of " }, { t: c.topic, kw: true },
            { t: " stop at the surface. The useful version names the moving parts and says which one the reader can actually influence. " },
            { t: "the specific mechanism, with a cited source", vf: true }, { t: "." } ],
          [ { t: "Order the parts by how much they affect the result rather than by how a vendor happens to describe them. Readers arrive with a rough mental model already, and the job is to correct the part of it that is wrong." } ]
        ];
      }
    },
    whofor: {
      heads: ["Who this is for", "Who benefits most", "Is this right for you?", "Who should care"],
      subs: ["Good fit", "Poor fit", "Edge cases worth naming", "When to revisit the decision"],
      paras: function (c, r) {
        return [
          [ { t: "Being explicit about who this suits, and who it does not, earns more trust than a page that claims universal benefit. Name at least one group who should skip it." } ],
          [ { t: "Ground each group in a situation rather than a label. \"Teams already running a formal review cycle\" tells a reader more about themselves than \"enterprise users\" does, and it gives them a test they can apply in a second." } ]
        ];
      }
    },
    requirements: {
      heads: ["What you need first", "Prerequisites", "Before you start", "What to have in place"],
      subs: ["Minimum requirements", "Nice to have", "Common blockers", "What you can skip"],
      paras: function (c, r) {
        return [
          [ { t: "List prerequisites as things a reader can check off, not as abstractions. " },
            { t: "the actual thresholds, limits, or specifications, with a source and date", vf: true },
            { t: " — treat every number here as unverified until sourced." } ],
          [ { t: "Separate the genuine requirements from the conventional advice. Readers who cannot meet a real requirement need to know now; readers held back by a convention need to know it is optional." } ]
        ];
      }
    },
    process: {
      heads: ["Step by step", "How to work through it", "The process, start to finish", "Doing it in order"],
      subs: ["Getting set up", "The main sequence", "Where people get stuck", "Finishing and checking your work"],
      paras: function (c, r) {
        return [
          [ { t: "Number the steps and keep one action per step. A step that contains two verbs is two steps, and readers following along will drop one of them." } ],
          [ { t: "Say how long each stage usually takes and what \"done\" looks like. " },
            { t: "realistic timings, from your own data or a cited source", vf: true },
            { t: ". Without a completion signal, readers cannot tell whether a slow stage is normal or broken." } ]
        ];
      }
    },
    criteria: {
      heads: ["How to evaluate the options", "What to look for", "The criteria that matter", "How to judge {T}"],
      subs: ["The criteria worth weighting", "Criteria that sound important but are not", "How to weight them for your situation", "Questions to ask a vendor"],
      paras: function (c, r) {
        return [
          [ { t: "Give the reader a short set of criteria and say plainly which one dominates. A list of twelve equally weighted factors is a way of avoiding the recommendation, and readers can tell." } ],
          [ { t: "Where you can, attach a threshold to each criterion so it becomes testable. \"Responsive support\" is unfalsifiable; \"a published response-time commitment you can hold them to\" is something a reader can go and check." } ]
        ];
      }
    },
    comparison: {
      heads: ["How the options compare", "Side by side", "Weighing the alternatives", "{T} against the alternatives"],
      subs: ["Where each option wins", "Where each falls short", "The honest trade-off", "Which to pick in which situation"],
      paras: function (c, r) {
        return [
          [ { t: "A comparison that finds one option better on every axis is a review, not a comparison, and readers discount it. Name what each option genuinely does better." } ],
          [ { t: "Build the table on criteria the reader can verify independently. " },
            { t: "current feature, pricing, or capability details for each option, dated and sourced", vf: true },
            { t: " — comparison content decays faster than anything else on the site, so date it visibly." } ]
        ];
      }
    },
    costs: {
      heads: ["What it costs", "Pricing and budget", "The real cost", "Costs to plan for"],
      subs: ["What you pay upfront", "Ongoing costs", "Costs people forget", "How to reduce the total"],
      paras: function (c, r) {
        return [
          [ { t: "Separate the headline price from the total cost. " },
            { t: "current pricing, with source and date — pricing goes stale fastest", vf: true },
            { t: ". Publishing an unsourced figure here is the fastest way to lose a reader's trust permanently." } ],
          [ { t: "Name the costs that do not appear on a pricing page: setup time, the internal hours to run it, and whatever gets abandoned to make room. Readers who discover those later feel misled by the page that omitted them." } ]
        ];
      }
    },
    mistakes: {
      heads: ["Where people go wrong", "Common mistakes", "What to avoid", "Mistakes worth knowing about"],
      subs: ["The expensive mistake", "The easy mistake", "The one nobody warns you about", "How to recover"],
      paras: function (c, r) {
        return [
          [ { t: "Mistakes sections work when they are specific enough to be uncomfortable. Generic warnings read as filler; a named, concrete error the reader recognizes from their own work earns the rest of the page." } ],
          [ { t: "Pair each mistake with the signal that it is happening, not just the fix. Readers rarely know they are making the mistake — they know something feels off — and the diagnostic is the part they cannot get elsewhere." } ]
        ];
      }
    },
    timeline: {
      heads: ["How long it takes", "Timelines and expectations", "What the schedule looks like"],
      subs: ["Typical timeline", "What speeds it up", "What causes delays"],
      paras: function (c, r) {
        return [
          [ { t: "Give a range rather than a single number, and say what puts a reader at each end of it. " },
            { t: "actual timings from your own data or a cited study", vf: true }, { t: "." } ],
          [ { t: "Note which delays the reader controls and which they do not. Knowing a two-week wait is structural rather than self-inflicted changes how someone plans around it." } ]
        ];
      }
    },
    examples: {
      heads: ["What this looks like in practice", "Worked examples", "In practice", "A concrete example"],
      subs: ["A straightforward case", "A harder case", "What the numbers looked like"],
      paras: function (c, r) {
        return [
          [ { t: "A worked example carries more weight than another paragraph of explanation. " },
            { t: "a real, anonymized example with actual figures — first-hand experience is the strongest trust signal you own", vf: true }, { t: "." } ],
          [ { t: "Show the case that did not go smoothly alongside the one that did. Published examples skew toward success, so a candid account of a harder case reads as unusually credible." } ]
        ];
      }
    },
    risks: {
      heads: ["Risks and trade-offs", "What can go wrong", "The downside worth knowing"],
      subs: ["The main risk", "Who carries it", "How to limit exposure"],
      paras: function (c, r) {
        return [
          [ { t: "State the trade-off plainly. Content that presents an option with no downside is discounted by readers and by reviewers assessing whether the page is genuinely useful." } ],
          [ { t: "Say who absorbs the risk when things go wrong. That question is usually the one a reader is circling, and it is the one most pages leave unanswered." } ]
        ];
      }
    },
    metrics: {
      heads: ["How to measure success", "Knowing whether it worked", "What to track"],
      subs: ["The metric that matters", "Leading indicators", "What not to measure"],
      paras: function (c, r) {
        return [
          [ { t: "Name one primary measure rather than a dashboard. A reader who leaves with a single number they can check next month has something they can act on." } ],
          [ { t: "Include one measure worth ignoring and say why. Ruling something out demonstrates judgment in a way that adding another metric does not." } ]
        ];
      }
    },
    expert: {
      heads: ["A practitioner's view", "Expert perspective", "From someone who does this"],
      subs: [],
      paras: function (c, r) {
        return [
          [ { t: "a named expert quote — full name, role, credential, two or three sentences on the mistake they see most", vf: true },
            { t: " An attributable quote from a real person with checkable credentials is the difference between demonstrating expertise and describing it." } ],
          [ { t: "Add a reviewer credit naming who checked this page for accuracy and when. Both search engines and answer engines weight verifiable authorship, and readers use it as a shortcut for whether to trust the numbers." } ]
        ];
      }
    },
    faq: {
      heads: ["Questions people actually ask", "Common questions", "Questions worth answering"],
      subs: [],
      paras: function (c, r) {
        return [];
      }
    },
    nextsteps: {
      heads: ["Where to go from here", "Your next step", "What to do next"],
      subs: [],
      paras: function (c, r) {
        return [
          [ { t: "Close with one concrete next action rather than a summary. A reader who has come this far does not need the page recapped; they need to know what to do on Monday." } ]
        ];
      }
    }
  };

  // Section sets per intent. The first entries are anchors, the rest are a
  // pool the RNG draws from, so structure varies keyword to keyword.
  var INTENT_PLAN = {
    informational: { anchor: ["quickanswer", "definition"], pool: ["howitworks", "whofor", "examples", "mistakes", "risks", "criteria", "timeline"] },
    comparison:    { anchor: ["quickanswer", "criteria"],   pool: ["comparison", "costs", "whofor", "mistakes", "examples", "risks"] },
    pricing:       { anchor: ["quickanswer", "costs"],      pool: ["criteria", "comparison", "mistakes", "whofor", "metrics", "risks"] },
    tutorial:      { anchor: ["quickanswer", "requirements"], pool: ["process", "mistakes", "timeline", "examples", "metrics", "risks"] },
    commercial:    { anchor: ["quickanswer", "criteria"],   pool: ["comparison", "costs", "mistakes", "examples", "whofor", "metrics"] }
  };

  function buildOutline(ctx) {
    var rnd = mulberry(hash("o:" + ctx.kw));
    var plan = INTENT_PLAN[ctx.intent] || INTENT_PLAN.informational;

    var extraCount = 3 + Math.floor(rnd() * 3);            // 3–5 from the pool
    var chosen = plan.anchor.concat(shuffle(plan.pool, rnd).slice(0, extraCount));

    // Competitors in play means the comparison lens earns a slot.
    if (ctx.competitors.length && chosen.indexOf("comparison") === -1) chosen.splice(3, 0, "comparison");
    chosen.push("expert");
    chosen.push("faq");
    if (rnd() > 0.45) chosen.push("nextsteps");

    var used = {};
    var sections = [];
    chosen.forEach(function (id) {
      if (used[id] || !ARCHETYPES[id]) return;
      used[id] = true;
      var a = ARCHETYPES[id];
      var head = pick(a.heads, rnd)
        .replace(/\{K\}/g, ctx.kwT).replace(/\{T\}/g, ctx.topicT);
      var subs = [];
      if (a.subs.length) {
        var nSubs = 2 + Math.floor(rnd() * 2);
        shuffle(a.subs, rnd).slice(0, nSubs).forEach(function (s) {
          subs.push({ t: s.replace(/\{K\}/g, ctx.kwT).replace(/\{T\}/g, ctx.topicT), flag: false });
        });
      }
      sections.push({ id: id, h: head, subs: subs });
    });

    // FAQ questions are generated from the keyword so they differ per brief.
    var faq = sections.filter(function (s) { return s.id === "faq"; })[0];
    if (faq) faq.subs = faqFor(ctx, rnd);

    return sections;
  }

  var CLOSERS = { expert: 1, faq: 1, nextsteps: 1 };

  // Adds one unused body archetype ahead of the closing sections.
  // Returns false when the pool is exhausted.
  function topUpOutline(brief, rnd) {
    var used = {};
    brief.outline.forEach(function (s) { used[s.id] = true; });
    var avail = Object.keys(ARCHETYPES).filter(function (id) {
      return !used[id] && !CLOSERS[id] && id !== "quickanswer";
    });
    if (!avail.length) return false;

    var id = avail[Math.floor(rnd() * avail.length) % avail.length];
    var a = ARCHETYPES[id];
    var head = pick(a.heads, rnd)
      .replace(/\{K\}/g, brief.ctx.kwT).replace(/\{T\}/g, brief.ctx.topicT);
    var subs = [];
    if (a.subs.length) {
      shuffle(a.subs, rnd).slice(0, 2 + Math.floor(rnd() * 2)).forEach(function (s) {
        subs.push({ t: s.replace(/\{K\}/g, brief.ctx.kwT).replace(/\{T\}/g, brief.ctx.topicT), flag: false });
      });
    }

    var at = brief.outline.length;
    for (var i = 0; i < brief.outline.length; i++) {
      if (CLOSERS[brief.outline[i].id]) { at = i; break; }
    }
    brief.outline.splice(at, 0, { id: id, h: head, subs: subs });
    return true;
  }

  function faqFor(ctx, rnd) {
    var t = ctx.topic;
    var pool = [
      "How long does " + t + " usually take?",
      "How much should I budget for " + t + "?",
      "What is the most common mistake with " + t + "?",
      "Do I need help, or can I do this myself?",
      "How do I know if " + t + " is working?",
      "What should I do first?",
      "Is " + t + " worth it for a small team?",
      "How often should this be revisited?",
      "What changes if my situation is unusual?"
    ];
    return shuffle(pool, rnd).slice(0, 3).map(function (q) {
      return { t: q, flag: false };
    });
  }

  /* ============================================================
     Brief assembly
     ============================================================ */

  function buildBrief(row, idx) {
    var ctx = {
      kw: row.kw,
      kwT: titleCase(row.kw),
      topic: row.topic,
      topicT: titleCase(row.topic),
      intent: row.intent,
      competitors: competitorsFor(row.kw),
      tone: readPersona(state.persona),
      persona: state.persona
    };

    var rnd = mulberry(hash("b:" + row.kw + ":" + state.variant));
    var outline = buildOutline(ctx);

    var titleShapes = [
      ctx.kwT + ": What to Know",
      ctx.kwT + " — A Practical Guide",
      ctx.kwT + ": How It Works and What It Costs",
      "A Straight Answer on " + ctx.kwT,
      ctx.kwT + ", Explained"
    ];
    var metaShapes = [
      "A practical look at " + ctx.kw + " — what it involves, what to watch for, and how to decide.",
      "What " + ctx.kw + " actually requires, written for people who need to make a call rather than browse.",
      "Straight answers on " + ctx.kw + ": the requirements, the trade-offs, and the parts most guides skip."
    ];

    var brief = {
      idx: idx,
      kw: ctx.kw, kwTitle: ctx.kwT,
      topic: ctx.topic, topicTitle: ctx.topicT,
      intent: ctx.intent, intentLabel: INTENT_LABEL[ctx.intent],
      msv: row.msv, kd: row.kd, opp: row.opp, pinned: row.pinned,
      competitors: ctx.competitors,
      tone: ctx.tone, persona: ctx.persona,
      titleTag: pick(titleShapes, rnd),
      metaDesc: pick(metaShapes, rnd),
      outline: outline,
      trust: TRUST_SIGNALS,
      checklist: CHECKLIST,
      legalCleared: false,
      ctx: ctx
    };

    // Long-form floor. Rather than hoping the RNG picks enough sections, top the
    // outline up with unused archetypes until the draft clears MIN_WORDS. Sections
    // are inserted before the closing blocks so the structure stays coherent.
    brief.paras = buildCopy(brief);
    var st = statsOf(brief);
    var guard = 0;
    while (st.words < MIN_WORDS && guard++ < 8) {
      if (!topUpOutline(brief, rnd)) break;
      brief.paras = buildCopy(brief);
      st = statsOf(brief);
    }

    brief.words = st.words;
    brief.headings = st.headings;
    brief.flagCount = st.flags;
    brief.lint = lintCopy(copyPlain(brief));
    brief.needsLegal = st.flags > 0;
    return brief;
  }

  /* ============================================================
     Copy generation — renders from the same outline the brief shows
     ============================================================ */

  function buildCopy(b) {
    var c = b.ctx;
    var rnd = mulberry(hash("c:" + b.kw + ":" + state.variant));
    var blocks = [];

    var openers = [
      [ { t: "If you are working out " }, { t: c.kw, kw: true },
        { t: ", the useful question is not what it is but what it changes for you. This covers the parts that affect a decision and skips the background you can find anywhere." } ],
      [ { t: "Most of what is written about " }, { t: c.kw, kw: true },
        { t: " answers a question nobody asked. This starts from the decision you are actually trying to make and works backwards to what you need in order to make it." } ],
      [ { t: "There is a short answer to " }, { t: c.kw, kw: true },
        { t: ", and there is the version with the caveats that matter. Both are here, in that order." } ]
    ];
    blocks.push({ lvl: 1, h: b.kwTitle, paras: [] });
    blocks.push({ lvl: 0, paras: [ pick(openers, rnd) ] });

    if (c.tone.length) {
      blocks.push({ lvl: 0, paras: [[
        { t: "Written for " },
        { t: c.tone.indexOf("technical") !== -1 ? "readers who already know the basics" : "readers coming to this fresh" },
        { t: ", in a " + c.tone.slice(0, 2).join(", ") + " register, per the brief." }
      ]]});
    }

    blocks.push({ lvl: 0, paras: [[
      { t: "One note on figures. Anything below marked " },
      { t: "like this", vf: true },
      { t: " is an open question rather than a fact, and it needs a real source with a date before this page goes live." }
    ]]});

    b.outline.forEach(function (sec) {
      var a = ARCHETYPES[sec.id];
      blocks.push({ lvl: 2, h: sec.h, paras: a ? a.paras(c, rnd) : [] });
      sec.subs.forEach(function (s) {
        blocks.push({ lvl: 3, h: s.t, paras: subParas(sec.id, s.t, c, rnd) });
      });
    });

    return blocks;
  }

  var SUB_LINES = [
    "Keep this to what a reader can act on. If a sentence here does not change what they do next, it belongs somewhere else or nowhere.",
    "Be specific enough to be wrong. A claim precise enough that someone could check it and disagree is worth more than a safe generality.",
    "Anchor this in a real situation rather than a category. Readers match themselves to circumstances, not to segments.",
    "Say the quiet part. Whatever a competitor's page leaves out here is usually the reason a reader is still searching.",
    "Give one concrete number or example. A single verified figure does more for credibility than a paragraph of careful hedging.",
    "Cut the throat-clearing. Open on the point rather than on a sentence explaining that the point is coming."
  ];

  var SUB_FOLLOWS = [
    "Two or three sentences is usually the right length here. If it runs longer, the point underneath it probably deserves its own heading, and readers scanning the page will thank you for the split.",
    "Where a reader is likely to disagree, say so and give them the reasoning rather than the conclusion alone. Content that anticipates the objection reads as though a person wrote it from experience.",
    "Link out once from this section to a primary source rather than to another page on your own site. Outbound citation to something authoritative is a stronger signal than an internal link, and it is the part most drafts skip.",
    "Avoid closing this section with a sentence that restates it. Summary closers on every section are one of the clearest tells that a draft was machine-written, and cutting them tightens the page.",
    "If you have first-hand experience with this, put it here in the first person. Original observation is the one thing a competitor cannot copy and an answer engine cannot synthesize from elsewhere.",
    "Name the specific situation this does not cover. A boundary makes the rest of the claim more credible, not less, and it saves the reader from applying advice that will not fit."
  ];

  function subParas(secId, subTitle, c, rnd) {
    return [
      [ { t: sentenceCase(subTitle.replace(/\?$/, "")) + ": " },
        { t: "the substantive answer, sourced", vf: true },
        { t: " " + pick(SUB_LINES, rnd) } ],
      [ { t: pick(SUB_FOLLOWS, rnd) } ]
    ];
  }

  /* ---------------- renderers over the copy model ---------------- */

  function copyHTML(b) {
    return b.paras.map(function (blk) {
      var head = "";
      if (blk.lvl === 2) head = "<h2>" + esc(blk.h) + "</h2>";
      else if (blk.lvl === 3) head = "<h3>" + esc(blk.h) + "</h3>";
      var body = blk.paras.map(function (p) {
        return "<p>" + p.map(function (tk) {
          if (tk.vf) return '<mark class="vf">[VERIFY: ' + esc(tk.t) + "]</mark>";
          if (tk.kw) return '<mark class="kw">' + esc(tk.t) + "</mark>";
          return esc(tk.t);
        }).join("") + "</p>";
      }).join("");
      return head + body;
    }).join("");
  }

  function tokenText(tk) {
    if (tk.vf) return "[VERIFY: " + tk.t + "]";
    return tk.t;
  }

  function copyPlain(b) {
    var out = [];
    b.paras.forEach(function (blk) {
      if (blk.h && blk.lvl > 1) out.push(blk.h);
      blk.paras.forEach(function (p) { out.push(p.map(tokenText).join("")); });
    });
    return out.join("\n\n");
  }

  function statsOf(b) {
    var words = 0, headings = 0, flags = 0;
    b.paras.forEach(function (blk) {
      if (blk.lvl === 2 || blk.lvl === 3) headings++;
      blk.paras.forEach(function (p) {
        p.forEach(function (tk) {
          if (tk.vf) flags++;
          var t = tokenText(tk).trim();
          if (t) words += t.split(/\s+/).length;
        });
      });
    });
    return { words: words, headings: headings, flags: flags };
  }

  function kwDensity(b) {
    var body = copyPlain(b).toLowerCase();
    var needle = b.kw.toLowerCase();
    var count = 0, at = body.indexOf(needle);
    while (at !== -1) { count++; at = body.indexOf(needle, at + needle.length); }
    var termWords = needle.split(/\s+/).length;
    return b.words ? ((count * termWords / b.words) * 100).toFixed(2) : "0.00";
  }

  /* ============================================================
     ZIP writer (store + raw deflate) and DOCX builder
     ============================================================ */

  var CRC_TABLE = (function () {
    var t = new Uint32Array(256), c, n, k;
    for (n = 0; n < 256; n++) {
      c = n;
      for (k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    return t;
  })();

  function crc32(u8) {
    var c = 0xFFFFFFFF, i;
    for (i = 0; i < u8.length; i++) c = CRC_TABLE[(c ^ u8[i]) & 0xFF] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }

  function utf8(str) { return new TextEncoder().encode(str); }

  function deflateRaw(u8) {
    if (typeof CompressionStream === "undefined") return Promise.resolve(null);
    try {
      var cs = new CompressionStream("deflate-raw");
      var stream = new Blob([u8]).stream().pipeThrough(cs);
      return new Response(stream).arrayBuffer().then(function (ab) {
        return new Uint8Array(ab);
      }).catch(function () { return null; });
    } catch (e) { return Promise.resolve(null); }
  }

  function dosTime(d) {
    return ((d.getHours() << 11) | (d.getMinutes() << 5) | (Math.floor(d.getSeconds() / 2))) & 0xFFFF;
  }
  function dosDate(d) {
    return (((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate()) & 0xFFFF;
  }

  // entries: [{name, data:Uint8Array}] -> Uint8Array of a valid .zip
  function makeZip(entries) {
    var now = new Date();
    var time = dosTime(now), date = dosDate(now);

    return Promise.all(entries.map(function (e) {
      return deflateRaw(e.data).then(function (def) {
        var useDef = def && def.length < e.data.length;
        return {
          nameBytes: utf8(e.name),
          crc: crc32(e.data),
          raw: e.data.length,
          body: useDef ? def : e.data,
          method: useDef ? 8 : 0
        };
      });
    })).then(function (parts) {
      var chunks = [], central = [], offset = 0;

      parts.forEach(function (p) {
        var lh = new Uint8Array(30 + p.nameBytes.length);
        var v = new DataView(lh.buffer);
        v.setUint32(0, 0x04034b50, true);
        v.setUint16(4, 20, true);
        v.setUint16(6, 0, true);
        v.setUint16(8, p.method, true);
        v.setUint16(10, time, true);
        v.setUint16(12, date, true);
        v.setUint32(14, p.crc, true);
        v.setUint32(18, p.body.length, true);
        v.setUint32(22, p.raw, true);
        v.setUint16(26, p.nameBytes.length, true);
        v.setUint16(28, 0, true);
        lh.set(p.nameBytes, 30);
        chunks.push(lh, p.body);

        var cd = new Uint8Array(46 + p.nameBytes.length);
        var cv = new DataView(cd.buffer);
        cv.setUint32(0, 0x02014b50, true);
        cv.setUint16(4, 20, true);
        cv.setUint16(6, 20, true);
        cv.setUint16(8, 0, true);
        cv.setUint16(10, p.method, true);
        cv.setUint16(12, time, true);
        cv.setUint16(14, date, true);
        cv.setUint32(16, p.crc, true);
        cv.setUint32(20, p.body.length, true);
        cv.setUint32(24, p.raw, true);
        cv.setUint16(28, p.nameBytes.length, true);
        cv.setUint16(30, 0, true);
        cv.setUint16(32, 0, true);
        cv.setUint16(34, 0, true);
        cv.setUint16(36, 0, true);
        cv.setUint32(38, 0, true);
        cv.setUint32(42, offset, true);
        cd.set(p.nameBytes, 46);
        central.push(cd);

        offset += lh.length + p.body.length;
      });

      var cdSize = central.reduce(function (a, c) { return a + c.length; }, 0);
      var eocd = new Uint8Array(22);
      var ev = new DataView(eocd.buffer);
      ev.setUint32(0, 0x06054b50, true);
      ev.setUint16(4, 0, true);
      ev.setUint16(6, 0, true);
      ev.setUint16(8, parts.length, true);
      ev.setUint16(10, parts.length, true);
      ev.setUint32(12, cdSize, true);
      ev.setUint32(16, offset, true);
      ev.setUint16(20, 0, true);

      var all = chunks.concat(central, [eocd]);
      var total = all.reduce(function (a, c) { return a + c.length; }, 0);
      var out = new Uint8Array(total), at = 0;
      all.forEach(function (c) { out.set(c, at); at += c.length; });
      return out;
    });
  }

  /* ---------------- DOCX ---------------- */

  var DOCX_CT =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">' +
    '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>' +
    '<Default Extension="xml" ContentType="application/xml"/>' +
    '<Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>' +
    '<Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>' +
    "</Types>";

  var DOCX_RELS =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>' +
    "</Relationships>";

  var DOCX_DOCRELS =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' +
    '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/>' +
    "</Relationships>";

  function headingStyle(id, size, color) {
    return '<w:style w:type="paragraph" w:styleId="Heading' + id + '">' +
      '<w:name w:val="heading ' + id + '"/><w:basedOn w:val="Normal"/>' +
      '<w:pPr><w:keepNext/><w:spacing w:before="' + (id === 1 ? 0 : 260) + '" w:after="120"/><w:outlineLvl w:val="' + (id - 1) + '"/></w:pPr>' +
      '<w:rPr><w:b/><w:color w:val="' + color + '"/><w:sz w:val="' + size + '"/></w:rPr></w:style>';
  }

  var DOCX_STYLES =
    '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
    '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">' +
    '<w:docDefaults><w:rPrDefault><w:rPr>' +
    '<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:sz w:val="22"/>' +
    "</w:rPr></w:rPrDefault></w:docDefaults>" +
    '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/>' +
    '<w:pPr><w:spacing w:after="160" w:line="280" w:lineRule="auto"/></w:pPr></w:style>' +
    headingStyle(1, 40, "0F2340") +
    headingStyle(2, 30, "15315A") +
    headingStyle(3, 25, "334155") +
    "</w:styles>";

  function run(text, opts) {
    opts = opts || {};
    var rpr = "";
    if (opts.b) rpr += "<w:b/>";
    if (opts.i) rpr += "<w:i/>";
    if (opts.color) rpr += '<w:color w:val="' + opts.color + '"/>';
    if (opts.sz) rpr += '<w:sz w:val="' + opts.sz + '"/>';
    return "<w:r>" + (rpr ? "<w:rPr>" + rpr + "</w:rPr>" : "") +
      '<w:t xml:space="preserve">' + xesc(text) + "</w:t></w:r>";
  }

  function para(runs, style) {
    return "<w:p>" + (style ? '<w:pPr><w:pStyle w:val="' + style + '"/></w:pPr>' : "") +
      runs.join("") + "</w:p>";
  }

  function docxFile(bodyXml) {
    var doc = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' +
      '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' +
      bodyXml +
      '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/>' +
      '<w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr>' +
      "</w:body></w:document>";
    return makeZip([
      { name: "[Content_Types].xml", data: utf8(DOCX_CT) },
      { name: "_rels/.rels", data: utf8(DOCX_RELS) },
      { name: "word/_rels/document.xml.rels", data: utf8(DOCX_DOCRELS) },
      { name: "word/styles.xml", data: utf8(DOCX_STYLES) },
      { name: "word/document.xml", data: utf8(doc) }
    ]);
  }

  function briefDocxBody(b) {
    var x = [];
    x.push(para([run("Content brief: " + b.kwTitle)], "Heading1"));
    x.push(para([run("Seed topic: " + b.topic + "  |  Est. volume " + nfmt(b.msv) +
      "/mo  |  Difficulty " + b.kd + "  |  Pulled " + fmtDate(state.pulledAt || new Date()),
      { i: true, color: "64748B", sz: 18 })]));

    x.push(para([
      run("REQUIRED: ", { b: true, color: "B91C1C" }),
      run("cite 2–3 authoritative primary sources before publish. Every [VERIFY] marker is an open question, not a fact.")
    ]));

    if (b.persona) {
      x.push(para([run("Voice & audience")], "Heading2"));
      x.push(para([run(b.persona)]));
      if (b.tone.length) x.push(para([run("Detected register: " + b.tone.join(", "), { i: true, color: "64748B" })]));
    }

    x.push(para([run("Search intent")], "Heading2"));
    x.push(para([run(b.intentLabel)]));

    x.push(para([run("Title tag")], "Heading2"));
    x.push(para([run(b.titleTag)]));
    x.push(para([run("Meta description")], "Heading2"));
    x.push(para([run(b.metaDesc)]));

    x.push(para([run("Outline")], "Heading2"));
    b.outline.forEach(function (sec) {
      x.push(para([run("H2  " + sec.h, { b: true })]));
      sec.subs.forEach(function (s) {
        x.push(para([run("        H3  " + s.t, { color: "334155" })]));
      });
    });

    x.push(para([run("Competitor coverage")], "Heading2"));
    if (b.competitors.length) {
      x.push(para([run("Audit these against this outline. Titles and headings are not fetched — capture them yourself.", { i: true, color: "64748B" })]));
      b.competitors.forEach(function (c) {
        x.push(para([run("•  " + c + " — capture current H2/H3 structure for \"" + b.kw + "\"; note what they cover that this outline does not.")]));
      });
    } else {
      x.push(para([run("No competitors were entered, so none were analyzed. This tool does not invent competitors.", { i: true })]));
    }

    x.push(para([run("Trust signals to include")], "Heading2"));
    b.trust.forEach(function (t) { x.push(para([run("•  " + t)])); });

    x.push(para([run("Editorial checklist")], "Heading2"));
    b.checklist.forEach(function (c) { x.push(para([run("☐  " + c)])); });

    return x.join("");
  }

  function copyDocxBody(b) {
    var x = [];
    b.paras.forEach(function (blk) {
      if (blk.lvl === 1) x.push(para([run(blk.h)], "Heading1"));
      else if (blk.lvl === 2) x.push(para([run(blk.h)], "Heading2"));
      else if (blk.lvl === 3) x.push(para([run(blk.h)], "Heading3"));
      blk.paras.forEach(function (p) {
        x.push(para(p.map(function (tk) {
          if (tk.vf) return run("[VERIFY: " + tk.t + "]", { b: true, color: "B91C1C" });
          if (tk.kw) return run(tk.t, { b: true, color: "047857" });
          return run(tk.t);
        })));
      });
    });
    return x.join("");
  }

  /* ============================================================
     UI — screen 1
     ============================================================ */

  var topicInput = $("topic-input");
  var kwInput = $("kw-input");
  var compInput = $("comp-input");
  var personaInput = $("persona-input");

  function chipList(hostId, list, render, label) {
    var wrap = $(hostId);
    wrap.innerHTML = "";
    list.forEach(function (v, i) {
      var chip = document.createElement("span");
      chip.className = "tag-chip";
      var s = document.createElement("span");
      s.textContent = v;
      var x = document.createElement("button");
      x.type = "button";
      x.setAttribute("aria-label", "Remove " + label + " " + v);
      x.textContent = "✕";
      x.addEventListener("click", function (e) { e.stopPropagation(); list.splice(i, 1); render(); });
      chip.appendChild(s); chip.appendChild(x);
      wrap.appendChild(chip);
    });
  }

  function renderTopics() {
    chipList("topic-tags", state.topics, renderTopics, "topic");
    $("topic-count").textContent = state.topics.length;
    topicInput.disabled = state.topics.length >= MAX_TOPICS;
    topicInput.placeholder = state.topics.length >= MAX_TOPICS
      ? "Topic limit reached"
      : (state.topics.length ? "Add another topic…" : "e.g. project management software");

    var has = state.topics.length > 0;
    ["kw-prompt", "kw-row", "kw-meta", "comp-prompt", "comp-row", "comp-meta",
     "persona-prompt", "persona-row", "persona-meta"].forEach(function (id) {
      $(id).classList.toggle("hidden", !has);
    });
    $("research-btn").disabled = !has;
  }
  function renderPinned() {
    chipList("kw-tags", state.pinned, renderPinned, "keyword");
    $("kw-count").textContent = state.pinned.length;
  }
  function renderComps() {
    chipList("comp-tags", state.competitors, renderComps, "competitor");
    $("comp-count").textContent = state.competitors.length;
    compInput.disabled = state.competitors.length >= MAX_COMPETITORS;
    compInput.placeholder = state.competitors.length >= MAX_COMPETITORS
      ? "Competitor limit reached" : "e.g. asana.com";
  }

  function addTag(list, value, max, done) {
    var v = String(value).trim().replace(/[,\s]+$/, "");
    if (!v) return;
    if (max && list.length >= max) return;
    if (list.some(function (x) { return x.toLowerCase() === v.toLowerCase(); })) return;
    list.push(v);
    done();
  }

  function wireTagInput(inputEl, containerId, list, max, render) {
    inputEl.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === ",") {
        e.preventDefault();
        addTag(list, inputEl.value, max, render);
        inputEl.value = "";
      } else if (e.key === "Backspace" && inputEl.value === "" && list.length) {
        list.pop(); render();
      }
    });
    inputEl.addEventListener("blur", function () {
      if (inputEl.value.trim()) { addTag(list, inputEl.value, max, render); inputEl.value = ""; }
    });
    $(containerId).addEventListener("click", function () { inputEl.focus(); });
  }

  wireTagInput(topicInput, "topic-tag-input", state.topics, MAX_TOPICS, renderTopics);
  wireTagInput(kwInput, "kw-tag-input", state.pinned, null, renderPinned);
  wireTagInput(compInput, "comp-tag-input", state.competitors, MAX_COMPETITORS, renderComps);

  personaInput.addEventListener("input", function () {
    state.persona = personaInput.value;
    $("persona-count").textContent = personaInput.value.length;
    var tags = readPersona(personaInput.value);
    $("persona-read").textContent = tags.length ? "reading as: " + tags.join(", ") : "";
  });

  $("fill-example").addEventListener("click", function () {
    state.topics = ["project management software", "team collaboration tools", "remote onboarding"];
    state.pinned = ["asynchronous standup"];
    state.competitors = ["asana.com", "monday.com", "notion.so"];
    state.persona = "Direct and practical, for ops managers at mid-size teams. Plain English, no hype, concrete examples over theory.";
    personaInput.value = state.persona;
    personaInput.dispatchEvent(new Event("input"));
    renderTopics(); renderPinned(); renderComps();
    $("research-btn").focus();
  });

  $("research-btn").addEventListener("click", function () {
    if (!state.topics.length) return;
    state.reruns = 0; state.variant = 0;
    startResearch();
  });

  /* ============================================================
     UI — screen 2
     ============================================================ */

  function goScreen(n) {
    var i, screens = document.querySelectorAll(".screen");
    for (i = 0; i < screens.length; i++) screens[i].classList.remove("active");
    $("screen-" + n).classList.add("active");
    var items = document.querySelectorAll("#stepper li");
    for (i = 0; i < items.length; i++) {
      var s = parseInt(items[i].getAttribute("data-step"), 10);
      items[i].classList.remove("active", "done");
      if (s === n) items[i].classList.add("active");
      else if (s < n) items[i].classList.add("done");
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderPipeline() {
    var ol = $("pipeline");
    ol.innerHTML = "";
    PIPELINE.forEach(function (s, i) {
      var li = document.createElement("li");
      li.id = "pl-" + i;
      li.innerHTML = '<span class="pl-mark"></span><span class="pl-body">' +
        '<span class="pl-title">' + esc(s.t) + "</span><span class=\"pl-tags\">" +
        '<span class="tg tg-' + s.aut + '">' + AUT_LABEL[s.aut] + "</span>" +
        '<span class="tg tg-' + (s.who === "both" ? "both" : "ai") + '">' + WHO_LABEL[s.who] + "</span>" +
        '<span class="tg tg-tool">' + esc(s.tool) + "</span></span></span>";
      ol.appendChild(li);
    });
  }

  function runPhase(from, to, headline, budget, onDone) {
    $("gen-stage").classList.remove("hidden");
    $("gate-stage").classList.add("hidden");
    $("gen-headline").textContent = headline;
    $("gen-budget").textContent = budget;
    var i = from;
    function step() {
      if (i > from) {
        var prev = $("pl-" + (i - 1));
        if (prev) { prev.classList.remove("on"); prev.classList.add("done"); }
      }
      if (i >= to) { onDone(); return; }
      var li = $("pl-" + i);
      if (li) { li.classList.add("on"); li.scrollIntoView({ block: "nearest" }); }
      $("gen-sub").textContent = PIPELINE[i].sub;
      $("progress-fill").style.width = Math.round(((i + 1) / PIPELINE.length) * 100) + "%";
      i++;
      later(step, STEP_MS);
    }
    step();
  }

  function startResearch() {
    clearTimers();
    goScreen(2);
    renderPipeline();
    $("progress-fill").style.width = "0%";
    state.pulledAt = new Date();
    state.approved = [];
    buildCandidates();
    runPhase(0, PHASE_A_END, "Pulling keyword data…",
      "Latency budget: under 2 minutes — you're waiting on this one.",
      function () { later(showGate, 300); });
  }

  function showGate() {
    $("gen-stage").classList.add("hidden");
    $("gate-stage").classList.remove("hidden");
    $("sel-max").textContent = MAX_APPROVED;
    renderKwTable();
    renderCutList();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function kdClass(kd) { return kd <= 39 ? "kd-low" : (kd <= 59 ? "kd-mid" : "kd-high"); }

  function renderKwTable() {
    var tb = $("kw-tbody");
    tb.innerHTML = "";
    state.candidates.forEach(function (r, i) {
      var tr = document.createElement("tr");
      var comps = competitorsFor(r.kw);
      var compCell = comps.length
        ? '<ul class="comp-list">' + comps.map(function (c) {
            return "<li><span class=\"comp-dom\">" + esc(c) + "</span></li>";
          }).join("") + "</ul>"
        : '<span class="comp-none">none entered</span>';

      tr.innerHTML =
        '<td class="c-check"><input type="checkbox" aria-label="Select ' + esc(r.kw) + '"></td>' +
        '<td class="c-kw"><span class="kw-name">' + esc(r.kw) + "</span>" +
          (r.pinned ? '<span class="kw-pin">pinned</span>' : "") +
          '<span class="kw-topic">' + esc(r.topic) + " · " + esc(r.intent) + "</span></td>" +
        '<td class="c-num">' + nfmt(r.msv) + "</td>" +
        '<td class="c-num"><span class="kd-pill ' + kdClass(r.kd) + '">' + r.kd + "</span></td>" +
        '<td class="c-num"><span class="opp-wrap">' +
          '<span class="opp-bar"><span class="opp-fill" style="width:' + Math.min(r.opp, 100) + '%"></span></span>' +
          '<span class="opp-num">' + r.opp + "</span></span></td>" +
        '<td class="c-comp">' + compCell + "</td>";

      var box = tr.querySelector("input");
      box.addEventListener("click", function (e) { e.stopPropagation(); });
      box.addEventListener("change", function () { onToggle(i, box.checked); });
      tr.addEventListener("click", function () {
        if (box.disabled && !box.checked) return;
        box.checked = !box.checked;
        onToggle(i, box.checked);
      });
      tb.appendChild(tr);
    });
    $("filtered-note").textContent = state.candidates.length + " passed the filter of " +
      (state.candidates.length + state.cut.length) + " generated";
    syncSelection();
  }

  function onToggle(i, checked) {
    var kw = state.candidates[i].kw;
    var at = state.approved.indexOf(kw);
    if (checked && at === -1) {
      if (state.approved.length >= MAX_APPROVED) {
        $("kw-tbody").children[i].querySelector("input").checked = false;
        return;
      }
      state.approved.push(kw);
    } else if (!checked && at !== -1) state.approved.splice(at, 1);
    syncSelection();
  }

  function syncSelection() {
    var rows = $("kw-tbody").children, i, box, on;
    var full = state.approved.length >= MAX_APPROVED;
    for (i = 0; i < rows.length; i++) {
      on = state.approved.indexOf(state.candidates[i].kw) !== -1;
      box = rows[i].querySelector("input");
      box.checked = on;
      box.disabled = full && !on;
      rows[i].classList.toggle("sel", on);
      rows[i].style.opacity = (full && !on) ? "0.5" : "";
    }
    $("sel-count").textContent = state.approved.length;
    $("approve-btn").disabled = state.approved.length === 0;
  }

  function renderCutList() {
    $("cut-count").textContent = state.cut.length;
    $("cut-panel").classList.toggle("hidden", state.cut.length === 0);
    $("cut-list").innerHTML = state.cut.map(function (r) {
      var why = [];
      if (r.msv < MIN_MSV) why.push("est. volume " + nfmt(r.msv) + " below 2,000");
      if (r.kd > MAX_KD) why.push("difficulty " + r.kd + " above 60");
      return "<li><strong>" + esc(r.kw) + "</strong> — " + why.join("; ") + "</li>";
    }).join("");
  }

  $("select-top").addEventListener("click", function () {
    state.approved = state.candidates.slice(0, MAX_APPROVED).map(function (r) { return r.kw; });
    syncSelection();
  });
  $("clear-sel").addEventListener("click", function () { state.approved = []; syncSelection(); });
  $("approve-btn").addEventListener("click", function () {
    if (state.approved.length) startGeneration();
  });

  function startGeneration() {
    clearTimers();
    var n = state.approved.length;
    runPhase(PHASE_A_END, PIPELINE.length,
      "Drafting " + n + " brief" + (n === 1 ? "" : "s") + "…",
      "Latency budget: under 5 minutes for up to 10 briefs — runs after your approval.",
      function () {
        $("gen-headline").textContent = "Brief set ready";
        $("gen-sub").textContent = "Handing off for your review, edits and approval.";
        $("progress-fill").style.width = "100%";
        buildBriefs();
        later(function () { renderResults(); goScreen(3); }, 480);
      });
  }

  function buildBriefs() {
    var byKw = {};
    state.candidates.forEach(function (r) { byKw[r.kw] = r; });
    state.briefs = state.approved.map(function (kw, i) { return buildBrief(byKw[kw], i); });
    state.activeBrief = 0;
  }

  /* ============================================================
     UI — screen 3
     ============================================================ */

  function renderResults() { renderMetrics(); renderRail(); renderBrief(); }

  function renderMetrics() {
    var n = state.briefs.length;
    var flags = state.briefs.reduce(function (a, b) { return a + b.flagCount; }, 0);
    var saved = n * (MANUAL_HRS_PER_BRIEF - TOOL_HRS_PER_BRIEF);
    $("m-briefs").textContent = n;
    $("m-reruns").textContent = state.reruns;
    $("m-flags").textContent = flags;
    $("m-hours").textContent = saved.toFixed(1) + " hrs";
    var rb = $("m-reruns-bar");
    rb.textContent = state.reruns <= 2 ? "within target (≤2)" : "over target (≤2)";
    rb.className = "h-bar " + (state.reruns <= 2 ? "good" : "over");
    $("m-hours-bar").textContent = nfmt(n * MANUAL_HRS_PER_BRIEF) + " hrs manual → " +
      (n * TOOL_HRS_PER_BRIEF).toFixed(1) + " hrs here";
  }

  function renderRail() {
    var ul = $("rail-list");
    ul.innerHTML = "";
    state.briefs.forEach(function (b, i) {
      var li = document.createElement("li");
      li.className = "rail-item" + (i === state.activeBrief ? " on" : "");
      li.setAttribute("role", "button");
      li.setAttribute("tabindex", "0");
      var lock = b.needsLegal
        ? (b.legalCleared ? '<span class="rail-lock clear">✓ Cleared</span>'
                          : '<span class="rail-lock locked">⚠ Review required</span>')
        : "";
      li.innerHTML = '<span class="rail-idx">' + (i + 1) + "</span><span>" +
        '<span class="rail-kw">' + esc(b.kw) + "</span>" +
        '<span class="rail-sub">' + nfmt(b.msv) + "/mo · KD " + b.kd + "</span>" + lock + "</span>";
      li.addEventListener("click", function () { selectBrief(i); });
      li.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); selectBrief(i); }
      });
      ul.appendChild(li);
    });
  }

  function selectBrief(i) {
    state.activeBrief = i;
    renderRail(); renderBrief();
    document.querySelector('.tab[data-tab="brief"]').click();
  }

  function renderBrief() {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    var pulled = state.pulledAt || new Date();
    var stale = new Date(pulled.getTime());
    stale.setDate(stale.getDate() + STALE_DAYS);

    $("d-pulled").textContent = fmtDate(pulled);
    $("d-stale").textContent = fmtDate(stale);
    $("d-msv").textContent = nfmt(b.msv) + "/mo";
    $("d-kd").textContent = b.kd;
    $("d-topic").textContent = b.topic;

    $("b-keyword").textContent = b.kw;
    $("b-intent").textContent = b.intentLabel;

    $("b-persona").textContent = b.persona || "No persona entered — copy uses a neutral register.";
    $("b-tone").innerHTML = b.tone.map(function (t) {
      return '<span class="chip">' + esc(t) + "</span>";
    }).join("");

    $("b-title").textContent = b.titleTag;
    $("b-meta").textContent = b.metaDesc;
    $("b-outline-note").textContent = b.outline.length + " sections · built for " + b.intent + " intent";

    $("b-outline").innerHTML = b.outline.map(function (sec) {
      var subs = sec.subs.length
        ? "<ul>" + sec.subs.map(function (s) { return "<li>" + esc(s.t) + "</li>"; }).join("") + "</ul>"
        : "";
      return "<li>" + esc(sec.h) + subs + "</li>";
    }).join("");

    $("b-comp-wrap").innerHTML = b.competitors.length
      ? '<ul class="link-list">' + b.competitors.map(function (c) {
          return "<li><strong>" + esc(c) + "</strong> — capture current H2/H3 structure for this keyword; " +
                 "note what they cover that this outline does not.</li>";
        }).join("") + "</ul>"
      : '<p class="muted empty-note">No competitors entered, so none were analyzed. ' +
        "Add competitors on the first screen to get a per-keyword audit list. " +
        "This tool will not invent competitors or claim a gap it has not seen.</p>";

    $("b-trust").innerHTML = b.trust.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("");
    $("b-checklist").innerHTML = b.checklist.map(function (c, i) {
      var id = "chk-" + b.idx + "-" + i;
      return '<li><input type="checkbox" id="' + id + '"><label for="' + id + '">' + esc(c) + "</label></li>";
    }).join("");

    $("c-h1").textContent = b.kwTitle;
    $("c-body").innerHTML = copyHTML(b).replace(/^<h1>.*?<\/h1>/, "");
    $("cs-words").textContent = nfmt(b.words);
    $("cs-heads").textContent = b.headings;
    $("cs-flags").textContent = b.flagCount;
    $("cs-density").textContent = kwDensity(b) + "%";

    renderScan(b);
    renderGate(b);
    $("dl-status").textContent = "";
  }

  function renderScan(b) {
    var clean = b.lint.length === 0;
    $("ai-scan").classList.toggle("clean", clean);
    $("scan-dot").className = "scan-dot " + (clean ? "ok" : "warn");
    $("scan-title").textContent = clean ? "AI-writing scan: clean" : "AI-writing scan: " + b.lint.length + " to review";
    $("scan-sub").textContent = clean
      ? "No filler phrasing, puffery, negative parallelism or formulaic closers found."
      : "Rewrite these before publishing.";
    $("scan-list").innerHTML = b.lint.map(function (h) {
      return "<li><code>" + esc(h.phrase) + "</code> — " + esc(h.why) + "</li>";
    }).join("");
  }

  function renderGate(b) {
    var gate = $("legal-gate"), cb = $("legal-checkbox");
    if (!b.needsLegal) {
      gate.classList.add("clear");
      $("lg-icon").textContent = "✓";
      $("lg-title").textContent = "No unverified claims in this draft.";
      $("lg-body").textContent = "Nothing is gated, but the editorial checklist still applies.";
      cb.checked = true; cb.disabled = true;
      $("dl-article-btn").disabled = false;
      return;
    }
    cb.disabled = false;
    cb.checked = b.legalCleared;
    gate.classList.toggle("clear", b.legalCleared);
    $("lg-icon").textContent = b.legalCleared ? "✓" : "⚠";
    $("lg-title").textContent = b.legalCleared
      ? "Cleared for publish." : "Review required before publish.";
    $("lg-body").textContent = b.legalCleared
      ? "Draft copy export is unlocked. The [VERIFY] markers still need real sources filled in."
      : "This draft carries " + b.flagCount + " unverified claim" + (b.flagCount === 1 ? "" : "s") +
        ". A human has to source or remove each one — the tool flags them, it cannot clear them.";
    $("dl-article-btn").disabled = !b.legalCleared;
  }

  $("legal-checkbox").addEventListener("change", function () {
    var b = state.briefs[state.activeBrief];
    if (!b || !b.needsLegal) return;
    b.legalCleared = this.checked;
    renderGate(b); renderRail();
  });

  (function wireTabs() {
    var tabs = document.querySelectorAll(".tab");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].addEventListener("click", function () {
        var all = document.querySelectorAll(".tab"), j;
        for (j = 0; j < all.length; j++) all[j].classList.remove("active");
        var panels = document.querySelectorAll(".tab-panel");
        for (j = 0; j < panels.length; j++) panels[j].classList.remove("active");
        this.classList.add("active");
        $("panel-" + this.getAttribute("data-tab")).classList.add("active");
      });
    }
  })();

  $("regen-btn").addEventListener("click", function () {
    state.reruns += 1; state.variant += 1;
    clearTimers();
    goScreen(2);
    renderPipeline();
    for (var i = 0; i < PHASE_A_END; i++) {
      var li = $("pl-" + i);
      if (li) li.classList.add("done");
    }
    $("progress-fill").style.width = Math.round((PHASE_A_END / PIPELINE.length) * 100) + "%";
    startGeneration();
  });

  $("start-over-btn").addEventListener("click", function () {
    clearTimers();
    state.candidates = []; state.cut = []; state.approved = [];
    state.briefs = []; state.activeBrief = 0; state.reruns = 0; state.variant = 0;
    $("gen-stage").classList.remove("hidden");
    $("gate-stage").classList.add("hidden");
    goScreen(1);
    topicInput.focus();
  });

  /* ============================================================
     Export
     ============================================================ */

  function status(msg, isErr) {
    var el = $("dl-status");
    el.textContent = msg;
    el.className = "dl-status" + (isErr ? " err" : "");
    clearTimeout(status._t);
    status._t = setTimeout(function () { el.textContent = ""; el.className = "dl-status"; }, 7000);
  }

  function deliver(bytes, filename, mime) {
    if (window.claude && window.claude.downloads) {
      return window.claude.downloads.save({ filename: filename, data: bytes })
        .then(function () { status("Saved " + filename, false); return true; })
        .catch(function (err) {
          var code = err && err.code;
          if (code === "declined") { status("Download canceled.", false); return false; }
          if (code === "rejected_extension" || code === "extension_not_enabled") return "unsupported";
          if (code === "rate_limited") { status("A download prompt is already open — try again in a moment.", true); return false; }
          status("Couldn't save the file (" + (code || "error") + ").", true);
          return false;
        });
    }
    var blob = new Blob([bytes], { type: mime });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url; a.download = filename;
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
    status("Downloaded " + filename, false);
    return Promise.resolve(true);
  }

  var DOCX_MIME = "application/vnd.openxmlformats-officedocument.wordprocessingml.document";

  $("dl-brief-btn").addEventListener("click", function () {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    status("Building .docx…", false);
    docxFile(briefDocxBody(b)).then(function (bytes) {
      return deliver(bytes, "brief_" + slug(b.kw) + ".docx", DOCX_MIME);
    });
  });

  $("dl-article-btn").addEventListener("click", function () {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    if (b.needsLegal && !b.legalCleared) {
      status("Blocked: this draft still needs review clearance.", true);
      return;
    }
    status("Building .docx…", false);
    docxFile(copyDocxBody(b)).then(function (bytes) {
      return deliver(bytes, "copy_" + slug(b.kw) + ".docx", DOCX_MIME);
    });
  });

  $("export-all-btn").addEventListener("click", function () {
    if (!state.briefs.length) return;
    status("Building " + (state.briefs.length * 2) + " .docx files…", false);

    var jobs = [];
    state.briefs.forEach(function (b, i) {
      var n = String(i + 1);
      if (n.length < 2) n = "0" + n;
      jobs.push(docxFile(briefDocxBody(b)).then(function (d) {
        return { name: "briefs/" + n + "_" + slug(b.kw) + "_brief.docx", data: d };
      }));
      jobs.push(docxFile(copyDocxBody(b)).then(function (d) {
        return { name: "draft-copy/" + n + "_" + slug(b.kw) + "_copy.docx", data: d };
      }));
    });

    jobs.push(Promise.resolve({ name: "README.txt", data: utf8(readmeText()) }));

    Promise.all(jobs).then(function (entries) {
      return makeZip(entries).then(function (zip) {
        var name = "seo-briefs_" + state.briefs.length + "_" +
          new Date().toISOString().slice(0, 10) + ".zip";
        return deliver(zip, name, "application/zip").then(function (res) {
          if (res === "unsupported") {
            // .zip isn't permitted in this viewer — fall back to one combined .docx.
            status("Zip not permitted here — building a single combined .docx instead…", false);
            var body = state.briefs.map(function (b, i) {
              return (i ? '<w:p><w:r><w:br w:type="page"/></w:r></w:p>' : "") +
                briefDocxBody(b) + '<w:p><w:r><w:br w:type="page"/></w:r></w:p>' + copyDocxBody(b);
            }).join("");
            return docxFile(body).then(function (d) {
              return deliver(d, "seo-briefs_" + state.briefs.length + ".docx", DOCX_MIME);
            });
          }
        });
      });
    }).catch(function () {
      status("Export failed while building the package.", true);
    });
  });

  function readmeText() {
    var lines = [];
    lines.push("SEO/GEO CONTENT BRIEF SET");
    lines.push("Generated " + fmtDate(state.pulledAt || new Date()));
    lines.push("");
    lines.push("Seed topics:  " + state.topics.join(", "));
    if (state.pinned.length) lines.push("Pinned keywords: " + state.pinned.join(", "));
    lines.push("Competitors:  " + (state.competitors.length ? state.competitors.join(", ") : "none entered — none analyzed"));
    lines.push("Persona:      " + (state.persona || "none entered"));
    lines.push("");
    lines.push("CONTENTS");
    lines.push("  briefs/       one .docx content brief per approved keyword");
    lines.push("  draft-copy/   one .docx long-form draft per approved keyword");
    lines.push("");
    lines.push("BEFORE PUBLISHING");
    lines.push("  1. Every [VERIFY] marker is an open question, not a fact. Source it or cut it.");
    lines.push("  2. Cite 2-3 authoritative primary sources per article.");
    lines.push("  3. Send anything with a regulated or high-stakes claim for compliance review.");
    lines.push("  4. Search volume and difficulty here are modelled estimates, not a live Ahrefs pull.");
    lines.push("  5. Competitor lists contain only the competitors entered by the user.");
    lines.push("");
    lines.push("BRIEFS IN THIS SET");
    state.briefs.forEach(function (b, i) {
      lines.push("  " + (i + 1) + ". " + b.kw + "  (" + nfmt(b.msv) + "/mo, KD " + b.kd +
        ", " + b.words + " words, " + b.flagCount + " flags)");
    });
    return lines.join("\n");
  }

  /* ---------------- init ---------------- */
  renderTopics(); renderPinned(); renderComps();
  topicInput.focus();
})();
