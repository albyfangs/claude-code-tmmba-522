/* ============================================================
   SEO/GEO Content Brief Studio — v2
   ------------------------------------------------------------
   Flow: seed topics + keywords + competitors + persona
         -> keyword research -> HUMAN APPROVAL GATE
         -> brief generation -> review -> .docx / .zip export

   v2 design rules:
   · No industry is assumed. Every keyword, outline and heading is
     derived from what the user typed. There is no built-in topic
     bank and no default vertical.
   · Competitors are analyzed only if the user names them. The tool
     never invents a competitor or claims a content gap.
   · Every brief gets its own outline. Section archetypes, heading
     phrasings and subsection sets are selected from a seeded RNG
     keyed to the keyword, so no two briefs share a structure.
   · Draft copy is written against the "signs of AI writing"
     guidance and then linted for those signs in the UI.
   ============================================================ */
(function () {
  "use strict";

  /* ---------------- config ---------------- */

  var MAX_TOPICS = 10;
  var MAX_COMPETITORS = 10;
  var MAX_APPROVED = 10;
  var MIN_MSV = 2000;
  var MAX_KD = 60;
  var STALE_DAYS = 14;
  var MANUAL_HRS_PER_BRIEF = 3;
  var TOOL_HRS_PER_BRIEF = 0.75;
  var STEP_MS = 600;
  var MIN_WORDS = 1500;   // long-form floor for every draft

  var PIPELINE = [
    { t: "Expand seed topics into keyword candidates", tool: "Keyword expansion", aut: "retrieve", who: "ai",
      sub: "Building candidate queries from your topics — no industry assumed…" },
    { t: "Estimate volume & competition",              tool: "Volume model",      aut: "retrieve", who: "ai",
      sub: "Attaching estimated monthly volume and difficulty to each candidate…" },
    { t: "Filter by volume & competition",             tool: "Mechanical filter", aut: "act",      who: "ai",
      sub: "Applying fixed thresholds: volume ≥ 2,000/mo, difficulty ≤ 60…" },
    { t: "Rank by opportunity",                        tool: "Opportunity score", aut: "recommend", who: "ai",
      sub: "Ordering the shortlist so the strongest candidates surface first…" },

    { t: "Map competitor coverage",                    tool: "Your competitor list", aut: "recommend", who: "both",
      sub: "Assigning review targets from the competitors you entered…" },
    { t: "Derive a unique outline per keyword",        tool: "Outline builder",   aut: "recommend", who: "ai",
      sub: "Selecting section structure from search intent — different for every keyword…" },
    { t: "Apply your voice & audience",                tool: "Persona",           aut: "recommend", who: "both",
      sub: "Shaping register and phrasing against the persona you described…" },
    { t: "Draft copy",                                 tool: "Draft generator",   aut: "recommend", who: "both",
      sub: "Writing long-form draft copy in your voice, section by section…" },
    { t: "Flag unverifiable claims",                   tool: "Claim scanner",     aut: "recommend", who: "both",
      sub: "Any claim not traceable to your inputs is flagged, never stated as fact…" },
    { t: "Scan for signs of AI writing",               tool: "Style linter",      aut: "recommend", who: "ai",
      sub: "Checking for filler phrasing, puffery and formulaic structure…" },
    { t: "Compile briefs & export package",            tool: ".docx / .zip",      aut: "recommend", who: "ai",
      sub: "Assembling the brief set for your review…" }
  ];
  var PHASE_A_END = 4;

  var AUT_LABEL = { retrieve: "Retrieve", act: "Act", recommend: "Recommend" };
  var WHO_LABEL = { ai: "AI", both: "AI + Human" };

  var TRUST_SIGNALS = [
    "Named subject-matter expert quote, with role and credential",
    "Author byline plus a reviewer credit and review date",
    "First-hand or original data you can point to",
    "Visible last-updated date and a short methodology note"
  ];
  var CHECKLIST = [
    "Includes at least one named, cited data point",
    "Cites 2–3 authoritative primary sources",
    "Carries a clear expertise or first-hand experience signal",
    "Author bio and reviewer credentials present",
    "Every figure added traces to a named, dated source",
    "Regulated or high-stakes claims sent for compliance review"
  ];

  /* ============================================================
     Signs of AI writing — lexicon and linter
     ------------------------------------------------------------
     Drawn from the Wikipedia "Signs of AI writing" guidance:
     filler vocabulary, negative parallelism, puffery, vague
     attribution and formulaic section closers. The generator
     avoids these; the linter proves it rather than asserting it.
     ============================================================ */

  var AI_TELLS = [
    { re: /\b(delve|delving)\b/i,                       why: "Filler verb flagged as a common AI tell" },
    { re: /\b(tapestry|landscape of|realm of)\b/i,      why: "Stock metaphor" },
    { re: /\bstands? as a testament\b/i,                why: "Formulaic praise construction" },
    { re: /\bit'?s not just [^.,;]{2,40}, it'?s\b/i,    why: "Negative parallelism (\"not just X, it's Y\")" },
    { re: /\bnot only [^.,;]{2,40} but also\b/i,        why: "Negative parallelism (\"not only… but also\")" },
    { re: /\b(crucial|vital|pivotal|paramount)\b/i,     why: "Inflated importance adjective" },
    { re: /\b(seamless|robust|cutting-edge|state-of-the-art|game-chang)/i, why: "Marketing puffery" },
    { re: /\b(leverage|utilize)\b/i,                    why: "Corporate filler verb — prefer \"use\"" },
    { re: /\b(navigating|navigate) the\b/i,             why: "Stock metaphor" },
    { re: /\b(furthermore|moreover|additionally)\b/i,   why: "Formulaic connective" },
    { re: /\bin conclusion\b/i,                         why: "Formulaic closer" },
    { re: /\bit'?s (important|worth) (to note|noting)\b/i, why: "Empty hedging phrase" },
    { re: /\b(experts say|studies show|many believe|it is widely (regarded|believed))\b/i,
      why: "Vague attribution with no named source" },
    { re: /\b(breathtaking|stunning|world-class|renowned|must-see)\b/i, why: "Puffery adjective" },
    { re: /\bever-(evolving|changing|growing)\b/i,      why: "Stock intensifier" },
    { re: /\bplays? a (significant|key|major) role\b/i, why: "Vague filler claim" },
    { re: /\bwhen it comes to\b/i,                      why: "Filler transition" },
    { re: /\bunlock(ing)? the (power|potential|secrets)\b/i, why: "Marketing cliché" },
    { re: /\bdive (deep|into)\b/i,                      why: "Stock metaphor" },
    { re: /\bin today'?s (fast-paced|digital|modern) world\b/i, why: "Formulaic opener" }
  ];

  function lintCopy(plainText) {
    var hits = [];
    AI_TELLS.forEach(function (rule) {
      var m = plainText.match(rule.re);
      if (m) hits.push({ phrase: m[0], why: rule.why });
    });
    return hits;
  }

  /* ---------------- state ---------------- */

  var state = {
    topics: [], pinned: [], competitors: [], persona: "",
    candidates: [], cut: [], approved: [], briefs: [],
    activeBrief: 0, reruns: 0, variant: 0, pulledAt: null
  };
  var timers = [];

  /* ---------------- helpers ---------------- */

  function $(id) { return document.getElementById(id); }
  function esc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function xesc(s) {
    return String(s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&apos;" }[c];
    });
  }
  function nfmt(n) { return n.toLocaleString("en-US"); }
  function fmtDate(d) {
    return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
  }
  function hash(s) {
    var h = 2166136261 >>> 0, i;
    for (i = 0; i < s.length; i++) {
      h ^= s.charCodeAt(i);
      h = Math.imul(h, 16777619) >>> 0;
    }
    return h >>> 0;
  }
  function mulberry(seed) {
    var a = seed >>> 0;
    return function () {
      a = (a + 0x6D2B79F5) >>> 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }
  function pick(arr, rnd) { return arr[Math.floor(rnd() * arr.length) % arr.length]; }
  function shuffle(arr, rnd) {
    var a = arr.slice(), i, j, t;
    for (i = a.length - 1; i > 0; i--) {
      j = Math.floor(rnd() * (i + 1));
      t = a[i]; a[i] = a[j]; a[j] = t;
    }
    return a;
  }
  var MINOR = /^(a|an|the|of|to|vs|in|on|is|for|and|or|with|at|by)$/i;
  function titleCase(s) {
    var first = true;
    return String(s).split(/(\s+)/).map(function (w) {
      if (!w.trim()) return w;
      if (w.length > 1 && w === w.toUpperCase() && /[A-Z]/.test(w)) { first = false; return w; }
      if (!first && MINOR.test(w)) return w.toLowerCase();
      first = false;
      return w.charAt(0).toUpperCase() + w.slice(1);
    }).join("");
  }
  function sentenceCase(s) {
    var t = String(s).trim();
    return t.charAt(0).toUpperCase() + t.slice(1);
  }
  function clearTimers() { timers.forEach(clearTimeout); timers = []; }
  function later(fn, ms) { var t = setTimeout(fn, ms); timers.push(t); return t; }
  function slug(s) {
    return String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "").slice(0, 50) || "item";
  }

  /* ============================================================
     Keyword expansion — domain neutral
     ============================================================ */

  var MODIFIERS = [
    { pat: "how does {t} work",        intent: "informational" },
    { pat: "what is {t}",              intent: "informational" },
    { pat: "{t} explained",            intent: "informational" },
    { pat: "how to choose {t}",        intent: "commercial" },
    { pat: "best {t}",                 intent: "commercial" },
    { pat: "{t} comparison",           intent: "comparison" },
    { pat: "{t} alternatives",         intent: "comparison" },
    { pat: "{t} cost",                 intent: "pricing" },
    { pat: "{t} pricing",              intent: "pricing" },
    { pat: "{t} requirements",         intent: "informational" },
    { pat: "{t} checklist",            intent: "tutorial" },
    { pat: "how to get started with {t}", intent: "tutorial" },
    { pat: "{t} best practices",       intent: "tutorial" },
    { pat: "{t} mistakes",             intent: "informational" },
    { pat: "{t} for beginners",        intent: "tutorial" },
    { pat: "{t} benefits",             intent: "informational" },
    { pat: "is {t} worth it",          intent: "commercial" },
    { pat: "{t} examples",             intent: "informational" }
  ];

  function detectIntent(kw) {
    var k = " " + kw.toLowerCase() + " ";
    if (/\b(vs|versus)\b/.test(k) || /\balternatives?\b/.test(k) || /\bcomparison\b/.test(k)) return "comparison";
    if (/\b(cost|costs|pricing|price|cheap|budget|fees?)\b/.test(k)) return "pricing";
    if (/\bhow to\b/.test(k) || /\b(checklist|steps?|guide|started|setup|set up|tutorial)\b/.test(k)) return "tutorial";
    if (/\b(best|top|review|reviews|worth it|choose|choosing)\b/.test(k)) return "commercial";
    if (/^\s*(how|what|why|when|where|can|is|does|do|should)\b/.test(k)) return "informational";
    return "informational";
  }

  var INTENT_LABEL = {
    informational: "Informational — the reader wants to understand. Answer directly in the opening, then build depth.",
    comparison:    "Comparison — the reader is choosing between options. Lead with a decision aid, not a definition.",
    pricing:       "Pricing — the reader wants numbers. Every figure needs a source and a date.",
    tutorial:      "How-to — the reader wants to act. Sequence matters more than background.",
    commercial:    "Commercial investigation — the reader is close to a decision and is comparing on criteria."
  };

  // Volume and difficulty are modelled, not fetched. Derived from a hash of the
  // phrase so a given keyword is stable across runs and across sessions.
  function estimate(kw) {
    var h = hash(kw);
    var rnd = mulberry(h);
    var words = kw.split(/\s+/).length;
    // Longer phrases trend to lower volume and lower competition.
    var base = [40500, 27100, 18100, 12100, 9900, 8100, 6600, 5400, 3600, 2400, 1600, 1000];
    var idx = Math.min(base.length - 1, Math.max(0, Math.floor(rnd() * 6) + (words - 2)));
    var msv = base[idx];
    var kd = Math.max(6, Math.min(92, Math.round(18 + rnd() * 55 - (words - 2) * 5)));
    return { msv: msv, kd: kd };
  }

  function oppScore(msv, kd) {
    var vol = Math.log10(Math.max(msv, 10)) / Math.log10(500000);
    return Math.max(1, Math.round(Math.min(vol, 1) * (1 - kd / 100) * 100));
  }

  function buildCandidates() {
    var seen = {}, all = [];

    state.topics.forEach(function (topic) {
      var t = topic.toLowerCase().trim();
      var rnd = mulberry(hash(t));
      // A different slice of modifiers per topic, so topics don't all
      // produce the same shaped keyword set.
      var mods = shuffle(MODIFIERS, rnd).slice(0, 6);
      // The bare topic is always a candidate.
      var rows = [{ kw: t, intent: detectIntent(t) }];
      mods.forEach(function (m) {
        rows.push({ kw: m.pat.replace("{t}", t), intent: m.intent });
      });
      rows.forEach(function (r) {
        var key = r.kw.toLowerCase();
        if (seen[key]) return;
        seen[key] = true;
        var e = estimate(r.kw);
        all.push({
          kw: r.kw, msv: e.msv, kd: e.kd, opp: oppScore(e.msv, e.kd),
          topic: topic, intent: r.intent, pinned: false
        });
      });
    });

    state.pinned.forEach(function (kw) {
      var key = kw.toLowerCase();
      if (seen[key]) {
        all.forEach(function (r) { if (r.kw.toLowerCase() === key) r.pinned = true; });
        return;
      }
      seen[key] = true;
      var e = estimate(kw);
      all.push({
        kw: kw, msv: e.msv, kd: e.kd, opp: oppScore(e.msv, e.kd),
        topic: nearestTopic(kw), intent: detectIntent(kw), pinned: true
      });
    });

    var kept = [], cut = [];
    all.forEach(function (r) {
      if (r.pinned || (r.msv >= MIN_MSV && r.kd <= MAX_KD)) kept.push(r);
      else cut.push(r);
    });
    kept.sort(function (a, b) { return b.opp - a.opp || b.msv - a.msv; });
    cut.sort(function (a, b) { return b.msv - a.msv; });

    state.candidates = kept;
    state.cut = cut;
  }

  function nearestTopic(kw) {
    var k = kw.toLowerCase(), best = state.topics[0] || kw;
    state.topics.forEach(function (t) {
      if (k.indexOf(t.toLowerCase()) !== -1) best = t;
    });
    return best;
  }

  /* ============================================================
     Competitors — only what the user supplied
     ============================================================ */

  function competitorsFor(kw) {
    if (!state.competitors.length) return [];
    var rnd = mulberry(hash("c:" + kw));
    var n = Math.min(state.competitors.length, 2 + Math.floor(rnd() * 2));
    return shuffle(state.competitors, rnd).slice(0, n);
  }

  /* ============================================================
     Persona / tone
     ============================================================ */

  function readPersona(text) {
    var p = (text || "").toLowerCase(), tags = [];
    if (/plain|simple|no jargon|accessible|clear|straightforward/.test(p)) tags.push("plain-spoken");
    if (/expert|technical|advanced|practitioner|specialist|in-depth/.test(p)) tags.push("technical");
    if (/casual|friendly|conversational|warm|approachable|human/.test(p)) tags.push("conversational");
    if (/formal|professional|authoritative|serious|corporate/.test(p)) tags.push("authoritative");
    if (/concise|brief|short|punchy|tight|skimmable/.test(p)) tags.push("concise");
    if (/data|evidence|research|numbers|proof|benchmark/.test(p)) tags.push("evidence-led");
    if (/empath|supportive|reassur|patient|beginner/.test(p)) tags.push("supportive");
    if (/no hype|no fluff|avoid hype|without hype|no buzzwords/.test(p)) tags.push("hype-free");
    if (/practical|actionable|hands-on|concrete|example/.test(p)) tags.push("practical");
    return tags;
  }

  /* ============================================================
     Outline archetypes — every brief gets its own structure
     ============================================================ */

  function T(ctx) { return ctx.topicT; }
  function K(ctx) { return ctx.kwT; }

  // Section archetypes. Each sub carries its own prose so an H3 and the
  // paragraph under it always match. Nothing here asserts a specific figure,
  // date or quotation: the tool has no knowledge of the user's industry, so it
  // writes what is true structurally and leaves the specifics to the writer.
  var ARCHETYPES = {
    quickanswer: {
      heads: ["The short answer", "Answer first", "The quick version", "Start here"],
      subs: [],
      paras: function (c, r) {
        return [
          [ { t: "The honest answer about " }, { t: c.kw, kw: true },
            { t: " is that it depends on a small number of things, and most people can work out which ones apply to them in a few minutes. The factors that matter are your starting position, what you are trying to get out of it, and how much time you can give it before you need a result." } ],
          [ { t: "The rest of this page works through those in order: what it involves, who it suits, what it tends to cost, where people run into trouble, and how to tell whether it is working. If you only read one section, read the one that matches whichever of those you are least sure about." } ]
        ];
      }
    },
    definition: {
      heads: ["What {K} actually means", "Defining {K}", "{K}, in plain terms", "What we mean by {K}"],
      subs: [
        { t: "Where the term comes from", p: "The phrase has drifted from how it was first used, and different parts of the field now apply it to slightly different things. That drift explains why two otherwise reliable sources can seem to contradict each other on the basics." },
        { t: "What it is not", p: "It is often confused with adjacent ideas that share vocabulary but behave differently in practice. The distinction usually only matters once you are committing time or money, which is exactly when it is most expensive to have got it wrong." },
        { t: "Terms people confuse with it", p: "A handful of neighbouring terms get used interchangeably in marketing material even though they describe meaningfully different arrangements. If a description feels like it is dodging specifics, that is often why." },
        { t: "How practitioners use the word", p: "People who work with this day to day tend to use the term more narrowly than the general usage suggests. When you are talking to someone experienced, it is worth checking which definition they are working from before assuming you agree." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "Stripped of jargon, " + c.topic + " describes a way of handling something deliberately rather than leaving it to chance. The formal definitions vary in wording, but they converge on that idea, and most of the variation you will read is presentation rather than substance." } ],
          [ { t: "The term gets used loosely, and that causes real problems once you start comparing options. Two providers can describe the same arrangement in different language, or use one label for setups that behave quite differently in daily use. Checking what a particular offer actually includes will tell you more than matching the name on the tin." } ]
        ];
      }
    },
    howitworks: {
      heads: ["How {T} works", "The mechanics", "What actually happens", "How this works in practice"],
      subs: [
        { t: "The moving parts", p: "There are fewer components than the surrounding marketing implies. Once you can name them, most of the apparent complexity turns out to be different vendors describing the same handful of things in their own vocabulary." },
        { t: "What happens first", p: "The opening stage sets constraints that are awkward to change later, which is why it repays more thought than it usually gets. People tend to rush it because it feels administrative rather than consequential." },
        { t: "Where it usually stalls", p: "Progress most often stops while waiting on someone else, not on any technical obstacle. Knowing that in advance changes how you sequence things and who you tell before you start rather than after." },
        { t: "What changes the outcome", p: "A small number of decisions account for most of the variation in how this turns out. The rest is detail that feels important while you are choosing and stops mattering shortly afterwards." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "The mechanics of " + c.topic + " are more straightforward than the surrounding material suggests. A few inputs go in, a defined process runs, and the result depends mostly on how well the inputs were prepared rather than on anything mysterious happening in the middle." } ],
          [ { t: "Not all of it is under your control. Part of the outcome is set by circumstances you cannot change, and part comes down to choices you make early and then live with for a while. Knowing which is which tells you where effort is worth spending and where you are better off accepting the default and moving on." } ]
        ];
      }
    },
    whofor: {
      heads: ["Who this is for", "Who benefits most", "Is this right for you?", "Who should care"],
      subs: [
        { t: "A good fit", p: "This tends to suit people who have a clear reason for doing it and enough runway to see it through. A specific problem you can describe in a sentence is usually a sign you are in the right place." },
        { t: "A poor fit", p: "If you are doing this because it seems like the responsible thing rather than because something is actually wrong, the effort rarely pays back. That is a legitimate conclusion to reach and a cheap one to reach early." },
        { t: "Edge cases", p: "Unusual situations are where general guidance breaks down fastest. If your circumstances differ from the standard case in a way that feels material, it probably is, and it is worth asking someone rather than extrapolating." },
        { t: "When to revisit", p: "Circumstances change, and a decision that was right a year ago can quietly stop being right without anything obvious happening. Setting a rough date to look again saves you from noticing by accident." }
      ],
      paras: function (c, r) {
        return [
          [ { t: sentenceCase(c.topic) + " suits some situations considerably better than others, and the difference is usually about circumstances rather than sophistication. It tends to work well when the problem is specific, the timing is not urgent, and someone has clear ownership of it." } ],
          [ { t: "It is a weaker fit if your situation is about to change, if you are solving something that only resembles this on the surface, or if nobody has the time to see it through. Plenty of people work through the question and conclude it is not for them, which is a perfectly good outcome." } ]
        ];
      }
    },
    requirements: {
      heads: ["What you need first", "Before you start", "What to have in place", "Prerequisites"],
      subs: [
        { t: "The essentials", p: "A short list of things genuinely has to be in place before anything else can happen. Gathering them first is dull, and it is still faster than stopping partway through to chase something down." },
        { t: "Useful but optional", p: "Several things get presented as requirements when they are really conveniences. Knowing which is which stops you from delaying over something that was never actually blocking you." },
        { t: "Common blockers", p: "Most delays trace back to a small number of predictable gaps rather than anything unusual. They are easy to check for in advance and awkward to resolve once you are already underway." },
        { t: "What you can skip", p: "Some conventional preparation adds little beyond reassurance. If you cannot explain what a step is for, it is worth asking whether it is there out of habit." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "Before starting with " + c.topic + ", it helps to have a clear picture of what you currently have and what you are missing. Most of the preparation is gathering information you already possess but have never had in one place, which is why it takes less time than people expect once they begin." } ],
          [ { t: "Some of what gets listed as a requirement is really convention. If you cannot meet something on the list, it is worth asking whether it is a genuine constraint or simply the way most people happen to do it. The answer differs more often than you would think, and asking costs nothing." } ]
        ];
      }
    },
    process: {
      heads: ["Step by step", "How to work through it", "The process, start to finish", "Doing it in order"],
      subs: [
        { t: "Getting set up", p: "The opening stage is mostly preparation and tends to go faster than expected. The temptation is to skim it, and skimming it is what causes the avoidable problems later." },
        { t: "The main sequence", p: "The middle is where most of the elapsed time goes, largely because it involves waiting rather than working. Building slack in here rather than at the end will save you some frustration." },
        { t: "Where people get stuck", p: "Sticking points cluster around handoffs, where responsibility moves from one person to another and nobody is quite sure whose turn it is. Naming the owner at each handoff prevents most of it." },
        { t: "Finishing up", p: "The final stage is short but easy to leave incomplete, because by then the interesting part is over. A brief check against what you set out to do is usually enough to catch anything left hanging." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "Working through " + c.topic + " follows a fairly predictable sequence, and each stage depends on the one before it. Doing things out of order is possible but usually means redoing something, so the order is worth respecting even when a later step looks more appealing." } ],
          [ { t: "Timing varies, though the stages that take longest are rarely the ones people brace for. Setup tends to be quicker than expected and the middle slower, mostly because that is where you are waiting on other people rather than on your own effort." } ]
        ];
      }
    },
    criteria: {
      heads: ["How to evaluate the options", "What to look for", "The criteria that matter", "How to judge {T}"],
      subs: [
        { t: "What to weight heavily", p: "One or two criteria usually decide the outcome, and they are rarely the ones given the most space in a comparison table. Working out which they are for your situation is most of the job." },
        { t: "What matters less than it seems", p: "Feature counts and long capability lists are easy to compare and weakly related to whether you will be satisfied. They get emphasised precisely because they are easy to compare." },
        { t: "How to weigh it for your case", p: "The right weighting depends on what you are optimising for, and being explicit about that first makes the comparison much shorter. Most people can name it in a sentence once asked directly." },
        { t: "Questions worth asking", p: "A few direct questions will tell you more than an afternoon of reading. The useful ones tend to be about what happens when something goes wrong rather than about what happens when everything works." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "Not every factor in choosing " + c.topic + " carries equal weight, and treating them as though they do is the most common way people end up with something that technically fits and practically does not. A small number of criteria will decide this, and the rest are detail." } ],
          [ { t: "Work out which criterion dominates for you before comparing anything, because the comparison gets much shorter once you have. A chart with twenty rows is usually a sign that nobody wanted to commit to saying which three actually matter." } ]
        ];
      }
    },
    comparison: {
      heads: ["How the options compare", "Side by side", "Weighing the alternatives", "{T} against the alternatives"],
      subs: [
        { t: "Where each option wins", p: "Every serious option is genuinely better at something, or it would not still be around. Finding what that is tells you who it was designed for and whether that resembles you." },
        { t: "Where each falls short", p: "The weaknesses are harder to find because nobody advertises them, but they are usually the mirror image of the strengths. Something optimised for flexibility tends to cost simplicity, and the reverse." },
        { t: "The honest trade-off", p: "There is no option here that wins on every axis, and any comparison suggesting otherwise is selling something. The useful question is which compromise you can live with." },
        { t: "Which to pick when", p: "The answer changes with circumstances more than with quality. A choice that suits a small team under time pressure is often the wrong one for a larger group with a longer horizon." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "There are usually several credible ways to approach " + c.topic + ", and none of them wins outright. Each is stronger on some dimension and pays for it somewhere else, which is why the comparison depends so heavily on what you personally need." } ],
          [ { t: "Which one suits you depends less on the feature lists than on what you are optimising for. If cost is the binding constraint, one answer follows; if time or flexibility matters more, a different one does. Deciding that first turns a long comparison into a short one." } ]
        ];
      }
    },
    costs: {
      heads: ["What it costs", "Pricing and budget", "The real cost", "Costs to plan for"],
      subs: [
        { t: "What you pay upfront", p: "The visible price is the easiest number to find and the least useful on its own. It is worth establishing early mainly so you can set it aside and look at the rest." },
        { t: "Ongoing costs", p: "Recurring costs usually outweigh the initial outlay over any reasonable horizon, and they are the ones that quietly grow. Working out the annual figure is a more honest basis for comparison." },
        { t: "Costs people forget", p: "Time is the cost that never appears on a quote and often dominates. Somebody has to run this, and their hours are real even when they are not invoiced." },
        { t: "Reducing the total", p: "Most of the savings available come from scoping rather than negotiating. Deciding not to do something is reliably cheaper than getting a discount on doing it." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "The cost of " + c.topic + " has two parts: what you pay, and what it takes to run. The second is routinely underestimated because it does not arrive as an invoice, and it is usually the part that determines whether this feels worthwhile a year in." } ],
          [ { t: "Prices in most areas move, so treat any figure you find, including one from a vendor, as something to confirm rather than rely on. Ask what is included, what is billed separately, and what changes when you grow — the answers to those three questions explain most surprises." } ]
        ];
      }
    },
    mistakes: {
      heads: ["Where people go wrong", "Common mistakes", "What to avoid", "Mistakes worth knowing about"],
      subs: [
        { t: "The expensive mistake", p: "The costly errors are rarely dramatic. They are ordinary decisions that were reasonable given what was known at the time and turn out badly for reasons that were foreseeable with slightly more information." },
        { t: "The easy mistake", p: "Skipping the preparation is the most common one, and it is common because preparation feels like delay. It is the cheapest hour you will spend on this." },
        { t: "The one nobody warns you about", p: "Under-communicating tends to cause more trouble than any technical misstep. People downstream make their own assumptions in the absence of information, and unwinding those takes longer than the original conversation would have." },
        { t: "How to recover", p: "Most missteps here are recoverable if caught early, and expensive if left. The recovery is almost always easier than the anticipation of it, which is why people delay longer than they should." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "The mistakes that cost most with " + c.topic + " share a pattern: they feel like sensible decisions at the time, and the consequences surface later, by which point undoing them means unwinding everything built on top." } ],
          [ { t: "The warning sign is usually that something feels slightly off before anything visibly breaks. People tend to explain that feeling away and press on. Stopping to check when it appears costs an afternoon; ignoring it can cost considerably more." } ]
        ];
      }
    },
    timeline: {
      heads: ["How long it takes", "Timelines and expectations", "What the schedule looks like"],
      subs: [
        { t: "A typical timeline", p: "The spread between a fast run and a slow one is wide, and preparation accounts for most of the difference. People who gather things in advance consistently land at the quicker end." },
        { t: "What speeds it up", p: "Responsiveness matters more than effort. Turning things around within a day rather than a week compounds across every handoff and shortens the whole thing noticeably." },
        { t: "What causes delays", p: "Waiting on other people is the usual culprit, and it is largely predictable. Knowing a particular pause is normal rather than a sign of trouble makes it much easier to plan around than to chase." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "How long " + c.topic + " takes depends mostly on how prepared you were before starting, which is why published timelines vary so widely. The work itself is fairly consistent; the waiting is not." } ],
          [ { t: "Some delays you control and some you do not. Separating the two early tells you where pushing will help and where it will only add friction to a process that was always going to take as long as it takes." } ]
        ];
      }
    },
    examples: {
      heads: ["What this looks like in practice", "A worked example", "In practice", "A concrete example"],
      subs: [
        { t: "A straightforward case", p: "The uncomplicated version is worth understanding first, because it is the baseline everything else deviates from. Most situations are a variation on it rather than something genuinely different." },
        { t: "A harder case", p: "Complications usually come from constraints outside the process itself: timing, other people, or a decision made earlier that cannot easily be revisited. The process rarely breaks on its own." },
        { t: "What the numbers looked like", p: "Working through an actual example with real figures makes the trade-offs concrete in a way that description does not. It is also where assumptions that sounded reasonable get tested." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "Descriptions of " + c.topic + " tend to stay abstract, which makes them hard to act on. Working through an actual case, including the parts that did not go smoothly, gives you a much better sense of what to expect than another round of explanation." } ],
          [ { t: "Published examples skew heavily toward things going well, so treat a tidy account with some scepticism. The complications are the useful part, since they are what you are most likely to encounter yourself." } ]
        ];
      }
    },
    risks: {
      heads: ["Risks and trade-offs", "What can go wrong", "The downside worth knowing"],
      subs: [
        { t: "The main risk", p: "The significant risk is usually committing to something before you understand it well enough to judge whether it fits. That is a timing problem more than a judgement problem." },
        { t: "Who carries it", p: "Responsibility when things go wrong is not always where you would assume, and it is often set out in terms nobody reads until they need to. Checking once, early, is cheap." },
        { t: "Limiting your exposure", p: "Starting small and expanding limits the downside more effectively than any amount of upfront analysis. It also produces information that analysis alone cannot." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "Every approach to " + c.topic + " involves a trade-off, and anyone presenting one with no downside is selling something. The useful exercise is naming what you are giving up so you can decide whether you mind." } ],
          [ { t: "Worth establishing who absorbs the cost when something goes wrong, because that question tends to be the one people are circling without asking, and it is the one most descriptions leave unanswered." } ]
        ];
      }
    },
    metrics: {
      heads: ["How to tell if it is working", "Knowing whether it worked", "What to track"],
      subs: [
        { t: "The measure that matters", p: "One measure you check regularly beats a dashboard you look at once. If you cannot say what number would tell you this was working, that is worth resolving before starting." },
        { t: "Early signals", p: "Leading indicators show up well before the outcome does, which is what makes them useful. They are also noisier, so treat a single reading as information rather than as a verdict." },
        { t: "What not to bother measuring", p: "Plenty of numbers move around without telling you anything actionable. Tracking too many feels rigorous and mostly generates work and reasons to keep adjusting things that were fine." }
      ],
      paras: function (c, r) {
        return [
          [ { t: "Deciding in advance what would tell you " + c.topic + " is working saves a lot of second-guessing later. The specific measure matters less than picking one and checking it on a schedule rather than whenever you happen to wonder." } ],
          [ { t: "Give it long enough to mean something before drawing conclusions. Most things here look worse before they look better, and reacting to the early dip is how people abandon something that was about to start working." } ]
        ];
      }
    },
    expert: {
      heads: ["A practitioner's view", "Expert perspective", "From someone who does this"],
      subs: [],
      paras: function (c, r) {
        return [
          [ { t: "People who work with " + c.topic + " regularly tend to describe the same pattern: the decision itself matters less than following through on it consistently. Most of the difference between a good outcome and a mediocre one shows up in the months afterwards rather than in the choice." } ],
          [ { t: "The other thing experienced practitioners tend to say is that the common problems are common for a reason, and being unremarkable does not make them less costly. Most of what goes wrong has gone wrong many times before and is well understood by anyone who has done this more than once." } ]
        ];
      }
    },
    faq: {
      heads: ["Questions people actually ask", "Common questions", "Questions worth answering"],
      subs: [],
      paras: function (c, r) { return []; }
    },
    nextsteps: {
      heads: ["Where to go from here", "Your next step", "What to do next"],
      subs: [],
      paras: function (c, r) {
        return [
          [ { t: "If " + c.topic + " looks like the right direction, the useful next step is the smallest one that produces real information: a conversation, a trial, or writing down what you actually need. That beats more reading, which at this point is mostly a way of postponing the decision." } ]
        ];
      }
    }
  };

  // Section sets per intent. The anchors always appear; the rest is a pool the
  // seeded RNG draws from, so structure varies keyword to keyword.
  var INTENT_PLAN = {
    informational: { anchor: ["quickanswer", "definition"], pool: ["howitworks", "whofor", "examples", "mistakes", "risks", "criteria", "timeline"] },
    comparison:    { anchor: ["quickanswer", "criteria"],   pool: ["comparison", "costs", "whofor", "mistakes", "examples", "risks"] },
    pricing:       { anchor: ["quickanswer", "costs"],      pool: ["criteria", "comparison", "mistakes", "whofor", "metrics", "risks"] },
    tutorial:      { anchor: ["quickanswer", "requirements"], pool: ["process", "mistakes", "timeline", "examples", "metrics", "risks"] },
    commercial:    { anchor: ["quickanswer", "criteria"],   pool: ["comparison", "costs", "mistakes", "examples", "whofor", "metrics"] }
  };

  function buildOutline(ctx) {
    var rnd = mulberry(hash("o:" + ctx.kw));
    var plan = INTENT_PLAN[ctx.intent] || INTENT_PLAN.informational;

    var extraCount = 3 + Math.floor(rnd() * 3);
    var chosen = plan.anchor.concat(shuffle(plan.pool, rnd).slice(0, extraCount));

    // Named competitors earn the comparison lens a slot.
    if (ctx.competitors.length && chosen.indexOf("comparison") === -1) chosen.splice(3, 0, "comparison");
    chosen.push("expert");
    chosen.push("faq");
    if (rnd() > 0.45) chosen.push("nextsteps");

    var used = {}, sections = [];
    chosen.forEach(function (id) {
      if (used[id] || !ARCHETYPES[id]) return;
      used[id] = true;
      var a = ARCHETYPES[id];
      var head = pick(a.heads, rnd)
        .replace(/\{K\}/g, ctx.kwT).replace(/\{T\}/g, ctx.topicT);
      var subs = [];
      if (a.subs.length) {
        var nSubs = 2 + Math.floor(rnd() * 2);
        shuffle(a.subs, rnd).slice(0, nSubs).forEach(function (sub) {
          subs.push({
            t: sub.t.replace(/\{K\}/g, ctx.kwT).replace(/\{T\}/g, ctx.topicT),
            p: sub.p
          });
        });
      }
      sections.push({ id: id, h: head, subs: subs });
    });

    var faq = sections.filter(function (x) { return x.id === "faq"; })[0];
    if (faq) faq.subs = faqFor(ctx, rnd);

    return sections;
  }

  var CLOSERS = { expert: 1, faq: 1, nextsteps: 1 };

  // Adds one unused body archetype ahead of the closing sections.
  // Returns false when the pool is exhausted.
  function topUpOutline(brief, rnd) {
    var used = {};
    brief.outline.forEach(function (s) { used[s.id] = true; });
    var avail = Object.keys(ARCHETYPES).filter(function (id) {
      return !used[id] && !CLOSERS[id] && id !== "quickanswer";
    });
    if (!avail.length) return false;

    var id = avail[Math.floor(rnd() * avail.length) % avail.length];
    var a = ARCHETYPES[id];
    var head = pick(a.heads, rnd)
      .replace(/\{K\}/g, brief.ctx.kwT).replace(/\{T\}/g, brief.ctx.topicT);
    var subs = [];
    if (a.subs.length) {
      shuffle(a.subs, rnd).slice(0, 2 + Math.floor(rnd() * 2)).forEach(function (sub) {
        subs.push({
          t: sub.t.replace(/\{K\}/g, brief.ctx.kwT).replace(/\{T\}/g, brief.ctx.topicT),
          p: sub.p
        });
      });
    }

    var at = brief.outline.length;
    for (var i = 0; i < brief.outline.length; i++) {
      if (CLOSERS[brief.outline[i].id]) { at = i; break; }
    }
    brief.outline.splice(at, 0, { id: id, h: head, subs: subs });
    return true;
  }

  function faqFor(ctx, rnd) {
    var t = ctx.topic;
    var pool = [
      "How long does " + t + " usually take?",
      "How much should I budget for " + t + "?",
      "What is the most common mistake with " + t + "?",
      "Do I need help, or can I do this myself?",
      "How do I know if " + t + " is working?",
      "What should I do first?",
      "Is " + t + " worth it for a small team?",
      "How often should this be revisited?",
      "What changes if my situation is unusual?"
    ];
    var answers = [
      "It varies with your circumstances more than with anything else, and the honest range is wide enough that a single number would mislead. The people who land at the quicker end are usually the ones who prepared before starting.",
      "Most of the cost is time rather than money, and the time is front-loaded. Budgeting for the preparation rather than just the doing gives you a more realistic picture.",
      "Start with the smallest version that produces real information. It tells you more than planning does and costs less than committing does.",
      "Yes, though what that looks like depends on scale. The underlying approach holds; the amount of process around it should not be the same for two people and twenty.",
      "Worth revisiting whenever your circumstances change materially, and otherwise on a set schedule so it does not depend on you happening to remember.",
      "Not necessarily, but knowing when to ask is worth something. The cases where help pays for itself are the unusual ones, not the routine ones."
    ];
    var chosen = shuffle(pool, rnd).slice(0, 3);
    return chosen.map(function (q, i) {
      return { t: q, p: answers[(hash(q) + i) % answers.length] };
    });
  }

  /* ============================================================
     Brief assembly
     ============================================================ */

  function buildBrief(row, idx) {
    var ctx = {
      kw: row.kw,
      kwT: titleCase(row.kw),
      topic: row.topic,
      topicT: titleCase(row.topic),
      intent: row.intent,
      competitors: competitorsFor(row.kw),
      tone: readPersona(state.persona),
      persona: state.persona
    };

    var rnd = mulberry(hash("b:" + row.kw + ":" + state.variant));
    var outline = buildOutline(ctx);

    var titleShapes = [
      ctx.kwT + ": What to Know",
      ctx.kwT + " — A Practical Guide",
      ctx.kwT + ": How It Works and What It Costs",
      "A Straight Answer on " + ctx.kwT,
      ctx.kwT + ", Explained"
    ];
    var metaShapes = [
      "A practical look at " + ctx.kw + " — what it involves, what to watch for, and how to decide.",
      "What " + ctx.kw + " actually requires, written for people who need to make a call rather than browse.",
      "Straight answers on " + ctx.kw + ": the requirements, the trade-offs, and the parts most guides skip."
    ];

    var brief = {
      idx: idx,
      kw: ctx.kw, kwTitle: ctx.kwT,
      topic: ctx.topic, topicTitle: ctx.topicT,
      intent: ctx.intent, intentLabel: INTENT_LABEL[ctx.intent],
      msv: row.msv, kd: row.kd, opp: row.opp, pinned: row.pinned,
      competitors: ctx.competitors,
      tone: ctx.tone, persona: ctx.persona,
      titleTag: pick(titleShapes, rnd),
      metaDesc: pick(metaShapes, rnd),
      outline: outline,
      trust: TRUST_SIGNALS,
      checklist: CHECKLIST,
      legalCleared: false,
      ctx: ctx
    };

    // Long-form floor. Rather than hoping the RNG picks enough sections, top the
    // outline up with unused archetypes until the draft clears MIN_WORDS. Sections
    // are inserted before the closing blocks so the structure stays coherent.
    brief.paras = buildCopy(brief);
    var st = statsOf(brief);
    var guard = 0;
    while (st.words < MIN_WORDS && guard++ < 8) {
      if (!topUpOutline(brief, rnd)) break;
      brief.paras = buildCopy(brief);
      st = statsOf(brief);
    }

    brief.words = st.words;
    brief.headings = st.headings;
    brief.lint = lintCopy(copyPlain(brief));
    return brief;
  }

  /* ============================================================
     Copy generation — renders from the same outline the brief shows
     ============================================================ */

  function buildCopy(b) {
    var c = b.ctx;
    var rnd = mulberry(hash("c:" + b.kw + ":" + state.variant));
    var blocks = [];

    var openers = [
      [ { t: "If you are looking into " }, { t: c.kw, kw: true },
        { t: ", you have probably found that most of what is written about it answers a slightly different question than the one you have. This page covers what actually changes the decision, and skips the background you can find anywhere." } ],
      [ { t: "There is a short answer to " }, { t: c.kw, kw: true },
        { t: ", and there is the version with the caveats that matter. Both are here, in that order, so you can stop whenever you have what you came for." } ],
      [ { t: "Most guides to " }, { t: c.kw, kw: true },
        { t: " start with definitions and work outward. This one starts from the decision you are trying to make and works back to what you need in order to make it." } ]
    ];
    blocks.push({ lvl: 1, h: b.kwTitle, paras: [] });
    blocks.push({ lvl: 0, paras: [ pick(openers, rnd) ] });

    b.outline.forEach(function (sec) {
      var a = ARCHETYPES[sec.id];
      blocks.push({ lvl: 2, h: sec.h, paras: a ? a.paras(c, rnd) : [] });
      sec.subs.forEach(function (sub) {
        blocks.push({ lvl: 3, h: sub.t, paras: [[ { t: sub.p } ]] });
      });
    });

    return blocks;
  }

  /* ---------------- renderers over the copy model ---------------- */

  function copyHTML(b) {
    return b.paras.map(function (blk) {
      var head = "";
      if (blk.lvl === 2) head = "<h2>" + esc(blk.h) + "</h2>";
      else if (blk.lvl === 3) head = "<h3>" + esc(blk.h) + "</h3>";
      var body = blk.paras.map(function (p) {
        return "<p>" + p.map(function (tk) {
          if (tk.kw) return '<mark class="kw">' + esc(tk.t) + "</mark>";
          return esc(tk.t);
        }).join("") + "</p>";
      }).join("");
      return head + body;
    }).join("");
  }

  function tokenText(tk) { return tk.t; }

  function copyPlain(b) {
    var out = [];
    b.paras.forEach(function (blk) {
      if (blk.h && blk.lvl > 1) out.push(blk.h);
      blk.paras.forEach(function (p) { out.push(p.map(tokenText).join("")); });
    });
    return out.join("\n\n");
  }

  function statsOf(b) {
    var words = 0, headings = 0;
    b.paras.forEach(function (blk) {
      if (blk.lvl === 2 || blk.lvl === 3) headings++;
      blk.paras.forEach(function (p) {
        p.forEach(function (tk) {
          var t = tokenText(tk).trim();
          if (t) words += t.split(/\s+/).length;
        });
      });
    });
    return { words: words, headings: headings };
  }

  function kwDensity(b) {
    var body = copyPlain(b).toLowerCase();
    var needle = b.kw.toLowerCase();
    var count = 0, at = body.indexOf(needle);
    while (at !== -1) { count++; at = body.indexOf(needle, at + needle.length); }
    var termWords = needle.split(/\s+/).length;
    return b.words ? ((count * termWords / b.words) * 100).toFixed(2) : "0.00";
  }

  /* ============================================================
     UI — screen 1
     ============================================================ */

  var topicInput = $("topic-input");
  var kwInput = $("kw-input");
  var compInput = $("comp-input");
  var personaInput = $("persona-input");

  function chipList(hostId, list, render, label) {
    var wrap = $(hostId);
    wrap.innerHTML = "";
    list.forEach(function (v, i) {
      var chip = document.createElement("span");
      chip.className = "tag-chip";
      var s = document.createElement("span");
      s.textContent = v;
      var x = document.createElement("button");
      x.type = "button";
      x.setAttribute("aria-label", "Remove " + label + " " + v);
      x.textContent = "✕";
      x.addEventListener("click", function (e) { e.stopPropagation(); list.splice(i, 1); render(); });
      chip.appendChild(s); chip.appendChild(x);
      wrap.appendChild(chip);
    });
  }

  function renderTopics() {
    chipList("topic-tags", state.topics, renderTopics, "topic");
    $("topic-count").textContent = state.topics.length;
    topicInput.disabled = state.topics.length >= MAX_TOPICS;
    topicInput.placeholder = state.topics.length >= MAX_TOPICS
      ? "Topic limit reached"
      : (state.topics.length ? "Add another topic…" : "e.g. project management software");

    var has = state.topics.length > 0;
    ["kw-prompt", "kw-row", "kw-meta", "comp-prompt", "comp-row", "comp-meta",
     "persona-prompt", "persona-row", "persona-meta"].forEach(function (id) {
      $(id).classList.toggle("hidden", !has);
    });
    $("research-btn").disabled = !has;
  }
  function renderPinned() {
    chipList("kw-tags", state.pinned, renderPinned, "keyword");
    $("kw-count").textContent = state.pinned.length;
  }
  function renderComps() {
    chipList("comp-tags", state.competitors, renderComps, "competitor");
    $("comp-count").textContent = state.competitors.length;
    compInput.disabled = state.competitors.length >= MAX_COMPETITORS;
    compInput.placeholder = state.competitors.length >= MAX_COMPETITORS
      ? "Competitor limit reached" : "e.g. asana.com";
  }

  function addTag(list, value, max, done) {
    var v = String(value).trim().replace(/[,\s]+$/, "");
    if (!v) return;
    if (max && list.length >= max) return;
    if (list.some(function (x) { return x.toLowerCase() === v.toLowerCase(); })) return;
    list.push(v);
    done();
  }

  function wireTagInput(inputEl, containerId, list, max, render) {
    inputEl.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === ",") {
        e.preventDefault();
        addTag(list, inputEl.value, max, render);
        inputEl.value = "";
      } else if (e.key === "Backspace" && inputEl.value === "" && list.length) {
        list.pop(); render();
      }
    });
    inputEl.addEventListener("blur", function () {
      if (inputEl.value.trim()) { addTag(list, inputEl.value, max, render); inputEl.value = ""; }
    });
    $(containerId).addEventListener("click", function () { inputEl.focus(); });
  }

  wireTagInput(topicInput, "topic-tag-input", state.topics, MAX_TOPICS, renderTopics);
  wireTagInput(kwInput, "kw-tag-input", state.pinned, null, renderPinned);
  wireTagInput(compInput, "comp-tag-input", state.competitors, MAX_COMPETITORS, renderComps);

  personaInput.addEventListener("input", function () {
    state.persona = personaInput.value;
    $("persona-count").textContent = personaInput.value.length;
    var tags = readPersona(personaInput.value);
    $("persona-read").textContent = tags.length ? "reading as: " + tags.join(", ") : "";
  });

  $("fill-example").addEventListener("click", function () {
    state.topics = ["project management software", "team collaboration tools", "remote onboarding"];
    state.pinned = ["asynchronous standup"];
    state.competitors = ["asana.com", "monday.com", "notion.so"];
    state.persona = "Direct and practical, for ops managers at mid-size teams. Plain English, no hype, concrete examples over theory.";
    personaInput.value = state.persona;
    personaInput.dispatchEvent(new Event("input"));
    renderTopics(); renderPinned(); renderComps();
    $("research-btn").focus();
  });

  $("research-btn").addEventListener("click", function () {
    if (!state.topics.length) return;
    state.reruns = 0; state.variant = 0;
    startResearch();
  });

  /* ============================================================
     UI — screen 2
     ============================================================ */

  function goScreen(n) {
    var i, screens = document.querySelectorAll(".screen");
    for (i = 0; i < screens.length; i++) screens[i].classList.remove("active");
    $("screen-" + n).classList.add("active");
    var items = document.querySelectorAll("#stepper li");
    for (i = 0; i < items.length; i++) {
      var s = parseInt(items[i].getAttribute("data-step"), 10);
      items[i].classList.remove("active", "done");
      if (s === n) items[i].classList.add("active");
      else if (s < n) items[i].classList.add("done");
    }
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function renderPipeline() {
    var ol = $("pipeline");
    ol.innerHTML = "";
    PIPELINE.forEach(function (s, i) {
      var li = document.createElement("li");
      li.id = "pl-" + i;
      li.innerHTML = '<span class="pl-mark"></span><span class="pl-body">' +
        '<span class="pl-title">' + esc(s.t) + "</span><span class=\"pl-tags\">" +
        '<span class="tg tg-' + s.aut + '">' + AUT_LABEL[s.aut] + "</span>" +
        '<span class="tg tg-' + (s.who === "both" ? "both" : "ai") + '">' + WHO_LABEL[s.who] + "</span>" +
        '<span class="tg tg-tool">' + esc(s.tool) + "</span></span></span>";
      ol.appendChild(li);
    });
  }

  function runPhase(from, to, headline, budget, onDone) {
    $("gen-stage").classList.remove("hidden");
    $("gate-stage").classList.add("hidden");
    $("gen-headline").textContent = headline;
    $("gen-budget").textContent = budget;
    var i = from;
    function step() {
      if (i > from) {
        var prev = $("pl-" + (i - 1));
        if (prev) { prev.classList.remove("on"); prev.classList.add("done"); }
      }
      if (i >= to) { onDone(); return; }
      var li = $("pl-" + i);
      if (li) { li.classList.add("on"); li.scrollIntoView({ block: "nearest" }); }
      $("gen-sub").textContent = PIPELINE[i].sub;
      $("progress-fill").style.width = Math.round(((i + 1) / PIPELINE.length) * 100) + "%";
      i++;
      later(step, STEP_MS);
    }
    step();
  }

  function startResearch() {
    clearTimers();
    goScreen(2);
    renderPipeline();
    $("progress-fill").style.width = "0%";
    state.pulledAt = new Date();
    state.approved = [];
    buildCandidates();
    runPhase(0, PHASE_A_END, "Pulling keyword data…",
      "Latency budget: under 2 minutes — you're waiting on this one.",
      function () { later(showGate, 300); });
  }

  function showGate() {
    $("gen-stage").classList.add("hidden");
    $("gate-stage").classList.remove("hidden");
    $("sel-max").textContent = MAX_APPROVED;
    renderKwTable();
    renderCutList();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function kdClass(kd) { return kd <= 39 ? "kd-low" : (kd <= 59 ? "kd-mid" : "kd-high"); }

  function renderKwTable() {
    var tb = $("kw-tbody");
    tb.innerHTML = "";
    state.candidates.forEach(function (r, i) {
      var tr = document.createElement("tr");
      var comps = competitorsFor(r.kw);
      var compCell = comps.length
        ? '<ul class="comp-list">' + comps.map(function (c) {
            return "<li><span class=\"comp-dom\">" + esc(c) + "</span></li>";
          }).join("") + "</ul>"
        : '<span class="comp-none">none entered</span>';

      tr.innerHTML =
        '<td class="c-check"><input type="checkbox" aria-label="Select ' + esc(r.kw) + '"></td>' +
        '<td class="c-kw"><span class="kw-name">' + esc(r.kw) + "</span>" +
          (r.pinned ? '<span class="kw-pin">pinned</span>' : "") +
          '<span class="kw-topic">' + esc(r.topic) + " · " + esc(r.intent) + "</span></td>" +
        '<td class="c-num">' + nfmt(r.msv) + "</td>" +
        '<td class="c-num"><span class="kd-pill ' + kdClass(r.kd) + '">' + r.kd + "</span></td>" +
        '<td class="c-num"><span class="opp-wrap">' +
          '<span class="opp-bar"><span class="opp-fill" style="width:' + Math.min(r.opp, 100) + '%"></span></span>' +
          '<span class="opp-num">' + r.opp + "</span></span></td>" +
        '<td class="c-comp">' + compCell + "</td>";

      var box = tr.querySelector("input");
      box.addEventListener("click", function (e) { e.stopPropagation(); });
      box.addEventListener("change", function () { onToggle(i, box.checked); });
      tr.addEventListener("click", function () {
        if (box.disabled && !box.checked) return;
        box.checked = !box.checked;
        onToggle(i, box.checked);
      });
      tb.appendChild(tr);
    });
    $("filtered-note").textContent = state.candidates.length + " passed the filter of " +
      (state.candidates.length + state.cut.length) + " generated";
    syncSelection();
  }

  function onToggle(i, checked) {
    var kw = state.candidates[i].kw;
    var at = state.approved.indexOf(kw);
    if (checked && at === -1) {
      if (state.approved.length >= MAX_APPROVED) {
        $("kw-tbody").children[i].querySelector("input").checked = false;
        return;
      }
      state.approved.push(kw);
    } else if (!checked && at !== -1) state.approved.splice(at, 1);
    syncSelection();
  }

  function syncSelection() {
    var rows = $("kw-tbody").children, i, box, on;
    var full = state.approved.length >= MAX_APPROVED;
    for (i = 0; i < rows.length; i++) {
      on = state.approved.indexOf(state.candidates[i].kw) !== -1;
      box = rows[i].querySelector("input");
      box.checked = on;
      box.disabled = full && !on;
      rows[i].classList.toggle("sel", on);
      rows[i].style.opacity = (full && !on) ? "0.5" : "";
    }
    $("sel-count").textContent = state.approved.length;
    $("approve-btn").disabled = state.approved.length === 0;
  }

  function renderCutList() {
    $("cut-count").textContent = state.cut.length;
    $("cut-panel").classList.toggle("hidden", state.cut.length === 0);
    $("cut-list").innerHTML = state.cut.map(function (r) {
      var why = [];
      if (r.msv < MIN_MSV) why.push("est. volume " + nfmt(r.msv) + " below 2,000");
      if (r.kd > MAX_KD) why.push("difficulty " + r.kd + " above 60");
      return "<li><strong>" + esc(r.kw) + "</strong> — " + why.join("; ") + "</li>";
    }).join("");
  }

  $("select-top").addEventListener("click", function () {
    state.approved = state.candidates.slice(0, MAX_APPROVED).map(function (r) { return r.kw; });
    syncSelection();
  });
  $("clear-sel").addEventListener("click", function () { state.approved = []; syncSelection(); });
  $("approve-btn").addEventListener("click", function () {
    if (state.approved.length) startGeneration();
  });

  function startGeneration() {
    clearTimers();
    var n = state.approved.length;
    runPhase(PHASE_A_END, PIPELINE.length,
      "Drafting " + n + " brief" + (n === 1 ? "" : "s") + "…",
      "Latency budget: under 5 minutes for up to 10 briefs — runs after your approval.",
      function () {
        $("gen-headline").textContent = "Brief set ready";
        $("gen-sub").textContent = "Handing off for your review, edits and approval.";
        $("progress-fill").style.width = "100%";
        buildBriefs();
        later(function () { renderResults(); goScreen(3); }, 480);
      });
  }

  function buildBriefs() {
    var byKw = {};
    state.candidates.forEach(function (r) { byKw[r.kw] = r; });
    state.briefs = state.approved.map(function (kw, i) { return buildBrief(byKw[kw], i); });
    state.activeBrief = 0;
  }

  /* ============================================================
     UI — screen 3
     ============================================================ */

  function renderResults() { renderMetrics(); renderRail(); renderBrief(); }

  function renderMetrics() {
    var n = state.briefs.length;
    var avgWords = state.briefs.length
      ? Math.round(state.briefs.reduce(function (a, b) { return a + b.words; }, 0) / state.briefs.length)
      : 0;
    var saved = n * (MANUAL_HRS_PER_BRIEF - TOOL_HRS_PER_BRIEF);
    $("m-briefs").textContent = n;
    $("m-reruns").textContent = state.reruns;
    $("m-flags").textContent = nfmt(avgWords);
    $("m-hours").textContent = saved.toFixed(1) + " hrs";
    var rb = $("m-reruns-bar");
    rb.textContent = state.reruns <= 2 ? "within target (≤2)" : "over target (≤2)";
    rb.className = "h-bar " + (state.reruns <= 2 ? "good" : "over");
    $("m-hours-bar").textContent = nfmt(n * MANUAL_HRS_PER_BRIEF) + " hrs manual → " +
      (n * TOOL_HRS_PER_BRIEF).toFixed(1) + " hrs here";
  }

  function renderRail() {
    var ul = $("rail-list");
    ul.innerHTML = "";
    state.briefs.forEach(function (b, i) {
      var li = document.createElement("li");
      li.className = "rail-item" + (i === state.activeBrief ? " on" : "");
      li.setAttribute("role", "button");
      li.setAttribute("tabindex", "0");
      var lock = b.legalCleared
        ? '<span class="rail-lock clear">✓ Approved</span>'
        : '<span class="rail-lock locked">Awaiting review</span>';
      li.innerHTML = '<span class="rail-idx">' + (i + 1) + "</span><span>" +
        '<span class="rail-kw">' + esc(b.kw) + "</span>" +
        '<span class="rail-sub">' + nfmt(b.msv) + "/mo · KD " + b.kd + "</span>" + lock + "</span>";
      li.addEventListener("click", function () { selectBrief(i); });
      li.addEventListener("keydown", function (e) {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); selectBrief(i); }
      });
      ul.appendChild(li);
    });
  }

  function selectBrief(i) {
    state.activeBrief = i;
    renderRail(); renderBrief();
    document.querySelector('.tab[data-tab="brief"]').click();
  }

  function renderBrief() {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    var pulled = state.pulledAt || new Date();
    var stale = new Date(pulled.getTime());
    stale.setDate(stale.getDate() + STALE_DAYS);

    $("d-pulled").textContent = fmtDate(pulled);
    $("d-stale").textContent = fmtDate(stale);
    $("d-msv").textContent = nfmt(b.msv) + "/mo";
    $("d-kd").textContent = b.kd;
    $("d-topic").textContent = b.topic;

    $("b-keyword").textContent = b.kw;
    $("b-intent").textContent = b.intentLabel;

    $("b-persona").textContent = b.persona || "No persona entered — copy uses a neutral register.";
    $("b-tone").innerHTML = b.tone.map(function (t) {
      return '<span class="chip">' + esc(t) + "</span>";
    }).join("");

    $("b-title").textContent = b.titleTag;
    $("b-meta").textContent = b.metaDesc;
    $("b-outline-note").textContent = b.outline.length + " sections · built for " + b.intent + " intent";

    $("b-outline").innerHTML = b.outline.map(function (sec) {
      var subs = sec.subs.length
        ? "<ul>" + sec.subs.map(function (s) { return "<li>" + esc(s.t) + "</li>"; }).join("") + "</ul>"
        : "";
      return "<li>" + esc(sec.h) + subs + "</li>";
    }).join("");

    $("b-comp-wrap").innerHTML = b.competitors.length
      ? '<ul class="link-list">' + b.competitors.map(function (c) {
          return "<li><strong>" + esc(c) + "</strong> — capture current H2/H3 structure for this keyword; " +
                 "note what they cover that this outline does not.</li>";
        }).join("") + "</ul>"
      : '<p class="muted empty-note">No competitors entered, so none were analyzed. ' +
        "Add competitors on the first screen to get a per-keyword audit list. " +
        "This tool will not invent competitors or claim a gap it has not seen.</p>";

    $("b-trust").innerHTML = b.trust.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("");
    $("b-checklist").innerHTML = b.checklist.map(function (c, i) {
      var id = "chk-" + b.idx + "-" + i;
      return '<li><input type="checkbox" id="' + id + '"><label for="' + id + '">' + esc(c) + "</label></li>";
    }).join("");

    $("c-h1").textContent = b.kwTitle;
    $("c-body").innerHTML = copyHTML(b).replace(/^<h1>.*?<\/h1>/, "");
    $("cs-words").textContent = nfmt(b.words);
    $("cs-heads").textContent = b.headings;
    $("cs-flags").textContent = b.outline.length;
    var dens = parseFloat(kwDensity(b));
    var densEl = $("cs-density");
    densEl.textContent = dens.toFixed(2) + "%";
    // Healthy exact-match density sits roughly between 0.3% and 2.5%.
    var densState = (dens < 0.3) ? "low" : (dens > 2.5 ? "high" : "ok");
    densEl.className = "dens-" + densState;
    densEl.title = densState === "ok" ? "Within a healthy range (0.3–2.5%)"
      : (densState === "low" ? "Below 0.3% — the target phrase may be too sparse"
                             : "Above 2.5% — reads as keyword stuffing");

    renderScan(b);
    renderGate(b);
    $("dl-status").textContent = "";
  }

  function renderScan(b) {
    var clean = b.lint.length === 0;
    $("ai-scan").classList.toggle("clean", clean);
    $("scan-dot").className = "scan-dot " + (clean ? "ok" : "warn");
    $("scan-title").textContent = clean ? "AI-writing scan: clean" : "AI-writing scan: " + b.lint.length + " to review";
    $("scan-sub").textContent = clean
      ? "No filler phrasing, puffery, negative parallelism or formulaic closers found."
      : "Rewrite these before publishing.";
    $("scan-list").innerHTML = b.lint.map(function (h) {
      return "<li><code>" + esc(h.phrase) + "</code> — " + esc(h.why) + "</li>";
    }).join("");
  }

  function renderGate(b) {
    var gate = $("legal-gate"), cb = $("legal-checkbox");
    cb.disabled = false;
    cb.checked = b.legalCleared;
    gate.classList.toggle("clear", b.legalCleared);
    $("lg-icon").textContent = b.legalCleared ? "\u2713" : "\u270E";
    $("lg-title").textContent = b.legalCleared
      ? "Approved for publish."
      : "Editorial review before publish.";
    $("lg-body").textContent = b.legalCleared
      ? "Draft copy export is unlocked."
      : "This is a first draft. Read it through, fact-check anything you add, and confirm it matches your brand voice before it ships.";
    $("dl-article-btn").disabled = !b.legalCleared;
  }

  $("legal-checkbox").addEventListener("change", function () {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    b.legalCleared = this.checked;
    renderGate(b); renderRail();
  });

  (function wireTabs() {
    var tabs = document.querySelectorAll(".tab");
    for (var i = 0; i < tabs.length; i++) {
      tabs[i].addEventListener("click", function () {
        var all = document.querySelectorAll(".tab"), j;
        for (j = 0; j < all.length; j++) all[j].classList.remove("active");
        var panels = document.querySelectorAll(".tab-panel");
        for (j = 0; j < panels.length; j++) panels[j].classList.remove("active");
        this.classList.add("active");
        $("panel-" + this.getAttribute("data-tab")).classList.add("active");
      });
    }
  })();

  $("regen-btn").addEventListener("click", function () {
    state.reruns += 1; state.variant += 1;
    clearTimers();
    goScreen(2);
    renderPipeline();
    for (var i = 0; i < PHASE_A_END; i++) {
      var li = $("pl-" + i);
      if (li) li.classList.add("done");
    }
    $("progress-fill").style.width = Math.round((PHASE_A_END / PIPELINE.length) * 100) + "%";
    startGeneration();
  });

  $("start-over-btn").addEventListener("click", function () {
    clearTimers();
    state.candidates = []; state.cut = []; state.approved = [];
    state.briefs = []; state.activeBrief = 0; state.reruns = 0; state.variant = 0;
    $("gen-stage").classList.remove("hidden");
    $("gate-stage").classList.add("hidden");
    goScreen(1);
    topicInput.focus();
  });

  /* ============================================================
     Export — Word-compatible .doc (v1 behaviour)
     ============================================================ */

  function status(msg, isErr) {
    var el = $("dl-status");
    el.textContent = msg;
    el.className = "dl-status" + (isErr ? " err" : "");
    clearTimeout(status._t);
    status._t = setTimeout(function () {
      el.textContent = "";
      el.className = "dl-status";
    }, 6000);
  }

  function docShell(title, body) {
    return '<!DOCTYPE html>\n' +
      '<html xmlns:o="urn:schemas-microsoft-com:office:office" ' +
      'xmlns:w="urn:schemas-microsoft-com:office:word" ' +
      'xmlns="http://www.w3.org/TR/REC-html40">\n' +
      '<head><meta charset="utf-8"><title>' + esc(title) + "</title>\n" +
      "<style>\n" +
      "body{font-family:Calibri,Arial,sans-serif;font-size:11pt;color:#0f172a;line-height:1.5;}\n" +
      "h1{font-size:19pt;color:#0f2340;} h2{font-size:13pt;color:#0f2340;margin-top:16pt;}\n" +
      "h3{font-size:11.5pt;color:#15315a;}\n" +
      ".flag{color:#b91c1c;font-weight:bold;} .kw{color:#047857;font-weight:bold;}\n" +
      ".callout{border:1.5pt solid #0f2340;background:#eef2ff;padding:8pt;margin:10pt 0;}\n" +
      ".meta{color:#64748b;font-size:9.5pt;}\n" +
      "</style></head>\n<body>" + body + "</body></html>";
  }

  function briefDocBody(b) {
    var outline = b.outline.map(function (sec) {
      var subs = sec.subs.length
        ? "<ul>" + sec.subs.map(function (sub) {
            return "<li>" + esc(sub.t) + "</li>";
          }).join("") + "</ul>"
        : "";
      return "<p><strong>" + esc(sec.h) + "</strong></p>" + subs;
    }).join("");

    var comps = b.competitors.length
      ? "<ul>" + b.competitors.map(function (c) {
          return "<li>" + esc(c) + " &mdash; capture current H2/H3 structure for \"" + esc(b.kw) +
                 "\"; note what they cover that this outline does not.</li>";
        }).join("") + "</ul>"
      : "<p><em>No competitors were entered, so none were analyzed.</em></p>";

    return "<h1>SEO Content Brief: " + esc(b.kwTitle) + "</h1>" +
      '<p class="meta">Target keyword: ' + esc(b.kw) + " &middot; Seed topic: " + esc(b.topic) +
      " &middot; Est. volume " + nfmt(b.msv) + "/mo &middot; Difficulty " + b.kd +
      " &middot; Data pulled " + fmtDate(state.pulledAt || new Date()) + "</p>" +
      '<div class="callout"><strong>REQUIRED:</strong> cite 2&ndash;3 authoritative primary sources ' +
      "before publish, and fact-check any figures you add to this draft.</div>" +
      (b.persona ? "<h2>Voice &amp; audience</h2><p>" + esc(b.persona) + "</p>" +
        (b.tone.length ? '<p class="meta">Reads as: ' + esc(b.tone.join(", ")) + "</p>" : "") : "") +
      "<h2>Search intent</h2><p>" + esc(b.intentLabel) + "</p>" +
      "<h2>Title tag</h2><p>" + esc(b.titleTag) + "</p>" +
      "<h2>Meta description</h2><p>" + esc(b.metaDesc) + "</p>" +
      "<h2>Outline</h2>" + outline +
      "<h2>Competitor coverage (for review &mdash; not a confirmed gap)</h2>" + comps +
      "<h2>Trust signals to include</h2><ul>" +
      b.trust.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ul>" +
      "<h2>Editorial checklist (human sign-off required)</h2><ul>" +
      b.checklist.map(function (c) { return "<li>&#9744; " + esc(c) + "</li>"; }).join("") + "</ul>";
  }

  function briefDocText(b) {
    var lines = [];
    lines.push("SEO CONTENT BRIEF: " + b.kwTitle);
    lines.push("Target keyword: " + b.kw + " | Seed topic: " + b.topic +
      " | Est. volume " + nfmt(b.msv) + "/mo | Difficulty " + b.kd);
    lines.push("Data pulled " + fmtDate(state.pulledAt || new Date()));
    lines.push("");
    lines.push("REQUIRED: cite 2-3 authoritative primary sources before publish,");
    lines.push("and fact-check any figures you add to this draft.");
    lines.push("");
    if (b.persona) {
      lines.push("VOICE & AUDIENCE"); lines.push(b.persona);
      if (b.tone.length) lines.push("Reads as: " + b.tone.join(", "));
      lines.push("");
    }
    lines.push("SEARCH INTENT"); lines.push(b.intentLabel); lines.push("");
    lines.push("TITLE TAG"); lines.push(b.titleTag); lines.push("");
    lines.push("META DESCRIPTION"); lines.push(b.metaDesc); lines.push("");
    lines.push("OUTLINE");
    b.outline.forEach(function (sec) {
      lines.push("  " + sec.h);
      sec.subs.forEach(function (s) {
        lines.push("    - " + s.t);
      });
    });
    lines.push("");
    lines.push("COMPETITOR COVERAGE (for review - not a confirmed gap)");
    if (b.competitors.length) b.competitors.forEach(function (c) { lines.push("  - " + c); });
    else lines.push("  none entered - none analyzed");
    lines.push("");
    lines.push("TRUST SIGNALS");
    b.trust.forEach(function (t) { lines.push("  - " + t); });
    lines.push("");
    lines.push("EDITORIAL CHECKLIST (human sign-off)");
    b.checklist.forEach(function (c) { lines.push("  [ ] " + c); });
    return lines.join("\n");
  }

  function slug(s) {
    return String(s).toLowerCase().replace(/[^a-z0-9]+/g, "-")
      .replace(/^-+|-+$/g, "").slice(0, 50) || "item";
  }

  // Saves through the viewer's downloads capability when the page is running
  // inside the Artifact sandbox (plain <a download> is inert there), and falls
  // back to a Blob anchor when opened as a normal web page.
  function saveDoc(baseName, title, html, text) {
    var full = docShell(title, html);

    if (window.claude && window.claude.downloads) {
      window.claude.downloads.save({ filename: baseName + ".html", data: full })
        .then(function () {
          status("Saved " + baseName + ".html — open it in Word (File › Open).", false);
        })
        .catch(function (err) {
          var code = err && err.code;
          if (code === "declined") { status("Download canceled.", false); return; }
          if (code === "rejected_extension" || code === "extension_not_enabled") {
            window.claude.downloads.save({ filename: baseName + ".txt", data: text })
              .then(function () { status("Saved " + baseName + ".txt (plain text fallback).", false); })
              .catch(function (e2) {
                var c2 = e2 && e2.code;
                status(c2 === "declined" ? "Download canceled." : "Couldn't save the file (" + (c2 || "error") + ").", c2 !== "declined");
              });
            return;
          }
          if (code === "rate_limited") { status("A download prompt is already open — try again in a moment.", true); return; }
          status("Couldn't save the file (" + (code || "error") + ").", true);
        });
      return;
    }

    var blob = new Blob(["﻿", full], { type: "application/msword" });
    var url = URL.createObjectURL(blob);
    var a = document.createElement("a");
    a.href = url;
    a.download = baseName + ".doc";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function () { URL.revokeObjectURL(url); }, 1500);
    status("Downloaded " + baseName + ".doc", false);
  }

  $("dl-brief-btn").addEventListener("click", function () {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    saveDoc("SEO-Brief_" + slug(b.kw), "SEO Brief — " + b.kwTitle,
      briefDocBody(b), briefDocText(b));
  });

  $("export-all-btn").addEventListener("click", function () {
    if (!state.briefs.length) return;
    var n = state.briefs.length;
    var approved = state.briefs.filter(function (b) { return b.legalCleared; }).length;

    var head = "<h1>SEO Content Brief Set</h1>" +
      '<p class="meta">' + n + " brief" + (n === 1 ? "" : "s") +
      " &middot; generated " + fmtDate(state.pulledAt || new Date()) +
      " &middot; " + approved + " of " + n + " approved</p>" +
      '<div class="callout"><strong>REQUIRED for every brief in this set:</strong> ' +
      "cite 2&ndash;3 authoritative primary sources before publish, and fact-check any figures " +
      "added to these drafts.</div>";

    var body = head + state.briefs.map(function (b, i) {
      return (i > 0 ? '<p style="page-break-before:always"></p>' : "") + briefDocBody(b);
    }).join("");

    var text = "SEO CONTENT BRIEF SET\n" + n + " briefs | generated " +
      fmtDate(state.pulledAt || new Date()) + "\n" +
      approved + " of " + n + " approved.\n\n" +
      state.briefs.map(briefDocText).join("\n\n" + new Array(60).join("=") + "\n\n");

    saveDoc("SEO-Brief-Set_" + n + "-briefs", "SEO Brief Set", body, text);
  });

  $("dl-article-btn").addEventListener("click", function () {
    var b = state.briefs[state.activeBrief];
    if (!b) return;
    if (!b.legalCleared) {
      status("Blocked: this draft still needs review clearance.", true);
      return;
    }
    var body = "<h1>" + esc(b.kwTitle) + "</h1>" +
      copyHTML(b).replace(/^<h1>.*?<\/h1>/, "")
                 .replace(/<mark class="vf">/g, '<span class="flag">')
                 .replace(/<mark class="kw">/g, '<span class="kw">')
                 .replace(/<\/mark>/g, "</span>") +
      '<p class="meta"><em>First draft. Fact-check any figures added before publish.</em></p>';
    saveDoc("Draft-Copy_" + slug(b.kw), b.kwTitle, body, copyPlain(b));
  });

  /* ---------------- init ---------------- */
  renderTopics(); renderPinned(); renderComps();
  topicInput.focus();
})();
