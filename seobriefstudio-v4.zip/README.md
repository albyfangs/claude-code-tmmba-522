# SEO/GEO Content Brief Studio — v2

A clickable front-end prototype that turns seed topics into SEO + GEO content briefs and
long-form draft copy, with a mandatory human approval gate in the middle and `.docx` / `.zip`
export at the end.

## Run it

No build step, no dependencies, no network calls.

```bash
python3 -m http.server 8080     # then open http://localhost:8080
```

`seo-brief-studio-standalone.html` (if present) runs from a double-click with no server.

## The flow

```
seed topics + keywords + competitors + persona
        ↓
keyword expansion, estimate, mechanical filter, rank      (~2 min budget)
        ↓
        🔒  HUMAN APPROVAL GATE — nothing is drafted until you approve
        ↓
outline → copy → claim flagging → AI-writing scan          (~5 min budget)
        ↓
review, per-brief clearance, export .docx / .zip
```

## What's new in v2

| # | Change |
|---|---|
| 1 | **Persona field.** Open-ended brand voice and audience input on screen 1. Detected register is shown live, shapes the draft, and ships inside every brief. |
| 2 | **No brand or vertical bias.** All SoFi references and home-loan defaults removed. |
| 3 | **Nothing is inherited.** No built-in topic bank. Every keyword, outline and heading derives from what you type. |
| 4 | **Unique outline per brief.** Section archetypes, heading phrasings, subsection sets and section counts are chosen by a seeded RNG keyed to each keyword — verified 10 unique structures from 10 keywords. |
| 5 | **Competitors come from you.** The tool analyzes only competitors you name and never invents one or claims a gap it hasn't seen. |
| 6 | **Anti-AI-writing.** Copy is written against the "signs of AI writing" guidance, then linted for it in the UI — filler vocabulary, negative parallelism, puffery, vague attribution and formulaic closers. |
| 7 | **Up to 10 seed topics** (was 5). |
| 8 | **Up to 10 competitors**, used for per-keyword audit lists and to bring a comparison lens into the outline. |
| 9 | ~~`.docx` + `.zip` export~~ — **reverted to v1 `.doc`** at the user's request (see Export format). |

## Copy vs. brief

The **draft copy** is finished, readable prose about the topic — no placeholders, no brackets,
no guidance to the writer. Every H3 carries its own matched paragraph, so a section heading and
the text under it always agree.

The copy does not assert specific figures, prices, dates or quotations. The tool has no
knowledge of your industry, so instead of inventing numbers it writes what holds structurally
and leaves the specifics to you. Add your own figures during review and source them.

The **brief** holds the editorial instructions: the sourcing callout and the checklist.

## Safety behaviour

- The draft never states a specific figure, price or quotation it cannot source.
- Per-brief editorial review gate; draft-copy export stays locked until a human approves it.
- Regenerating **resets all approvals** — regenerated copy has not been reviewed.
- Competitor coverage is labelled "for your review", never "a gap".
- The editorial checklist is human-checked and never AI-scored.

## Export format

Word-compatible `.doc` (HTML with Office namespaces), matching v1:

| Button | Output |
|---|---|
| Brief (.doc) | one content brief |
| Draft copy (.doc) | the long-form draft for that keyword |
| Export all briefs (.doc) | every brief in one document, page-broken |

Inside the Artifact sandbox the same content saves as `.html` (Word opens it via File › Open),
with a `.txt` fallback, since `<a download>` is inert there.

## Notes

Search volume and difficulty are **modelled estimates** derived deterministically from each
phrase, not a live Ahrefs pull — a given keyword always scores the same. Wiring in a real
keyword API would replace `estimate()` in `app.js` and nothing else.
